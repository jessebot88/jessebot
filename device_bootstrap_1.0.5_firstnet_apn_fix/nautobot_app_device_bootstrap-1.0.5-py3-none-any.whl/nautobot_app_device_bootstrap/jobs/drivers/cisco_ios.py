"""Cisco IOS / IOS-XE platform driver.

Source of truth for the Cisco console personality: prompt regexes, the
netmiko promotion target, router/switch classification, and the save-config
flow with its IOS-XE DBPERSIST self-heal. console.py re-exports the names
steps have always imported (EXEC_PROMPT, DBPERSIST helpers, ...), so step
modules keep importing from ..console.
"""

import re
import time

from .base import PlatformDriver

EXEC_PROMPT = r"(?m)^[A-Za-z0-9][\w\-]*#\s*$"
CFG_PROMPT = r"(?m)^[A-Za-z0-9][\w\-]*\([^)]+\)#\s*$"
ANY_PROMPT = r"(?m)^[A-Za-z0-9][\w\-]*(#|\([^)]+\)#)\s*$"

# IOS-XE TDLDB persist bug: a stale CTRL_MNG_CFG_DB directory under
# bootflash:/.dbpersist blocks config save AND reload:
#   %TDLDB-3-DBPERSIST_OPERATION_FAILURE: ... Failure reason: Is a directory
#   %IOSXE_RP_CFG_NOT-3-MCP_DBPERSIST_ERROR: System configuration update
#   could not complete
DBPERSIST_ERROR = re.compile(
    r"DBPERSIST|configuration update could not complete|"
    r"Failure reason:\s*Is a directory|startup-config file open failed",
    re.IGNORECASE,
)
_DBPERSIST_DB_PATH = "bootflash:/.dbpersist/CTRL_MNG_CFG_DB/"


def dbpersist_log_count(child):
    """Count DBPERSIST entries in the log buffer, or None if unreadable.

    The bug's failure is ASYNC: `write mem` prints [OK] while the persist
    fails seconds later as syslog (seen live). Comparing counts before/after
    a save is how an inline-clean-but-actually-failed save is caught."""
    try:
        child.drain(quiet=0.3, max_wait=3)
        out = child.send_command("show logging | count DBPERSIST", read_timeout=30)
        m = re.search(r"=\s*(\d+)", out)
        if m:
            return int(m.group(1))
        out = child.send_command("show logging | include DBPERSIST", read_timeout=30)
        return len(re.findall(r"%\S*DBPERSIST", out))
    except Exception:
        return None


def dbpersist_bug_logged(child):
    """True if the log buffer shows the TDLDB persist failure. With console
    logging off, the buffer is where the syslog signature lands."""
    try:
        child.drain(quiet=0.3, max_wait=3)
        out = child.send_command("show logging | include DBPERSIST", read_timeout=30)
        return bool(re.search(r"%\S*DBPERSIST", out))
    except Exception:
        return False


def clear_log_buffer(child):
    """Clear the device log buffer (best effort).

    Used after DBPERSIST remediation so the retry save is judged from a zero
    baseline: the bug's syslog entries land seconds after the save's [OK], so
    a straggler from the FIRST failed save can otherwise drift in between the
    retry's before/after samples and get blamed on a save that succeeded.
    Failure here is fine — the count-based comparison still works, just with
    the old race window.
    """
    try:
        child.drain(quiet=0.3, max_wait=3)
        child.send_command_timing("clear logging", last_read=1.0, read_timeout=15)
        child.send_command_timing("", last_read=1.0, read_timeout=10)  # answer [confirm]
    except Exception:
        pass


def dbpersist_log_lines(child, limit=3):
    """The last few DBPERSIST log lines, for failure evidence. Empty on error."""
    try:
        child.drain(quiet=0.3, max_wait=3)
        out = child.send_command("show logging | include DBPERSIST", read_timeout=30)
        lines = [ln.strip() for ln in out.splitlines() if "DBPERSIST" in ln]
        return " | ".join(lines[-limit:])
    except Exception:
        return ""


def clear_dbpersist_db(child, logger):
    """Delete the stale DBPERSIST directory that blocks save/reload."""
    logger.warning(
        f"Hit the IOS-XE DBPERSIST bug — deleting stale {_DBPERSIST_DB_PATH} and retrying"
    )
    child.drain(quiet=0.3, max_wait=3)
    # /force /recursive suppresses per-file confirms; timing-based send in
    # case a platform still prompts something unexpected.
    out = child.send_command_timing(
        f"delete /force /recursive {_DBPERSIST_DB_PATH}", last_read=2.0, read_timeout=60
    )
    return out


class CiscoIosDriver(PlatformDriver):
    """Cisco IOS / IOS-XE — routers and switches, the original device family."""

    network_drivers = ("cisco_ios", "cisco_xe")
    netmiko_device_type = "cisco_ios"

    exec_prompt = EXEC_PROMPT
    cfg_prompt = CFG_PROMPT
    any_prompt = ANY_PROMPT

    pipeline_keys = {
        "router": "pipeline_router",
        "switch": "pipeline_switch",
    }

    def classify(self, device):
        """Router vs switch by role name — router wins when a role matches both."""
        role_name = device.role.name.lower() if device.role else ""
        if "router" in role_name:
            return "router"
        if any(k in role_name for k in ("switch", "access", "dist")):
            return "switch"
        return None

    def save_config(self, console):
        """Save config, self-healing the IOS-XE TDLDB persist bug.

        A stale CTRL_MNG_CFG_DB *directory* under bootflash:/.dbpersist makes
        every save (and save-on-reload) fail with
        %TDLDB-3-DBPERSIST_OPERATION_FAILURE ... Is a directory. The fix is
        deleting that directory and saving again. Seen live on the fleet;
        `no logging console` means the syslog signature may only be in the
        log buffer, so an ambiguous save failure is confirmed there before
        remediating.
        """
        logger = console._logger
        pre = dbpersist_log_count(console)
        try:
            output = console.conn.save_config()
        except Exception:
            if not dbpersist_bug_logged(console):
                raise
            output = None
        if output is not None and not DBPERSIST_ERROR.search(output):
            # Inline output can show [OK] while the persist fails async as
            # syslog (seen live) — a NEW DBPERSIST entry means the save lied.
            post = dbpersist_log_count(console)
            logger.debug(f"DBPERSIST log count around save: before={pre} after={post}")
            if pre is None or post is None or post <= pre:
                return output
            logger.warning("Save printed [OK] but a new DBPERSIST failure hit the log — the save did not persist")
        clear_dbpersist_db(console, logger)
        # Zero the baseline so stragglers from the FIRST save's async syslog
        # can't be blamed on the retry (they otherwise land mid-comparison and
        # fail a save that actually persisted).
        clear_log_buffer(console)
        pre = dbpersist_log_count(console)
        output = console.conn.save_config()
        # The bug's syslog arrives seconds AFTER the [OK] — give it a settle
        # window before sampling, or a genuinely failed retry can pass.
        time.sleep(6)
        post = dbpersist_log_count(console)
        logger.debug(f"DBPERSIST log count around retry save (post log-clear): before={pre} after={post}")
        if DBPERSIST_ERROR.search(output) or (pre is not None and post is not None and post > pre):
            evidence = dbpersist_log_lines(console)
            raise RuntimeError(
                f"Config save still failing after deleting the stale DBPERSIST "
                f"directory — new DBPERSIST log: {evidence or 'n/a'} — "
                f"device said: {' '.join(output.split())[-300:]}"
            )
        logger.info("Config saved successfully after DBPERSIST cleanup")
        return output
