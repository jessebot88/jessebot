"""Platform driver seam guards.

Runs with `nautobot-server test nautobot_app_device_bootstrap`. The driver
package is the single source of truth for device classification, pipeline
selection, and console personality — these tests pin the resolution rules
(network_driver lookup with Cisco fallback) and the Cisco classification the
whole fleet depends on.
"""
from types import SimpleNamespace

from django.test import SimpleTestCase

from nautobot_app_device_bootstrap.jobs import console, drivers
from nautobot_app_device_bootstrap.jobs.drivers.cisco_ios import CiscoIosDriver


def _device(role_name=None, network_driver=None):
    role = SimpleNamespace(name=role_name) if role_name is not None else None
    platform = SimpleNamespace(network_driver=network_driver) if network_driver is not None else None
    return SimpleNamespace(role=role, platform=platform)


class DriverResolutionTest(SimpleTestCase):
    def test_cisco_network_drivers_resolve_to_cisco(self):
        for nd in ("cisco_ios", "cisco_xe"):
            self.assertIsInstance(drivers.get_driver(_device(network_driver=nd)), CiscoIosDriver)

    def test_no_platform_falls_back_to_cisco(self):
        # The fleet predates the driver seam — a bare device must still provision.
        self.assertIsInstance(drivers.get_driver(_device()), CiscoIosDriver)

    def test_unknown_network_driver_falls_back_to_cisco(self):
        self.assertIsInstance(drivers.get_driver(_device(network_driver="arista_eos")), CiscoIosDriver)

    def test_pipeline_keys_cover_every_class_every_driver_yields(self):
        for driver in set(drivers.DRIVER_REGISTRY.values()):
            for device_class, key in driver.pipeline_keys.items():
                self.assertEqual(drivers.PIPELINE_KEYS[device_class], key)


class CiscoClassificationTest(SimpleTestCase):
    def classify(self, role_name):
        return drivers.classify_device(_device(role_name=role_name))

    def test_router_roles(self):
        for role in ("Router", "primary-router", "Standalone Router"):
            self.assertEqual(self.classify(role), "router")

    def test_switch_roles(self):
        for role in ("Switch", "Access Switch", "distribution", "access"):
            self.assertEqual(self.classify(role), "switch")

    def test_router_wins_over_switch_keywords(self):
        # Pipeline selection always preferred router; staging now agrees.
        self.assertEqual(self.classify("router-on-a-stick access"), "router")

    def test_unrecognized_and_missing_roles(self):
        self.assertIsNone(self.classify("firewall"))
        self.assertIsNone(drivers.classify_device(_device()))

    def test_pipeline_key_mapping(self):
        driver = drivers.default_driver()
        self.assertEqual(driver.pipeline_key("router"), "pipeline_router")
        self.assertEqual(driver.pipeline_key("switch"), "pipeline_switch")


class ConsoleReexportTest(SimpleTestCase):
    """Steps import the Cisco personality from ..console — keep that surface."""

    def test_prompt_and_dbpersist_names_reexported(self):
        for name in (
            "EXEC_PROMPT",
            "CFG_PROMPT",
            "ANY_PROMPT",
            "DBPERSIST_ERROR",
            "dbpersist_log_count",
            "dbpersist_bug_logged",
            "clear_dbpersist_db",
        ):
            self.assertTrue(hasattr(console, name), f"console.{name} re-export missing")

    def test_console_promote_alias(self):
        self.assertIs(console.Console.promote_to_ios, console.Console.promote)

    def test_default_driver_personality(self):
        driver = drivers.default_driver()
        self.assertEqual(driver.netmiko_device_type, "cisco_ios")
        self.assertEqual(driver.exec_prompt, console.EXEC_PROMPT)
        self.assertEqual(driver.cfg_prompt, console.CFG_PROMPT)
