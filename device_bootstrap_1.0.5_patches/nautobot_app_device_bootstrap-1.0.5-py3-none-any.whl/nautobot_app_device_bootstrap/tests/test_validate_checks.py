"""Validate step: certificate, APN, attach, and config-applied checks.

These verify the later steps' WORK (not just that they ran): a router
certificate on the trustpoint, the APN on profile 1, the modem attached, and
the intended config present in running-config. Parsers are exercised on
realistic device output; the check functions on a scripted fake console with
the Nautobot-side lookups stubbed.
"""
from unittest import mock

from django.test import SimpleTestCase

from nautobot_app_device_bootstrap.jobs.steps import validate as val

from .test_cell_firmware import FakeChild, FakeLogger, _clock


CERTS_ENROLLED = """\
Certificate
  Status: Available
  Certificate Serial Number (hex): 1A2B3C
  Certificate Usage: General Purpose
  Issuer:
    cn=Example Issuing CA
  Subject:
    Name: rtr01.example.net
    hostname=rtr01.example.net
  Validity Date:
    start date: 10:41:12 UTC Feb 26 2026
    end   date: 10:41:12 UTC Feb 26 2028
  Associated Trustpoints: TP-EXAMPLE

CA Certificate
  Status: Available
  Certificate Serial Number (hex): 01
  Certificate Usage: Signature
  Issuer:
    cn=Example Issuing CA
  Associated Trustpoints: TP-EXAMPLE
"""
CERTS_CA_ONLY = CERTS_ENROLLED[CERTS_ENROLLED.index("CA Certificate"):]
CERTS_PENDING = CERTS_ENROLLED.replace("Status: Available\n  Certificate Serial Number (hex): 1A2B3C", "Status: Pending\n  Certificate Serial Number (hex): 1A2B3C")

PROFILE = """\
Profile 1 = ACTIVE*
--------
PDP Type = IPv4
Access Point Name (APN) = example.apn
Authentication = None

Profile 2 = INACTIVE
--------
PDP Type = IPv4
Access Point Name (APN) = other.apn
Authentication = None

  * - Default profile
"""

NETWORK_XE_ATTACHED = """\
Current System Time = Thu Feb 26 10:40:01 2026
Current Service Status = Normal
Current Service = Packet switched
Current Roaming Status = Home
Network Selection Mode = Automatic
Network = Example Wireless
Packet switch domain(PS) state = Attached
Registration state(EMM) = Registered
EMM Sub State = Normal Service
"""
NETWORK_IOS_ATTACHED = """\
Current Service Status = Normal
Current Service = Packet switched
Packet Service = LTE (Attached)
"""
NETWORK_NO_SERVICE = """\
Current System Time = Thu Feb 26 10:40:01 2026
Current Service Status = No service
Current Service = Unknown
Packet switch domain(PS) state = Detached
Registration state(EMM) = Not registered
"""

INTENDED = """\
hostname rtr01
!
ntp server 10.0.0.1
snmp-server community s3cr3t RO
!
interface Loopback0
 ip address 10.1.1.1 255.255.255.255
!
end
"""
RUNNING_COMPLETE = """\
Building configuration...

Current configuration : 1234 bytes
!
version 17.15
hostname rtr01
!
ntp server 10.0.0.1
snmp-server community 7 0822455D0A16 RO
!
interface Loopback0
 ip address 10.1.1.1 255.255.255.255
!
end
"""
RUNNING_MISSING_NTP = RUNNING_COMPLETE.replace("ntp server 10.0.0.1\n", "")


class ShowChild(FakeChild):
    """Answers by command keyword; `outputs` maps keyword -> list of outputs."""

    def __init__(self, outputs):
        super().__init__()
        self.script = {k: list(v) for k, v in outputs.items()}


def _device(driver="cisco_xe"):
    device = mock.Mock()
    device.platform.network_driver = driver
    return device


class ParserTest(SimpleTestCase):
    def test_router_cert_status(self):
        self.assertEqual(val._parse_router_cert_status(CERTS_ENROLLED), "Available")
        self.assertEqual(val._parse_router_cert_status(CERTS_PENDING), "Pending")
        self.assertIsNone(val._parse_router_cert_status(CERTS_CA_ONLY))
        self.assertIsNone(val._parse_router_cert_status(""))

    def test_profile_apn(self):
        self.assertEqual(val._parse_profile_apn(PROFILE), "example.apn")
        self.assertIsNone(val._parse_profile_apn("No profiles configured\n"))

    def test_attach(self):
        self.assertEqual(val._parse_attach(NETWORK_XE_ATTACHED), (True, "Normal"))
        self.assertEqual(val._parse_attach(NETWORK_IOS_ATTACHED), (True, "Normal"))
        self.assertEqual(val._parse_attach(NETWORK_NO_SERVICE), (False, "No service"))
        self.assertEqual(val._parse_attach(""), (False, "unknown"))

    def test_in_pipeline(self):
        self.assertTrue(val._in_pipeline({}, "cert_enroll"))
        self.assertTrue(val._in_pipeline({"pipeline_router": ["staging", "cert_enroll"]}, "cert_enroll"))
        self.assertFalse(val._in_pipeline({"pipeline_router": ["staging"], "pipeline_switch": ["staging"]}, "cert_enroll"))

    def test_parser_os(self):
        self.assertEqual(val._config_parser_os(_device("cisco_xe")), "cisco_ios")
        self.assertEqual(val._config_parser_os(_device("cisco_ios")), "cisco_ios")
        self.assertEqual(val._config_parser_os(object()), "cisco_ios")


class MissingConfigLinesTest(SimpleTestCase):
    def test_complete_running_config_only_differs_on_secrets(self):
        real, secret = val._missing_config_lines(INTENDED, RUNNING_COMPLETE, "cisco_ios")
        self.assertEqual(real, [])
        self.assertEqual(len(secret), 1)
        self.assertIn("snmp-server community", secret[0])

    def test_missing_line_is_reported(self):
        real, _ = val._missing_config_lines(INTENDED, RUNNING_MISSING_NTP, "cisco_ios")
        self.assertEqual(real, ["ntp server 10.0.0.1"])


class CertificateCheckTest(SimpleTestCase):
    def _check(self, output, tp={"name": "TP-EXAMPLE"}):
        verified = []
        with mock.patch.object(val._cert_enroll, "_parse_trustpoint_from_intended", return_value=tp):
            failures = val._check_certificate(ShowChild({"crypto": [output]}), object(), FakeLogger(), verified)
        return failures, verified

    def test_enrolled(self):
        failures, verified = self._check(CERTS_ENROLLED)
        self.assertEqual(failures, [])
        self.assertEqual(verified, ["certificate (TP-EXAMPLE)"])

    def test_ca_only_fails(self):
        failures, _ = self._check(CERTS_CA_ONLY)
        self.assertEqual(len(failures), 1)
        self.assertIn("no router certificate", failures[0])

    def test_pending_fails(self):
        failures, _ = self._check(CERTS_PENDING)
        self.assertIn("status is Pending", failures[0])

    def test_no_trustpoint_in_intended_is_skipped(self):
        failures, verified = self._check(CERTS_CA_ONLY, tp=None)
        self.assertEqual((failures, verified), ([], []))


class ApnAndAttachCheckTest(SimpleTestCase):
    def _patches(self, apn="example.apn"):
        return (
            mock.patch.object(val._cell_fw, "_find_cellular_modules", return_value=[("PIM 1", "P-5GS6-GL", "0/1/0")]),
            mock.patch.object(val._cell_profile, "_resolve_apn", return_value=apn),
        )

    def test_apn_matches(self):
        verified = []
        with self._patches()[0], self._patches()[1]:
            failures = val._check_apn_profile(ShowChild({"profile": [PROFILE]}), object(), {}, FakeLogger(), verified)
        self.assertEqual(failures, [])
        self.assertEqual(verified, ["APN example.apn"])

    def test_apn_mismatch_fails(self):
        with self._patches(apn="wanted.apn")[0], self._patches(apn="wanted.apn")[1]:
            failures = val._check_apn_profile(ShowChild({"profile": [PROFILE]}), object(), {}, FakeLogger())
        self.assertEqual(len(failures), 1)
        self.assertIn("APN is example.apn, expected wanted.apn", failures[0])

    def test_attach_waits_then_passes(self):
        clock = _clock(self, module=val)
        verified = []
        child = ShowChild({"network": [NETWORK_NO_SERVICE, NETWORK_NO_SERVICE, NETWORK_XE_ATTACHED]})
        with self._patches()[0], self._patches()[1]:
            failures = val._check_cell_attached(child, object(), {}, FakeLogger(), verified)
        self.assertEqual(failures, [])
        self.assertEqual(verified, ["modem 0/1/0 attached"])
        self.assertEqual(len(clock.sleeps), 2)

    def test_never_attached_fails_after_window(self):
        _clock(self, module=val)
        child = ShowChild({"network": [NETWORK_NO_SERVICE]})
        with self._patches()[0], self._patches()[1]:
            failures = val._check_cell_attached(child, object(), {}, FakeLogger())
        self.assertEqual(len(failures), 1)
        self.assertIn("not attached after 180s (service status: No service)", failures[0])

    def test_no_apn_configured_skips_both(self):
        with self._patches(apn=None)[0], self._patches(apn=None)[1]:
            self.assertEqual(val._check_apn_profile(ShowChild({}), object(), {}, FakeLogger()), [])
            self.assertEqual(val._check_cell_attached(ShowChild({}), object(), {}, FakeLogger()), [])


class ConfigAppliedCheckTest(SimpleTestCase):
    def _check(self, running, hard=False):
        verified, logger = [], FakeLogger()
        with mock.patch.object(val._config_push, "_resolve_intended_config", return_value=INTENDED), \
                mock.patch.object(val, "_CONFIG_DIFF_HARD", hard):
            failures = val._check_config_applied(
                ShowChild({"running-config": [running]}), _device(), {}, logger, verified
            )
        return failures, verified, logger

    def test_complete_config_passes(self):
        failures, verified, logger = self._check(RUNNING_COMPLETE)
        self.assertEqual(failures, [])
        self.assertEqual(verified, ["config applied"])
        self.assertIn("1 secret-bearing lines not compared", logger.text("info"))

    def test_missing_line_is_advisory_by_default(self):
        failures, verified, logger = self._check(RUNNING_MISSING_NTP)
        self.assertEqual(failures, [])
        self.assertEqual(verified, ["config applied (1 lines missing, advisory)"])
        self.assertIn("ntp server 10.0.0.1", logger.text("warning"))
        self.assertIn("advisory", logger.text("warning"))

    def test_missing_line_fails_when_hard(self):
        failures, _, _ = self._check(RUNNING_MISSING_NTP, hard=True)
        self.assertEqual(len(failures), 1)
        self.assertIn("1 intended line(s) missing", failures[0])
        self.assertIn("ntp server 10.0.0.1", failures[0])

    def test_unavailable_intended_config_is_skipped(self):
        with mock.patch.object(val._config_push, "_resolve_intended_config", side_effect=RuntimeError("no GC")):
            failures = val._check_config_applied(ShowChild({}), _device(), {}, FakeLogger(), [])
        self.assertEqual(failures, [])
