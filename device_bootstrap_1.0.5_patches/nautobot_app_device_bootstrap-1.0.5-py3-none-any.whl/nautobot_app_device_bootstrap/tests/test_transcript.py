"""Console transcript: capture-since-last-take, redaction, clipping, reconnects.

The transcript is what ends up in the job log as the per-step debug entry,
so the invariants that matter are: every registered secret is masked
(including when netmiko's own masking is bypassed), secret-keyword lines are
masked, each take() returns only new traffic, and a reconnected session
inherits the secret list.
"""
from unittest import mock

from django.test import SimpleTestCase

from nautobot_app_device_bootstrap.jobs import console as console_mod
from nautobot_app_device_bootstrap.jobs.console import Transcript


class FakeSessionLog:
    """netmiko SessionLog stand-in: masks no_log values on flush into the buffer."""

    def __init__(self, buffer):
        self.buffer = buffer
        self.no_log = {}
        self.pending = ""

    def write(self, data):
        self.pending += data

    def flush(self):
        data = self.pending
        self.pending = ""
        for hidden in self.no_log.values():
            data = data.replace(hidden, "********")
        self.buffer.write(data.encode())


class FakeConn:
    def __init__(self, buffer):
        self.session_log = FakeSessionLog(buffer)


class TranscriptTest(SimpleTestCase):
    def test_take_returns_only_new_traffic_and_normalises_line_endings(self):
        t = Transcript()
        t.buffer.write(b"rtr01#show version\r\nCisco IOS XE\r\n")
        self.assertEqual(t.take(), "rtr01#show version\nCisco IOS XE\n")
        self.assertEqual(t.take(), "")
        t.buffer.write(b"rtr01#\r")
        self.assertEqual(t.take(), "rtr01#\n")

    def test_boot_noise_is_stripped_so_postgres_accepts_the_entry(self):
        t = Transcript()
        t.buffer.write(
            b"reload\r\nProceed with reload? [confirm]\r\n"
            b"\x00\x00\x1b[2J\x1b[H\x00Initializing Hardware...\r\n"
            b"\x07\x08###\x1b(B\x1bc\r\nPress RETURN to get started.\x7f\r\n\ttabbed\r\n"
        )
        text = t.take()
        self.assertNotIn("\x00", text)
        self.assertNotIn("\x1b", text)
        self.assertNotIn("\x07", text)
        self.assertEqual(
            text,
            "reload\nProceed with reload? [confirm]\nInitializing Hardware...\n###\nPress RETURN to get started.\n\ttabbed\n",
        )

    def test_registered_secret_is_masked_even_without_netmiko(self):
        t = Transcript()
        t.register_secret("Sup3rS3cret!")
        t.buffer.write(b"Password: \r\nSup3rS3cret!\r\nrtr01#\r\n")
        text = t.take()
        self.assertNotIn("Sup3rS3cret!", text)
        self.assertIn("********", text)

    def test_short_values_are_not_registered(self):
        t = Transcript()
        t.register_secret("ab")
        t.register_secret("")
        t.register_secret(None)
        t.buffer.write(b"ab cd\r\n")
        self.assertEqual(t.take(), "ab cd\n")

    def test_secret_keyword_lines_are_masked(self):
        t = Transcript()
        t.buffer.write(
            b"rtr01(config)#enable secret 9 $9$abcdef\r\n"
            b"rtr01(config)#snmp-server community s3cr3t RO\r\n"
            b"rtr01(config)#tacacs server T1\r\n"
            b"rtr01(config-server-tacacs)# key 7 0822455D0A16\r\n"
            b"rtr01(config)#ntp server 10.0.0.1\r\n"
        )
        text = t.take()
        self.assertNotIn("$9$abcdef", text)
        self.assertNotIn("s3cr3t", text)
        self.assertNotIn("0822455D0A16", text)
        self.assertIn("enable secret ********", text)
        self.assertIn("community ********", text)
        self.assertIn("key ********", text)
        self.assertIn("ntp server 10.0.0.1", text)

    def test_attach_seeds_netmiko_no_log_and_later_secrets_propagate(self):
        t = Transcript()
        t.register_secret("first-secret")
        conn1 = FakeConn(t.buffer)
        t.attach(conn1)
        self.assertEqual(conn1.session_log.no_log, {"first-secret": "first-secret"})

        t.register_secret("later-secret")
        self.assertIn("later-secret", conn1.session_log.no_log)

        # A reconnect gets the full list.
        conn2 = FakeConn(t.buffer)
        t.attach(conn2)
        self.assertEqual(set(conn2.session_log.no_log), {"first-secret", "later-secret"})

        # take() flushes every attached session log; netmiko's masking applies.
        conn2.session_log.write("login: first-secret later-secret done\r\n")
        self.assertEqual(t.take(), "login: ******** ******** done\n")

    def test_clip_keeps_the_tail(self):
        text = "x" * 100 + "TAIL"
        clipped = Transcript.clip(text, cap=10)
        self.assertTrue(clipped.startswith("[… 94 earlier characters omitted …]\n"))
        self.assertTrue(clipped.endswith("xxxxxxTAIL"))
        self.assertEqual(Transcript.clip("short", cap=10), "short")


class ConsoleWiringTest(SimpleTestCase):
    def test_console_passes_buffer_to_netmiko_and_attaches(self):
        t = Transcript()
        fake_conn = FakeConn(t.buffer)
        with mock.patch.object(console_mod, "get_settings", return_value={"console_port_base": 3000}), \
                mock.patch.object(console_mod, "ConnectHandler", return_value=fake_conn) as ch:
            c = console_mod.Console({"host": "og1", "port_number": 5}, "u", "p", mock.Mock(), transcript=t)
        kwargs = ch.call_args.kwargs
        self.assertIs(kwargs["session_log"], t.buffer)
        self.assertTrue(kwargs["session_log_record_writes"])
        self.assertIn(fake_conn.session_log, t._session_logs)

        c.register_secret("wire-secret")
        self.assertIn("wire-secret", fake_conn.session_log.no_log)

    def test_console_without_transcript_is_unchanged(self):
        with mock.patch.object(console_mod, "get_settings", return_value={"console_port_base": 3000}), \
                mock.patch.object(console_mod, "ConnectHandler", return_value=mock.Mock(session_log=None)) as ch:
            c = console_mod.Console({"host": "og1", "port_number": 5}, "u", "p", mock.Mock())
        self.assertNotIn("session_log", ch.call_args.kwargs)
        c.register_secret("ignored")  # no-op, must not raise
