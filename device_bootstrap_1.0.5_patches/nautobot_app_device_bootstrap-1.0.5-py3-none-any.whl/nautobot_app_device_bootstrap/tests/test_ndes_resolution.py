"""NDES server location from the trustpoint enrollment URL.

Nothing may key on the word "ndes": the hostname comes from the URL, the IP
from the URL (literal), the exact `ip host` line for that hostname, or the
settings override — in that order. The admin (OTP) URL keeps the enrollment
URL's scheme/host/port and honours the host override for the worker only.
"""
from unittest import mock

from django.test import SimpleTestCase

from nautobot_app_device_bootstrap.jobs.steps import cert_enroll as ce


INTENDED = """\
hostname rtr01
ip host scep01.example.net 10.9.9.10
ip host vrf MGMT scep01.example.net 10.9.9.10
ip host NDES.example.net 10.9.9.20
!
crypto pki trustpoint TP-EXAMPLE
 enrollment url http://scep01.example.net/certsrv/mscep/mscep.dll
 rsakeypair kr_example
!
"""


def _tp(url):
    return {"name": "TP-EXAMPLE", "enrollment_url": url, "vrf": None, "key_label": "kr_example"}


class ResolveNdesTest(SimpleTestCase):
    def setUp(self):
        patcher = mock.patch.object(ce, "_intended_config", return_value=INTENDED)
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_hostname_with_matching_ip_host_line(self):
        ndes = ce.resolve_ndes(object(), {}, _tp("http://scep01.example.net/certsrv/mscep/mscep.dll"))
        self.assertEqual(ndes["host"], "scep01.example.net")
        self.assertEqual(ndes["ip"], "10.9.9.10")
        self.assertEqual(ndes["source"], "intended config ip host")
        self.assertEqual((ndes["scheme"], ndes["port"]), ("http", None))

    def test_hostname_match_is_exact_and_case_insensitive(self):
        ndes = ce.resolve_ndes(object(), {}, _tp("https://ndes.example.net:8443/certsrv/mscep/mscep.dll"))
        self.assertEqual(ndes["ip"], "10.9.9.20")
        self.assertEqual((ndes["scheme"], ndes["port"]), ("https", 8443))

    def test_vrf_form_of_ip_host_counts(self):
        with mock.patch.object(ce, "_intended_config", return_value="ip host vrf MGMT scep02.example.net 10.9.9.30\n"):
            ndes = ce.resolve_ndes(object(), {}, _tp("http://scep02.example.net/certsrv/mscep/mscep.dll"))
        self.assertEqual(ndes["ip"], "10.9.9.30")

    def test_ip_literal_in_url(self):
        ndes = ce.resolve_ndes(object(), {}, _tp("http://10.9.9.40/certsrv/mscep/mscep.dll"))
        self.assertEqual((ndes["host"], ndes["ip"], ndes["source"]), ("10.9.9.40", "10.9.9.40", "enrollment URL"))

    def test_unknown_hostname_without_override_has_no_ip(self):
        ndes = ce.resolve_ndes(object(), {}, _tp("http://other.example.net/certsrv/mscep/mscep.dll"))
        self.assertEqual(ndes["host"], "other.example.net")
        self.assertIsNone(ndes["ip"])
        self.assertIsNone(ndes["source"])

    def test_settings_override_supplies_the_ip(self):
        ndes = ce.resolve_ndes(object(), {"ndes_ip": "10.9.9.50"}, _tp("http://other.example.net/certsrv/mscep/mscep.dll"))
        self.assertEqual((ndes["ip"], ndes["source"]), ("10.9.9.50", "NDES IP override"))
        self.assertEqual(ndes["host"], "other.example.net")  # the device still resolves the URL host

    def test_no_url_falls_back_to_host_override(self):
        ndes = ce.resolve_ndes(object(), {"ndes_host": "ndes.example.net", "ndes_ip": "10.9.9.60"}, _tp(None))
        self.assertEqual((ndes["host"], ndes["ip"]), ("ndes.example.net", "10.9.9.60"))

    def test_no_url_no_override(self):
        ndes = ce.resolve_ndes(object(), {}, _tp(None))
        self.assertEqual((ndes["host"], ndes["ip"]), (None, None))

    def test_legacy_wrapper_returns_ip_only(self):
        with mock.patch.object(ce, "_parse_trustpoint_from_intended", return_value=_tp("http://scep01.example.net/certsrv/mscep/mscep.dll")):
            self.assertEqual(ce._parse_ndes_ip_from_intended(object()), "10.9.9.10")


class AdminUrlTest(SimpleTestCase):
    def test_same_host_scheme_and_port_as_enrollment(self):
        ndes = {"host": "scep01.example.net", "ip": "10.9.9.10", "scheme": "https", "port": 8443}
        self.assertEqual(ce._admin_url(ndes, {}), "https://scep01.example.net:8443/CertSrv/mscep_admin/")

    def test_host_override_replaces_worker_side_host_only(self):
        ndes = {"host": "scep01.example.net", "ip": "10.9.9.10", "scheme": "http", "port": None}
        self.assertEqual(
            ce._admin_url(ndes, {"ndes_host": "ndes-admin.corp.example.net"}),
            "http://ndes-admin.corp.example.net/CertSrv/mscep_admin/",
        )

    def test_falls_back_to_ip(self):
        ndes = {"host": None, "ip": "10.9.9.10", "scheme": "http", "port": None}
        self.assertEqual(ce._admin_url(ndes, {}), "http://10.9.9.10/CertSrv/mscep_admin/")

    def test_nothing_known_raises(self):
        with self.assertRaisesRegex(ValueError, "Cannot determine the NDES admin URL"):
            ce._admin_url({"host": None, "ip": None, "scheme": "http", "port": None}, {})


class PreflightTest(SimpleTestCase):
    def _issues(self, url, settings=None):
        with mock.patch.object(ce, "_intended_config", return_value=INTENDED), \
                mock.patch.object(ce, "_parse_trustpoint_from_intended", return_value=_tp(url)), \
                mock.patch.object(ce, "_parse_loopback0_from_intended", return_value={"ip": "10.1.1.1", "mask": "255.255.255.255", "vrf": None}):
            return ce.preflight(object(), settings or {})

    def test_resolvable_host_passes_the_ndes_check(self):
        issues = self._issues("http://scep01.example.net/certsrv/mscep/mscep.dll")
        self.assertFalse(any("NDES IP" in i or "NDES server" in i for i in issues), issues)

    def test_unresolvable_host_is_reported_with_the_hostname(self):
        issues = self._issues("http://other.example.net/certsrv/mscep/mscep.dll")
        self.assertTrue(any("no 'ip host' line for 'other.example.net'" in i for i in issues), issues)

    def test_override_satisfies_preflight(self):
        issues = self._issues("http://other.example.net/certsrv/mscep/mscep.dll", {"ndes_ip": "10.9.9.50"})
        self.assertFalse(any("NDES IP" in i for i in issues), issues)
