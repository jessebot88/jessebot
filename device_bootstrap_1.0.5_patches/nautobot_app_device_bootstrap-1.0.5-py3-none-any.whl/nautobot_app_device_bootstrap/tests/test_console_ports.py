"""Console-server port name -> port number parsing."""

from django.test import SimpleTestCase

from nautobot_app_device_bootstrap.jobs.console import _parse_port_number


class ParsePortNumberTest(SimpleTestCase):
    """Names are matched on whole words, never on the last letter of a word."""

    def test_named_usb_ports(self):
        for name, expected in (
            ("UPPER", 25), ("lower", 26),
            ("Front Upper USB", 25), ("Front Lower USB", 26), ("Upper USB 2", 25),
        ):
            with self.subTest(name=name):
                self.assertEqual(_parse_port_number(name), expected)

    def test_letter_ports(self):
        for name, expected in (("A", 17), ("USB-A", 17), ("USB B", 18), ("usb-h", 24), ("port1A", 17)):
            with self.subTest(name=name):
                self.assertEqual(_parse_port_number(name), expected)

    def test_word_ending_in_a_port_letter_is_not_a_letter_port(self):
        for name in ("USB", "Front USB"):
            with self.subTest(name=name):
                self.assertIsNone(_parse_port_number(name))

    def test_numbered_ports(self):
        for name, expected in (("1", 1), ("port1", 1), ("Port 12", 12), ("serial0/1", 1), ("ttyS7", 7)):
            with self.subTest(name=name):
                self.assertEqual(_parse_port_number(name), expected)
