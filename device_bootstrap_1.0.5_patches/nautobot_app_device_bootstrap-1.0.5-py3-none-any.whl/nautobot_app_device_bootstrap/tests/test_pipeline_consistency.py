"""Pipeline contract consistency guard.

Runs with `nautobot-server test nautobot_app_device_bootstrap`. Fails loudly if
a step is added or edited in a way that breaks the pipeline contract — a
registered step missing its label, a run()/preflight()/applies_to() with the
wrong signature, or a default pipeline referencing a step that doesn't exist.
"""
from django.conf import settings as django_settings
from django.test import SimpleTestCase

from nautobot_app_device_bootstrap.jobs import steps


class PipelineConsistencyTest(SimpleTestCase):
    def test_registry_is_consistent(self):
        # Raises ValueError listing every problem if the registry has drifted.
        steps.validate_registry()

    def test_registry_and_labels_are_bijective(self):
        self.assertEqual(
            set(steps.STEP_REGISTRY),
            set(steps.STEP_LABELS),
            "STEP_REGISTRY and STEP_LABELS must cover exactly the same steps",
        )

    def test_default_pipelines_reference_real_steps(self):
        cfg = django_settings.PLUGINS_CONFIG["nautobot_app_device_bootstrap"]
        steps.validate_pipeline(cfg["pipeline_router"], "pipeline_router")
        steps.validate_pipeline(cfg["pipeline_switch"], "pipeline_switch")

    def test_every_step_has_a_run(self):
        for name, module in steps.STEP_REGISTRY.items():
            self.assertTrue(
                callable(getattr(module, "run", None)),
                f"step '{name}' must expose a callable run()",
            )

    def test_validate_pipeline_rejects_unknown_step(self):
        with self.assertRaises(ValueError):
            steps.validate_pipeline(["factory_default", "does_not_exist"])

    def test_every_step_has_a_session_status_choice(self):
        # session.status holds the running step's name; a step missing from
        # the choices renders as its raw slug in every status pill.
        from nautobot_app_device_bootstrap.models import BOOTSTRAP_STATUS_CHOICES

        choice_keys = {key for key, _ in BOOTSTRAP_STATUS_CHOICES}
        missing = set(steps.STEP_REGISTRY) - choice_keys
        self.assertFalse(missing, f"steps without a BOOTSTRAP_STATUS_CHOICES entry: {sorted(missing)}")


class ProgressPageStepMapsTest(SimpleTestCase):
    """The progress page keeps its own label/icon/description maps; a step
    missing there renders as its raw name (seen live: 'console_rele…')."""

    def test_every_cisco_step_has_label_icon_and_description(self):
        from nautobot_app_device_bootstrap import views

        for name in steps.STEP_REGISTRY:
            if name.startswith("panos_"):
                continue
            for mapping, what in ((views.STEP_LABELS, "label"), (views.STEP_ICONS, "icon"), (views.STEP_DESCRIPTIONS, "description")):
                self.assertIn(name, mapping, f"step '{name}' has no progress-page {what}")
