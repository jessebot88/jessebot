"""Batch provisioning plumbing guards.

Covers the pieces that don't need a live Celery worker: the shared session
status payload (batch cards and the per-device status API both consume it)
and the job contract the provision view's fan-out relies on (one job per
device carrying a batch_id).
"""
import inspect
from types import SimpleNamespace

from django.test import SimpleTestCase

from nautobot_app_device_bootstrap import views
from nautobot_app_device_bootstrap.jobs.bootstrap import DeviceBootstrapJob


def _session(status, steps_done=(), device_class="switch"):
    return SimpleNamespace(
        status=status,
        device_type_class=device_class,
        steps=[{"name": n, "status": s, "message": ""} for n, s in steps_done],
        device=SimpleNamespace(role=SimpleNamespace(name="Access Switch"), platform=None),
        error_message="",
        get_status_display=lambda: status,
        # a live job behind the session; the payload reports "failed" when the
        # job has ended (or is missing) before the pipeline finished
        job_result=SimpleNamespace(status="RUNNING"),
    )


# Steps without applies_to() so filter_pipeline passes a mock device through.
SETTINGS = {
    "pipeline_router": ["factory_default", "staging", "config_push"],
    "pipeline_switch": ["factory_default", "staging", "config_push"],
}


class SessionStatusPayloadTest(SimpleTestCase):
    def test_running_session(self):
        session = _session("staging", steps_done=[("factory_default", "complete")])
        payload = views._session_status_payload(session, SETTINGS)
        self.assertEqual(payload["overall"], "running")
        self.assertTrue(payload["is_active"])
        self.assertEqual(payload["completed_count"], 1)
        self.assertEqual(payload["total_steps"], 3)
        self.assertEqual(
            [s["status"] for s in payload["steps"]], ["complete", "running", "pending"]
        )

    def test_complete_session_pins_100_percent(self):
        session = _session(
            "complete",
            steps_done=[("factory_default", "complete"), ("staging", "complete"), ("config_push", "complete")],
        )
        payload = views._session_status_payload(session, SETTINGS)
        self.assertEqual(payload["overall"], "complete")
        self.assertFalse(payload["is_active"])
        self.assertEqual(payload["progress_pct"], 100)

    def test_failed_session_marks_rest_skipped(self):
        session = _session(
            "failed",
            steps_done=[("factory_default", "complete"), ("staging", "failed")],
        )
        session.error_message = "Preflight blocked provisioning"
        payload = views._session_status_payload(session, SETTINGS)
        self.assertEqual(payload["overall"], "failed")
        self.assertFalse(payload["is_active"])
        self.assertEqual(
            [s["status"] for s in payload["steps"]], ["complete", "failed", "skipped"]
        )
        self.assertEqual(payload["error_message"], "Preflight blocked provisioning")

    def test_pending_session_is_active(self):
        payload = views._session_status_payload(_session("pending"), SETTINGS)
        self.assertEqual(payload["overall"], "pending")
        self.assertTrue(payload["is_active"])


class BatchJobContractTest(SimpleTestCase):
    def test_run_accepts_batch_id(self):
        params = inspect.signature(DeviceBootstrapJob.run).parameters
        self.assertIn("batch_id", params)
        self.assertEqual(params["batch_id"].default, "")

    def test_batch_id_var_is_optional(self):
        var = DeviceBootstrapJob._get_vars()["batch_id"]
        self.assertFalse(var.field_attrs.get("required", True))
