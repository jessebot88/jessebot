import os

from nautobot.apps import NautobotAppConfig

__version__ = "1.0.5"


class NautobotAppDeviceBootstrapConfig(NautobotAppConfig):
    name = "nautobot_app_device_bootstrap"
    verbose_name = "Device Provisioning"
    version = __version__
    author = ""
    description = "Provision routers and switches via OpenGear console servers."
    base_url = "nautobot-app-device-bootstrap"
    docs_view_name = "plugins:nautobot_app_device_bootstrap:docs"
    required_settings = []
    default_settings = {
        # Pipelines — one reload, placed after os_image + license so a single
        # reboot activates both the new image and the license boot level
        # before certs/config (crypto lines are rejected without the license).
        "pipeline_router": [
            "factory_default", "staging", "serial_verify", "connectivity",
            "time_sync", "os_image", "license", "reload", "connectivity",
            "cell_firmware", "cell_firmware_reset", "connectivity", "cert_enroll", "staging_cleanup",
            "cell_profile", "config_push", "validate", "console_release",
        ],
        "pipeline_switch": [
            "factory_default", "staging", "serial_verify", "time_sync",
            "os_image", "license", "reload",
            "staging_cleanup", "config_push", "validate", "console_release",
        ],
        # Staging network
        "console_port_base": int(os.getenv("BOOTSTRAP_CONSOLE_PORT_BASE", "3000")),
        # Batch provisioning — dedicated job queue name; blank = default queue
        "provisioning_queue": os.getenv("BOOTSTRAP_PROVISIONING_QUEUE", ""),
        "domain_name": os.getenv("BOOTSTRAP_DOMAIN_NAME", "example.net"),
        "vrf_name": os.getenv("BOOTSTRAP_VRF_NAME", "MGMT"),
        "vrf_rd": os.getenv("BOOTSTRAP_VRF_RD", "65000:100"),
        "staging_gateway": os.getenv("BOOTSTRAP_STAGING_GATEWAY", "192.0.2.1"),
        "mgmt_vlan": int(os.getenv("BOOTSTRAP_MGMT_VLAN", "1")),
        # Throwaway secret used only until config_push installs the real one.
        # Newer IOS-XE setup dialogs enforce a strength policy: 10-32 chars,
        # at least one upper/lower/digit, must not contain "cisco".
        "factory_default_enable_secret": os.getenv("BOOTSTRAP_ENABLE_SECRET", "Bootstrap-Temp1"),
        # Safety — factory_default is destructive. Refuse to provision any device
        # whose status.name is not in this list. Override per-env via env var:
        # BOOTSTRAP_ALLOWED_STATUSES="Staging,Planned,Inventory"
        "allowed_provisioning_statuses": [
            s.strip() for s in os.getenv(
                "BOOTSTRAP_ALLOWED_STATUSES", "Staging,Planned,Inventory"
            ).split(",") if s.strip()
        ],
        # NDES — secrets group name, rest comes from intended config
        "ndes_secrets_group": os.getenv("BOOTSTRAP_NDES_SECRETS_GROUP", "NDES_Credentials"),
        # Local admin fallback used after reload when AAA+TACACS is in the intended
        # config and the device can't reach TACACS yet (WAN/DMVPN not up). Requires
        # the named SecretsGroup to have Generic/username + Generic/password.
        "local_admin_secrets_group": os.getenv("BOOTSTRAP_LOCAL_ADMIN_SECRETS_GROUP", "LocalAdmin_Credentials"),
        # Post-provision — status applied by console_release after a fully
        # successful run (also keeps the allowed-statuses gate from letting a
        # finished device be re-provisioned). Empty string disables.
        "post_provision_status": os.getenv("BOOTSTRAP_POST_PROVISION_STATUS", "Active"),
        # File server — name of the ExternalIntegration used as the default on
        # the job form and the implicit choice on the per-device preflight page.
        "default_file_server_ei_name": os.getenv("BOOTSTRAP_DEFAULT_FILE_SERVER_EI", "Firmware Webserver"),
        # Cellular firmware — only needed if you have cellular devices.
        # Base URL + credentials now come from the file-server ExternalIntegration
        # selected on the job form (default: "Firmware Webserver"). Only filenames remain here.
        "cell_firmware_cwe": os.getenv("BOOTSTRAP_CELL_FW_CWE", ""),
        "cell_firmware_firstnet_nvu": os.getenv("BOOTSTRAP_CELL_FW_FIRSTNET_NVU", ""),
        "cell_firmware_verizon_nvu": os.getenv("BOOTSTRAP_CELL_FW_VERIZON_NVU", ""),
        # Cellular APN
        # APNs are carrier/deployment-specific — set via env or PLUGINS_CONFIG.
        "cell_apn_firstnet": os.getenv("BOOTSTRAP_CELL_APN_FIRSTNET", ""),
        "cell_apn_verizon": os.getenv("BOOTSTRAP_CELL_APN_VERIZON", ""),
        "cell_apn_reboot_wait": int(os.getenv("BOOTSTRAP_CELL_APN_REBOOT_WAIT", "360")),
    }
    searchable_models = ["BootstrapSession"]

    def ready(self):
        super().ready()


config = NautobotAppDeviceBootstrapConfig
