from django.conf import settings as django_settings
from django.core.exceptions import ValidationError
from django.db import models
from nautobot.apps.models import BaseModel, PrimaryModel, extras_features


# Session status is either a lifecycle state or the currently-running step
# name — every registered step needs an entry here or get_status_display
# falls back to the raw slug ("os_image") in the UI.
BOOTSTRAP_STATUS_CHOICES = (
    ("pending", "Pending"),
    ("factory_default", "Factory Default"),
    ("staging", "Staging Config"),
    ("serial_verify", "Serial Verification"),
    ("connectivity", "Connectivity Check"),
    ("time_sync", "Time Sync"),
    ("os_image", "OS Image"),
    ("license", "License Boot Level"),
    ("reload", "Reload"),
    ("cell_firmware", "Cellular Firmware"),
    ("cell_firmware_reset", "Cellular Firmware Reset"),
    ("cert_enroll", "Certificate Enrollment"),
    ("staging_cleanup", "Staging Cleanup"),
    ("cell_profile", "APN Profile"),
    ("config_push", "Config Push"),
    ("validate", "Validation"),
    ("console_release", "Release Console Port"),
    ("complete", "Complete"),
    ("failed", "Failed"),
)

DEVICE_TYPE_CHOICES = (
    ("router", "Router"),
    ("switch", "Switch"),
)


@extras_features("graphql")
class BootstrapSession(BaseModel):
    device = models.ForeignKey(to="dcim.Device", on_delete=models.CASCADE, related_name="bootstrap_sessions")
    status = models.CharField(max_length=24, choices=BOOTSTRAP_STATUS_CHOICES, default="pending")
    device_type_class = models.CharField(max_length=10, choices=DEVICE_TYPE_CHOICES, default="router")
    console_server = models.ForeignKey(
        to="dcim.Device", on_delete=models.SET_NULL, null=True, blank=True, related_name="+"
    )
    console_port_number = models.IntegerField(null=True, blank=True)
    # Multi-device submits enqueue one job per device sharing a batch_id; the
    # batch page groups sessions by it. job_result links back to the run's
    # native Nautobot job (durable logs, cancel, and liveness for the
    # duplicate-provisioning guard).
    batch_id = models.UUIDField(null=True, blank=True, db_index=True)
    job_result = models.ForeignKey(
        to="extras.JobResult", on_delete=models.SET_NULL, null=True, blank=True, related_name="+"
    )
    staging_ip = models.CharField(max_length=64, blank=True)
    steps = models.JSONField(default=list, blank=True)
    started_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    error_message = models.TextField(blank=True)

    natural_key_field_names = ["id"]

    class Meta:
        verbose_name = "Provisioning Session"
        verbose_name_plural = "Provisioning Sessions"
        ordering = ["-started_at"]
        indexes = [
            models.Index(fields=["device", "-started_at"]),
            models.Index(fields=["status"]),
        ]

    def __str__(self):
        return f"{self.device.name} - {self.get_status_display()} ({self.started_at:%Y-%m-%d %H:%M})"

    def get_absolute_url(self):
        from django.urls import reverse

        return reverse("plugins:nautobot_app_device_bootstrap:bootstrapsession", args=[self.pk])


@extras_features("graphql")
class BootstrapSettings(PrimaryModel):
    """Singleton app settings, editable in the GUI.

    Seeded once from PLUGINS_CONFIG (which keeps its env-var defaults purely
    as first-boot seed values) via load(); after that the database row is the
    single source of truth. PrimaryModel base = full Nautobot citizenship:
    edits land in the object change log. Secrets are never stored here —
    credential fields are references to SecretsGroups (the one deliberate
    exception is the throwaway factory-default enable secret).
    """

    # Pipelines — ordered step lists validated against STEP_REGISTRY on save
    pipeline_router = models.JSONField(default=list, blank=True)
    pipeline_switch = models.JSONField(default=list, blank=True)

    # Console access
    console_port_base = models.PositiveIntegerField(
        default=3000, help_text="OpenGear base TCP port; serial port N is reached at base + N."
    )

    # Batch provisioning
    provisioning_queue = models.ForeignKey(
        to="extras.JobQueue",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="+",
        help_text=(
            "Job queue provisioning jobs are dispatched to. Empty = the default queue. "
            "A dedicated queue with its own worker (e.g. celery worker -Q provisioning -c 4) caps how "
            "many devices provision in parallel and keeps hour-long console jobs from starving other jobs. "
            "The queue must have a worker listening, or jobs will sit pending."
        ),
    )

    # Staging network
    domain_name = models.CharField(max_length=253, blank=True)
    vrf_name = models.CharField(max_length=64, blank=True, verbose_name="Staging VRF name")
    vrf_rd = models.CharField(max_length=64, blank=True, verbose_name="Staging VRF route distinguisher")
    staging_gateway = models.CharField(max_length=64, blank=True)
    mgmt_vlan = models.PositiveIntegerField(default=1, verbose_name="Switch staging VLAN")
    connectivity_window = models.PositiveIntegerField(
        default=600, help_text="Seconds to wait for gateway reachability after staging/reload."
    )

    # Provisioning policy
    factory_default_enable_secret = models.CharField(
        max_length=64,
        blank=True,
        help_text=(
            "THROWAWAY value, stored in plain text — do NOT put a real or production secret here. "
            "Used only to get through the factory setup dialog; the config push replaces it with the "
            "real enable secret from the intended config. Newer IOS-XE enforces: 10-32 chars, "
            "upper+lower+digit, must not contain 'cisco'."
        ),
    )
    allowed_provisioning_statuses = models.ManyToManyField(
        to="extras.Status",
        blank=True,
        related_name="+",
        help_text="Only devices in one of these statuses can be provisioned (factory default is destructive).",
    )
    post_provision_status = models.ForeignKey(
        to="extras.Status",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="+",
        help_text="Status applied after a fully successful run. Empty disables.",
    )

    # File server
    default_file_server = models.ForeignKey(
        to="extras.ExternalIntegration",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="+",
        help_text="Default file server for OS images and cellular firmware.",
    )

    # NDES / certificate enrollment
    ndes_secrets_group = models.ForeignKey(
        to="extras.SecretsGroup",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="+",
        verbose_name="NDES credentials",
    )
    ndes_host = models.CharField(max_length=253, blank=True, help_text="Optional override; normally parsed from intended config.")
    ndes_ip = models.CharField(max_length=64, blank=True, help_text="Optional override; normally parsed from intended config.")
    local_admin_secrets_group = models.ForeignKey(
        to="extras.SecretsGroup",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="+",
        verbose_name="Local admin credentials",
        help_text="Fallback console login if a reload lands on an AAA prompt before TACACS is reachable.",
    )

    # Cellular
    cell_firmware_cwe = models.CharField(max_length=255, blank=True, verbose_name="Modem CWE firmware filename")
    cell_firmware_firstnet_nvu = models.CharField(max_length=255, blank=True, verbose_name="FirstNet NVU filename")
    cell_firmware_verizon_nvu = models.CharField(max_length=255, blank=True, verbose_name="Verizon NVU filename")
    cell_apn_firstnet = models.CharField(max_length=100, blank=True, verbose_name="FirstNet APN")
    cell_apn_verizon = models.CharField(max_length=100, blank=True, verbose_name="Verizon APN")
    cell_apn_reboot_wait = models.PositiveIntegerField(
        default=360, help_text="Seconds to wait for the modem to reboot after the APN profile is applied."
    )

    natural_key_field_names = ["id"]

    class Meta:
        verbose_name = "Provisioning Settings"
        verbose_name_plural = "Provisioning Settings"

    def __str__(self):
        return "Provisioning Settings"

    def clean(self):
        super().clean()
        if not self.present_in_database and BootstrapSettings.objects.exists():
            raise ValidationError("Provisioning settings already exist — edit the existing entry.")
        # Lazy import: models must not import the jobs package at module load.
        from nautobot_app_device_bootstrap.jobs import steps as step_registry

        for field, pipeline in (("pipeline_router", self.pipeline_router), ("pipeline_switch", self.pipeline_switch)):
            try:
                step_registry.validate_pipeline(pipeline, field)
            except ValueError as e:
                raise ValidationError({field: str(e)})

    def get_absolute_url(self):
        from django.urls import reverse

        return reverse("plugins:nautobot_app_device_bootstrap:bootstrap_settings")

    @classmethod
    def load(cls):
        """Return the singleton, creating it from PLUGINS_CONFIG on first use."""
        obj = cls.objects.first()
        if obj is not None:
            return obj

        cfg = django_settings.PLUGINS_CONFIG["nautobot_app_device_bootstrap"]
        from nautobot.extras.models import ExternalIntegration, JobQueue, SecretsGroup, Status

        obj = cls(
            pipeline_router=list(cfg.get("pipeline_router", [])),
            pipeline_switch=list(cfg.get("pipeline_switch", [])),
            console_port_base=int(cfg.get("console_port_base", 3000)),
            provisioning_queue=JobQueue.objects.filter(name=cfg.get("provisioning_queue", "")).first(),
            domain_name=cfg.get("domain_name", ""),
            vrf_name=cfg.get("vrf_name", ""),
            vrf_rd=cfg.get("vrf_rd", ""),
            staging_gateway=cfg.get("staging_gateway", ""),
            mgmt_vlan=int(cfg.get("mgmt_vlan") or 1),
            connectivity_window=int(cfg.get("connectivity_window", 600)),
            factory_default_enable_secret=cfg.get("factory_default_enable_secret", ""),
            ndes_host=cfg.get("ndes_host", ""),
            ndes_ip=cfg.get("ndes_ip", ""),
            cell_firmware_cwe=cfg.get("cell_firmware_cwe", ""),
            cell_firmware_firstnet_nvu=cfg.get("cell_firmware_firstnet_nvu", ""),
            cell_firmware_verizon_nvu=cfg.get("cell_firmware_verizon_nvu", ""),
            cell_apn_firstnet=cfg.get("cell_apn_firstnet", ""),
            cell_apn_verizon=cfg.get("cell_apn_verizon", ""),
            cell_apn_reboot_wait=int(cfg.get("cell_apn_reboot_wait", 360)),
            post_provision_status=Status.objects.filter(name=cfg.get("post_provision_status", "")).first(),
            default_file_server=ExternalIntegration.objects.filter(
                name=cfg.get("default_file_server_ei_name", "")
            ).first(),
            ndes_secrets_group=SecretsGroup.objects.filter(name=cfg.get("ndes_secrets_group", "")).first(),
            local_admin_secrets_group=SecretsGroup.objects.filter(
                name=cfg.get("local_admin_secrets_group", "")
            ).first(),
        )
        obj.save()
        obj.allowed_provisioning_statuses.set(
            Status.objects.filter(name__in=cfg.get("allowed_provisioning_statuses", []))
        )
        return obj
