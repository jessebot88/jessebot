"""Runtime settings accessor.

`get_settings()` returns a plain dict with the SAME keys the old
PLUGINS_CONFIG dict had, sourced from the BootstrapSettings singleton
(seeded from PLUGINS_CONFIG on first access). Consumers — the job, views,
console layer, and every pipeline step — keep working on a dict and never
touch the model, so a settings-storage change stays contained here.
"""


def get_settings():
    from nautobot_app_device_bootstrap.models import BootstrapSettings

    obj = BootstrapSettings.load()
    return {
        "pipeline_router": list(obj.pipeline_router or []),
        "pipeline_switch": list(obj.pipeline_switch or []),
        "console_port_base": obj.console_port_base,
        "provisioning_queue": obj.provisioning_queue.name if obj.provisioning_queue else "",
        "domain_name": obj.domain_name,
        "vrf_name": obj.vrf_name,
        "vrf_rd": obj.vrf_rd,
        "staging_gateway": obj.staging_gateway,
        "mgmt_vlan": obj.mgmt_vlan,
        "connectivity_window": obj.connectivity_window,
        "factory_default_enable_secret": obj.factory_default_enable_secret,
        "allowed_provisioning_statuses": list(
            obj.allowed_provisioning_statuses.values_list("name", flat=True)
        ),
        "post_provision_status": obj.post_provision_status.name if obj.post_provision_status else "",
        "default_file_server_ei_name": obj.default_file_server.name if obj.default_file_server else "",
        "ndes_secrets_group": obj.ndes_secrets_group.name if obj.ndes_secrets_group else "",
        "ndes_host": obj.ndes_host,
        "ndes_ip": obj.ndes_ip,
        "local_admin_secrets_group": (
            obj.local_admin_secrets_group.name if obj.local_admin_secrets_group else ""
        ),
        "cell_firmware_cwe": obj.cell_firmware_cwe,
        "cell_firmware_firstnet_nvu": obj.cell_firmware_firstnet_nvu,
        "cell_firmware_verizon_nvu": obj.cell_firmware_verizon_nvu,
        "cell_apn_firstnet": obj.cell_apn_firstnet,
        "cell_apn_verizon": obj.cell_apn_verizon,
        "cell_apn_reboot_wait": obj.cell_apn_reboot_wait,
    }
