"""Check network connectivity through the staging VRF (global table on switches).

Runs twice in the router pipeline: after staging and again after the reload.
Post-reload the device can take minutes to bring interfaces up, re-acquire
DHCP, and converge routing, so this polls for a window rather than judging a
single ping.
"""

from .staging import _poll_connectivity, is_switch_role


def run(child, device, session, settings, logger):
    """Poll the staging gateway until it answers. Raises when the window expires."""
    gateway = settings["staging_gateway"]
    window = int(settings.get("connectivity_window", 600))

    logger.info(
        f"Pinging gateway ({gateway}) — allowing up to {window // 60} min for the network to settle"
    )
    # Switch staging has no VRF — its SVI is in the global routing table.
    _poll_connectivity(
        child, gateway, settings, logger,
        window=window,
        use_vrf=not is_switch_role(device),
    )
    return f"Gateway {gateway} reachable"
