"""Push full intended config from Golden Config."""

import re

from django.conf import settings as django_settings

# Match the DEVICE's parser-error phrases, not a bare "% Word". Config now
# includes banners/MOTDs, whose prose (echoed back during the push) can start
# with "% Unknown ...", "% Error ..." etc. — a keyword match would false-abort
# on the banner text. These full phrases don't occur in normal banner prose.
IOS_ERROR_PATTERN = re.compile(
    r"% ?(?:Invalid input detected|Incomplete command|Ambiguous command|"
    r"Unrecognized command|Unknown command|Bad mask|Overlaps with|"
    r"Error (?:opening|decoding|in)|Cannot )",
    re.IGNORECASE,
)

# Benign %-prefixed NOTICES that are informational, not command rejections.
# The classic one: HSECK9 / throughput license changes reply
# "% use 'write' command to disable 'hseck9' license on next boot" — the
# command WAS accepted; it just takes effect on the next reload (which happens
# when the gear is powered down for install). These must never abort the push.
_BENIGN_NOTICE = re.compile(
    r"use 'write' command|on next (?:boot|reload)|will take effect|"
    r"takes effect (?:after|on)|change on next reload|please (?:save|write)|"
    r"reboot (?:the )?(?:router|device|system)",
    re.IGNORECASE,
)


def _scan_for_error(output):
    """Return (culprit_command, device_error_line) for the FIRST genuine IOS
    rejection in the output, or None. Line-accurate: reports the line that
    actually matched — not merely the first '%' line — and skips benign
    informational notices."""
    out_lines = output.splitlines()
    for i, line in enumerate(out_lines):
        if IOS_ERROR_PATTERN.search(line) and not _BENIGN_NOTICE.search(line):
            culprit = "(unknown)"
            for j in range(i - 1, -1, -1):
                candidate = out_lines[j].strip()
                # Skip the device's '^' marker line and bare prompts — the
                # culprit is the echoed COMMAND, not the error decoration.
                if not candidate or candidate.strip("^ ") == "" or candidate.endswith(("#", ">")):
                    continue
                culprit = _redact_line(candidate)
                break
            return culprit, line.strip()
    return None


def _error_context(output, before=8, after=2):
    """Redacted excerpt of device output around the first genuine rejection,
    so the log shows the config the device was chewing on — not just the
    error line."""
    out_lines = output.splitlines()
    for i, line in enumerate(out_lines):
        if IOS_ERROR_PATTERN.search(line) and not _BENIGN_NOTICE.search(line):
            lo, hi = max(0, i - before), min(len(out_lines), i + after + 1)
            return "\n".join(_redact_line(l) for l in out_lines[lo:hi])
    return ""

# Now that post-processing renders real secrets into the pushed config, a line
# echoed into a log/exception could leak one. Mask the value after common
# secret-bearing keywords before a line is ever logged. Over-masking a
# non-secret (e.g. a key-chain name) is harmless.
_SECRET_KEYWORD_RE = re.compile(
    r"(?i)\b(password|secret|key-string|key|community|passphrase|pre-shared-key)\b\s+\S.*$"
)


def _redact_line(line):
    """Mask the value trailing a secret keyword so config lines are log-safe."""
    return _SECRET_KEYWORD_RE.sub(lambda m: f"{m.group(1)} ********", line)

# get_config_postprocessing() returns error text (not an exception) when it
# can't render — these prefixes flag those so we fail instead of pushing the
# error string as config.
_POSTPROCESS_ERROR_PREFIXES = (
    "Found an error rendering",
    "Generation of intended configurations postprocessing",
    "No intended configuration is available",
)


def _resolve_intended_config(device, settings, logger):
    """Return the config to push.

    When Golden Config post-processing is enabled, render it (this resolves
    `render_secrets` placeholders so secrets are pushed as real values instead
    of literal Jinja). Otherwise use the stored intended config as-is.
    """
    from nautobot_golden_config.models import GoldenConfig

    try:
        gc = GoldenConfig.objects.get(device=device)
    except GoldenConfig.DoesNotExist:
        raise ValueError(f"No Golden Config record found for {device.name} — run intended config generation first")

    if not gc.intended_config:
        raise ValueError(f"Golden Config record exists but intended config is empty for {device.name}")

    gc_cfg = django_settings.PLUGINS_CONFIG.get("nautobot_golden_config", {})
    if not gc_cfg.get("enable_postprocessing"):
        logger.info("Pulling intended config from Golden Config (post-processing disabled)")
        return gc.intended_config

    from django.http import HttpRequest
    from nautobot_golden_config.utilities.config_postprocessing import get_config_postprocessing

    user = settings.get("job_user")
    if user is None:
        # Secrets can't be rendered without a user to authorize them; refuse
        # rather than fall back to pushing unrendered placeholders.
        raise ValueError(
            "Golden Config post-processing is enabled but no job user is available to "
            "render secrets — cannot safely push config"
        )
    request = HttpRequest()
    request.user = user

    logger.info("Rendering intended config with Golden Config post-processing (secrets)")
    rendered = get_config_postprocessing(gc, request)
    if not rendered or rendered.startswith(_POSTPROCESS_ERROR_PREFIXES):
        raise ValueError(f"Golden Config post-processing failed for {device.name}: {rendered}")
    return rendered


# Chunk size for the push. Chunks split ONLY at top-level block boundaries,
# so a chunk edge can never land inside an interface/controller/banner block.
_CHUNK_MAX_LINES = 150


def _split_top_level_blocks(lines):
    """Group config lines into top-level blocks: a column-0 command plus its
    indented children. Separators ('!', blank) stay attached to the block
    they follow. Banner blocks consume their multi-line content through the
    closing delimiter — banner prose can start at column 0, so without this
    a banner line would be mistaken for a new top-level command."""
    blocks = []
    current = []
    banner_delim = None
    for line in lines:
        if banner_delim is not None:
            current.append(line)
            if banner_delim in line:
                banner_delim = None
            continue
        if line.startswith((" ", "\t")) or not line.strip() or line.startswith("!"):
            current.append(line)
            continue
        if current:
            blocks.append(current)
        current = [line]
        parts = line.split()
        if parts[0] == "banner" and len(parts) >= 3:
            banner_delim = parts[2]
    if current:
        blocks.append(current)
    return blocks


def _chunk_blocks(blocks, max_lines=_CHUNK_MAX_LINES):
    """Pack whole blocks into chunks of roughly max_lines. A single oversized
    block becomes its own chunk rather than being split."""
    chunks = []
    cur = []
    for block in blocks:
        if cur and len(cur) + len(block) > max_lines:
            chunks.append(cur)
            cur = []
        cur.extend(block)
    if cur:
        chunks.append(cur)
    return chunks


def run(child, device, session, settings, logger):
    """Fetch intended config from Golden Config and push it line-by-line."""
    intended = _resolve_intended_config(device, settings, logger)

    # Push the config VERBATIM — do NOT filter interior blank/'!' lines. Inside
    # a `banner`/`motd` block those are literal content, and stripping them
    # corrupts the banner. Outside a banner they are harmless no-ops in config
    # mode. Only a trailing standalone `end` is removed (it would exit config
    # mode); a bare `end` mid-config never occurs in a full intended config.
    lines = [raw.rstrip() for raw in intended.splitlines()]
    while lines and lines[-1].strip() in ("", "end"):
        lines.pop()

    # Chunked send: same lines, same order, nothing filtered — chunking only
    # decides how much goes into each send_config_set call, so a failure is
    # attributable to a known line range instead of "somewhere in 900 lines".
    chunks = _chunk_blocks(_split_top_level_blocks(lines))
    total = len(lines)
    logger.info(f"Pushing {total} lines of config in {len(chunks)} chunks")

    sent = 0
    for n, chunk in enumerate(chunks, 1):
        first, last = sent + 1, sent + len(chunk)

        # cmd_verify=False: banners put IOS into multi-line text-entry mode
        # where lines don't echo a config prompt until the closing delimiter,
        # so per-line echo verification would hang. Timing-based send handles
        # banners (and any other interactive config) the way a human paste
        # does. Errors are caught by scanning the combined output below.
        read_timeout = max(60, len(chunk) * 2)
        try:
            output = child.send_config_set(chunk, cmd_verify=False, read_timeout=read_timeout)
        except Exception as e:
            logger.error(
                f"Console send failed in chunk {n}/{len(chunks)} — intended lines "
                f"{first}-{last}, starting at '{_redact_line(chunk[0])}': {e}"
            )
            raise RuntimeError(
                f"Config push died in intended lines {first}-{last} "
                f"(chunk starts at '{_redact_line(chunk[0])}'): {e}"
            ) from e

        error = _scan_for_error(output)
        if error:
            culprit, err_line = error
            context = _error_context(output)
            if context:
                logger.error(f"Device output around the rejection:\n{context}")
            raise RuntimeError(
                f"Config push rejected near '{culprit}' (intended lines {first}-{last}) — "
                f"device said: {err_line}"
            )

        sent += len(chunk)
        logger.info(f"Pushed lines {first}-{last} of {total} — accepted")

    child.drain(quiet=0.3, max_wait=3)  # clear any post-config %SYS syslog before netmiko re-detects the prompt
    child.save_config()
    logger.info(f"Full config pushed ({total} lines) and saved to NVRAM")
    return f"{total} lines pushed in {len(chunks)} chunk(s), saved to NVRAM"
