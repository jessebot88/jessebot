"""Step registry for the bootstrap pipeline.

Each step module exposes a run(child, device, session, settings, logger) function.
Teams can add custom steps by adding a module here and registering it in STEP_REGISTRY.
"""

from . import (
    cell_firmware,
    cell_firmware_reset,
    cell_profile,
    cert_enroll,
    config_push,
    connectivity,
    console_release,
    factory_default,
    license,
    os_image,
    reload,
    serial_verify,
    staging,
    staging_cleanup,
    time_sync,
    validate,
)

STEP_REGISTRY = {
    "factory_default": factory_default,
    "staging": staging,
    "serial_verify": serial_verify,
    "connectivity": connectivity,
    "time_sync": time_sync,
    "os_image": os_image,
    "license": license,
    "cell_firmware": cell_firmware,
    "cell_firmware_reset": cell_firmware_reset,
    "cert_enroll": cert_enroll,
    "staging_cleanup": staging_cleanup,
    "cell_profile": cell_profile,
    "config_push": config_push,
    "reload": reload,
    "validate": validate,
    "console_release": console_release,
}

STEP_LABELS = {
    "factory_default": "Factory Default",
    "staging": "Staging Config",
    "serial_verify": "Serial Verification",
    "connectivity": "Connectivity Check",
    "time_sync": "Time Sync",
    "os_image": "OS Image",
    "license": "License Boot Level",
    "cell_firmware": "Cellular Firmware",
    "cell_firmware_reset": "Cellular Firmware Reset",
    "cert_enroll": "Certificate Enrollment",
    "staging_cleanup": "Staging Cleanup",
    "cell_profile": "APN Profile",
    "config_push": "Config Push",
    "reload": "Reload",
    "validate": "Validation",
    "console_release": "Release Console Port",
}


# The contract every step module must satisfy. run() is required; preflight()
# and applies_to() are optional but, when present, must match these signatures.
_STEP_CONTRACT = {
    "run": ("child", "device", "session", "settings", "logger"),
    "preflight": ("device", "settings"),
    "applies_to": ("device", "settings"),
}


def validate_registry():
    """Assert the step registry is internally consistent.

    Guards against drift as steps are added/edited: every registered step must
    have a label and vice versa, every module must expose a run() with the
    exact contract signature, and any preflight()/applies_to() must match too.
    Raises ValueError listing every problem found (not just the first).
    """
    import inspect

    problems = []

    reg, lbl = set(STEP_REGISTRY), set(STEP_LABELS)
    for name in sorted(reg - lbl):
        problems.append(f"step '{name}' is in STEP_REGISTRY but has no STEP_LABELS entry")
    for name in sorted(lbl - reg):
        problems.append(f"label '{name}' is in STEP_LABELS but not STEP_REGISTRY")

    for name, module in STEP_REGISTRY.items():
        for func_name, expected_params in _STEP_CONTRACT.items():
            func = getattr(module, func_name, None)
            required = func_name == "run"
            if func is None:
                if required:
                    problems.append(f"step '{name}' is missing required {func_name}()")
                continue
            if not callable(func):
                problems.append(f"step '{name}'.{func_name} is not callable")
                continue
            params = tuple(inspect.signature(func).parameters)
            if params != expected_params:
                problems.append(
                    f"step '{name}'.{func_name}{params} does not match the contract "
                    f"{func_name}{expected_params}"
                )

    if problems:
        raise ValueError(
            "Bootstrap step registry is inconsistent:\n  - " + "\n  - ".join(problems)
        )


def validate_pipeline(pipeline, name="pipeline"):
    """Assert a pipeline (list of step names) references only registered steps.

    Raises ValueError naming the unknown steps. Order/duplicates are allowed —
    e.g. 'connectivity' legitimately runs before and after the reload.
    """
    unknown = [s for s in pipeline if s not in STEP_REGISTRY]
    if unknown:
        available = ", ".join(sorted(STEP_REGISTRY))
        raise ValueError(
            f"{name} references unknown step(s): {', '.join(unknown)}. Available: {available}"
        )


def get(step_name):
    """Look up a step module by name. Raises KeyError if not found."""
    if step_name not in STEP_REGISTRY:
        available = ", ".join(sorted(STEP_REGISTRY.keys()))
        raise KeyError(f"Unknown bootstrap step '{step_name}'. Available: {available}")
    return STEP_REGISTRY[step_name]


def label(step_name):
    """Get the friendly display name for a step."""
    return STEP_LABELS.get(step_name, step_name)


def run_preflight(pipeline, device, settings):
    """Run preflight checks for all steps in the pipeline.

    Returns a list of {"step": name, "label": label, "ok": bool, "detail": str}.
    Only includes steps that have a preflight() function AND have findings to report.
    """
    results = []
    for step_name in pipeline:
        step_module = STEP_REGISTRY[step_name]
        check = getattr(step_module, "preflight", None)
        if check is None:
            continue
        try:
            issues = check(device, settings)
            if not issues:
                continue
            results.append({"step": step_name, "label": label(step_name), "ok": False, "detail": "; ".join(issues)})
        except Exception as e:
            results.append({"step": step_name, "label": label(step_name), "ok": False, "detail": str(e)})
    return results


def filter_pipeline(pipeline, device, settings):
    """Return only the steps that apply to this device.

    Steps that define an applies_to(device, settings) function are included
    only when it returns True. Steps without applies_to are always included.
    """
    filtered = []
    for step_name in pipeline:
        step_module = STEP_REGISTRY[step_name]
        check = getattr(step_module, "applies_to", None)
        if check is None or check(device, settings):
            filtered.append(step_name)
    return filtered
