"""Reload the device and wait for it to come back on the console."""

import time

from nautobot.extras.models import SecretsGroup, SecretsGroupAssociation

from ..console import (
    ConsoleSessionLost,
    DBPERSIST_ERROR,
    EXEC_PROMPT,
    clear_dbpersist_db,
    dbpersist_bug_logged,
)

_SAVE_PROMPT = r"System configuration has been modified.*\[yes/no\]:"
_PLAIN_CONFIRM = r"Proceed with reload\?\s*\[confirm\]"
# The warning form ("Boot variable either does not exist or buffer is too
# small ... Do you wish to proceed with reload anyway[confirm]") means the
# startup config may NOT be intact — under the DBPERSIST bug the preceding
# save prints [OK] but fails async, and confirming would reboot into a
# stale/empty config. It is aborted and repaired, never blindly confirmed.
_ANYWAY_CONFIRM = r"(?i)proceed with reload anyway\s*\[confirm\]"


def run(child, device, session, settings, logger):
    """Send reload and wait for the device to boot back to an exec prompt.

    Skipped when os_image/license ran earlier and recorded that nothing
    changed (settings["reload_required"] is False). Pipelines that don't
    include those steps get the old unconditional behavior.
    """
    if not settings.get("reload_required", True):
        logger.info("No pending image or license change — skipping reload")
        return "No pending image or license change — no reload"

    logger.info("Reloading device")
    _initiate_reload(child, logger)
    logger.info("Reload initiated — waiting for device to come back")

    _wait_for_boot(child, settings, logger)
    settings["reload_required"] = False
    return "Reloaded; device back at privileged exec"


def _classify_confirm(seen):
    """Fallback classification when no prompt regex matched.

    PnP discovery chatter (CCO server ... can't be resolved) prints straight
    to the console regardless of `no logging console` and can splice INTO
    the confirm prompt text, defeating any contiguous regex (seen live). On
    expect timeout the full unconsumed buffer is returned — substring checks
    across the whole buffer survive the splicing.
    """
    if "[confirm]" not in (seen or ""):
        return "failed"
    return "anyway" if "anyway" in seen else "plain"


def _initiate_reload(child, logger, attempts=3):
    """Issue `reload` and confirm it, repairing anything that taints the
    saved config first.

    Only a clean 'Proceed with reload? [confirm]' is confirmed outright. The
    boot-variable WARNING confirm means the startup config may not be intact
    (under the DBPERSIST bug the save prints [OK] but fails async) — that
    reload is ABORTED, the stale DB dir deleted if the bug is in the log,
    the config explicitly re-saved (via the self-healing save), and the
    reload reissued. If the warning survives a verified-clean save it is
    treated as cosmetic and confirmed — including the chained plain confirm
    that can follow it. A save-on-reload that dies back to the exec prompt
    takes the same repair path; sailing on without a confirm would leave
    _wait_for_boot mistaking the live prompt for a post-boot one.
    """
    remediated = False
    for attempt in range(1, attempts + 1):
        child.drain(quiet=0.3, max_wait=5)
        child.sendline("reload")

        idx, seen = child.expect(
            [_SAVE_PROMPT, _PLAIN_CONFIRM, _ANYWAY_CONFIRM],
            timeout=30,
            where="reload_prompt",
        )
        if idx == 0:
            child.sendline("yes")
            i2, seen = child.expect(
                [_PLAIN_CONFIRM, _ANYWAY_CONFIRM, DBPERSIST_ERROR.pattern, EXEC_PROMPT],
                timeout=60,
                where="reload_confirm",
            )
            outcome = {0: "plain", 1: "anyway"}.get(i2, _classify_confirm(seen))
        else:
            outcome = {1: "plain", 2: "anyway"}.get(idx, _classify_confirm(seen))

        if outcome == "plain":
            child.send_return()
            return

        if outcome == "anyway":
            if remediated:
                logger.warning(
                    "Boot-variable warning persists after DBPERSIST cleanup and a "
                    "verified save — treating it as cosmetic and proceeding"
                )
                child.send_return()
                # The warning form can chain straight into the standard confirm.
                chained, _ = child.expect([_PLAIN_CONFIRM], timeout=15, where="reload_confirm_chained")
                if chained == 0:
                    child.send_return()
                return
            logger.warning(
                "Reload warned the startup config/boot variable may not be intact — "
                "aborting this reload to repair before rebooting"
            )
            child.sendline("n")
            child.expect([EXEC_PROMPT], timeout=15, where="reload_abort")

        if attempt == attempts:
            raise RuntimeError(
                f"Couldn't reach a clean reload confirmation after {attempts} "
                f"attempts — console showed: {child.tail()}"
            )

        if dbpersist_bug_logged(child):
            clear_dbpersist_db(child, logger)
        logger.info("Re-saving config before retrying reload")
        child.save_config()  # self-healing save; raises if the save is hopeless
        remediated = True


def _wait_for_boot(child, settings, logger, timeout=900, poll=15):
    """Watch the console for an exec prompt after reload.

    Mid-pipeline the saved staging config has no console login, so the
    device comes back at user exec. If a pipeline reloads after config_push
    instead, AAA+TACACS is enabled but TACACS is unreachable until the
    WAN/DMVPN comes up, so authentication falls back to `local` and we log
    in as the priv-15 local admin.

    The OpenGear owns the serial line, so a device reboot does NOT drop our
    session to the console server — we just press Enter (a real CR; the IOS
    "Press RETURN" gate ignores line feeds) every `poll` seconds until a
    prompt appears, exactly like a human at the console. If the transport
    genuinely dies we rebuild the session once and carry on. Once a prompt is
    reached the session is promoted back to IOS mode (fresh boot = fresh exec
    = default paging).
    """
    reconnect = settings.get("reconnect_console")
    start = time.time()

    while time.time() - start < timeout:
        time.sleep(poll)

        try:
            # A reload spews boot logs — drain the backlog, then press Enter.
            child.drain(quiet=0.3, max_wait=5)
            child.send_return()
            idx, _ = child.expect(
                [
                    EXEC_PROMPT,                          # 0: already at priv exec
                    r"Press RETURN to get started",       # 1: post-boot banner
                    r"(?m)^rommon\s?\d*\s?>",             # 2: ROMMON — boot failed
                    r"(?m)^[A-Za-z0-9][\w\-]*>\s*$",      # 3: user exec (no AAA on console)
                    r"[Uu]sername:",                      # 4: AAA login prompt
                ],
                timeout=30,
                where="reload_poll",
            )
        except (ConsoleSessionLost, OSError) as e:
            # Only fires if the SSH transport to the OpenGear actually drops —
            # not expected across a device reboot, but recover if it happens.
            if not reconnect:
                raise
            logger.info(f"Console session dropped ({type(e).__name__}) — reconnecting")
            try:
                child = reconnect()
            except Exception as re_err:
                logger.warning(f"Reconnect failed ({re_err}) — retrying next cycle")
            continue

        if idx == 0:
            logger.info("Device is back — privileged exec")
            child.promote_to_ios()
            return child

        if idx == 1:
            child.send_return()  # the RETURN gate only accepts CR, not LF
            continue  # re-poll for what comes after the banner

        if idx == 2:
            raise RuntimeError(
                "Device dropped to ROMMON after reload — the boot image is likely "
                "bad or the boot statement is wrong. Manual recovery required."
            )

        if idx == 3:
            _escalate_to_priv(child, settings, logger)
            child.promote_to_ios()
            return child

        if idx == 4:
            _login_local_admin(child, settings, logger)
            child.promote_to_ios()
            return child

    raise RuntimeError(
        f"Device didn't come back after {timeout}s — check console manually. "
        f"Last console output: {child.tail()}"
    )


def _login_local_admin(child, settings, logger):
    """Authenticate at a post-reload Username: prompt using the fallback local admin.

    Assumes a privilege-15 local user in the intended config, so successful login
    lands directly at EXEC_PROMPT (#) with no enable step required.
    """
    sg_name = settings.get("local_admin_secrets_group", "LocalAdmin_Credentials")
    sg = SecretsGroup.objects.filter(name=sg_name).first()
    if not sg:
        raise RuntimeError(
            f"Local admin SecretsGroup '{sg_name}' not found — "
            f"create it or set BOOTSTRAP_LOCAL_ADMIN_SECRETS_GROUP to the right name"
        )

    username = SecretsGroupAssociation.objects.get(
        secrets_group=sg, access_type="Generic", secret_type="username",
    ).secret.get_value()
    password = SecretsGroupAssociation.objects.get(
        secrets_group=sg, access_type="Generic", secret_type="password",
    ).secret.get_value()

    logger.info(f"Console shows login prompt — authenticating as '{username}' (local fallback)")
    child.sendline(username)
    child.expect([r"[Pp]assword:"], timeout=15, where="reload_login_pw_prompt")
    child.register_secret(password)
    child.sendline(password)

    idx, _ = child.expect(
        [EXEC_PROMPT, r">", r"(Login|Authentication|% Access|% Bad) ?[fF]?ailed"],
        timeout=20,
        where="reload_login_result",
    )
    if idx == 0:
        logger.info(f"Logged in as '{username}' — privileged exec")
        return
    if idx == 1:
        logger.warning(f"Logged in as '{username}' but landed at user exec — escalating")
        _escalate_to_priv(child, settings, logger)
        return
    raise RuntimeError(f"Local admin login failed for '{username}' — check {sg_name}")


def _escalate_to_priv(child, settings, logger):
    """Get from user exec to privileged exec (bootstrap-era enable secret)."""
    child.sendline("enable")
    idx, _ = child.expect(
        [EXEC_PROMPT, r"[Pp]assword:"],
        timeout=10,
        where="reload_enable",
    )

    if idx == 0:
        logger.info("Device is back — privileged exec (no enable password)")
        return

    enable_secret = settings.get("factory_default_enable_secret", "")
    child.sendline(enable_secret)
    idx, _ = child.expect(
        [EXEC_PROMPT, r"% (Bad|Access denied)"],
        timeout=10,
        where="reload_enable_auth",
    )

    if idx == 0:
        logger.info("Device is back — privileged exec")
        return

    child.send_return()
    raise RuntimeError("Could not escalate to privileged exec after reload")
