"""Apply staging config — just enough connectivity to reach NDES/network."""

import re
import time

from netmiko.exceptions import ReadTimeout

_CONFIG_ERROR = re.compile(r"(?m)^\s*%\s*(Invalid|Error|Incomplete|Ambiguous|Unknown).*$", re.IGNORECASE)


def is_switch_role(device):
    """Switches get the SVI/no-VRF staging shape; everything else is a router.

    Classification is the platform driver's call — one source of truth shared
    with pipeline selection, so a device can't stage as one class and run the
    other class's pipeline."""
    from ..drivers import classify_device

    return classify_device(device) == "switch"


def preflight(device, settings):
    issues = []
    if is_switch_role(device) and not settings.get("mgmt_vlan"):
        issues.append("'mgmt_vlan' setting is empty — required for switch staging (SVI)")
    return issues


def run(child, device, session, settings, logger):
    """Apply role-appropriate staging config."""
    if is_switch_role(device):
        _apply_switch(child, device, settings, logger)
        return f"Switch staging config applied (DHCP on Vlan{settings.get('mgmt_vlan')})"
    _apply_router(child, device, settings, logger)
    return f"Router staging config applied (VRF {settings.get('vrf_name')}, DHCP uplink)"


def _apply_config(child, commands, logger, what):
    """Push a config set and raise on any IOS rejection in the output."""
    output = child.send_config_set(commands, read_timeout=30)
    m = _CONFIG_ERROR.search(output)
    if m:
        raise RuntimeError(f"{what} config rejected by the device: {m.group(0).strip()}")
    return output


def _stop_pnp(child, logger):
    """Stop the PnP agent's discovery loop.

    PnP keeps retrying CCO discovery long after staging config lands, and
    its messages print straight to the console REGARDLESS of `no logging
    console` — they splice into prompt text (broke the reload confirm live)
    and PnP also periodically holds the exclusive config lock. Best-effort:
    the command name has minor platform variance, so a rejection is logged
    and ignored.
    """
    out = child.send_command_timing("pnpa service discovery stop", last_read=2.0, read_timeout=30)
    if "% Invalid" in out or "% Incomplete" in out:
        logger.info("PnP discovery stop command not supported on this platform — continuing")
    else:
        logger.info("Stopped PnP agent discovery (kills CCO console chatter + config locks)")


def _set_hostname(child, device, logger):
    """Set the hostname first, on its own, then re-sync netmiko's prompt cache.

    The prompt changes the instant this applies; without a re-sync every later
    config_mode() waits for the old (factory) prompt and times out.

    `no logging console` rides along as the FIRST line: this is the pipeline's
    first config entry, and on a booting switch the console is still spraying
    %LINK/%LINEPROTO for dozens of ports right now — silencing it here (rather
    than in the later staging set) shrinks the syslog-corrupts-netmiko window
    to this single entry, which the console layer's config-mode retry covers.
    """
    _apply_config(child, ["no logging console", f"hostname {device.name}"], logger, "Hostname")
    child.sync_prompt()


def _apply_router(child, device, settings, logger):
    domain = settings["domain_name"]
    vrf = settings["vrf_name"]
    vrf_rd = settings["vrf_rd"]
    gateway = settings["staging_gateway"]

    # The device must resolve the hostname in the trustpoint enrollment URL
    # inside the staging VRF — pin it with ip host entries (global + VRF).
    from .cert_enroll import resolve_ndes
    ndes = resolve_ndes(device, settings)
    ndes_ip = ndes["ip"] or ""
    ndes_hostname = ndes["host"] or f"ndes.{domain}"

    ndes_host = f"ip host {ndes_hostname} {ndes_ip}" if ndes_ip else None
    ndes_vrf_host = f"ip host vrf {vrf} {ndes_hostname} {ndes_ip}" if ndes_ip else None

    logger.info(f"Setting up temporary staging config (VRF {vrf}, DHCP on g0/0/0)")

    _set_hostname(child, device, logger)

    staging_commands = [
        # (async console syslog already silenced — _set_hostname applies
        # `no logging console` as the pipeline's first config line; saved
        # before the reload, so it holds for the whole pipeline)
        f"vrf definition {vrf}",
        f" rd {vrf_rd}",
        " address-family ipv4",
        " exit-address-family",
        # "ip domain name" (no hyphen) — newer IOS-XE removed the hyphenated
        # alias, and the unhyphenated form works on everything modern.
        f"ip domain name {domain}",
    ]
    if ndes_host:
        staging_commands.append(ndes_host)
    if ndes_vrf_host:
        staging_commands.append(ndes_vrf_host)
    staging_commands.extend([
        f"ip route vrf {vrf} 0.0.0.0 0.0.0.0 {gateway} name FDVRF_DEFAULT",
        "interface GigabitEthernet0/0/0",
        f" vrf forwarding {vrf}",
        " ip address dhcp",
        " no shutdown",
        # Bind the HTTP client to the staging uplink so `copy https://...`
        # (OS image + cell firmware) reaches the webserver through the MGMT
        # VRF — the route to it lives in that VRF, not the global table.
        # cert_enroll later repoints this at Loopback0 for SCEP.
        "ip http client source-interface GigabitEthernet0/0/0",
    ])

    _apply_config(child, staging_commands, logger, "Router staging")
    _stop_pnp(child, logger)

    logger.info("Staging config applied — waiting for DHCP lease")
    _poll_connectivity(child, gateway, settings, logger)


def _apply_switch(child, device, settings, logger):
    domain = settings["domain_name"]
    gateway = settings["staging_gateway"]
    mgmt_vlan = settings.get("mgmt_vlan")
    if not mgmt_vlan:
        # An empty VLAN would emit a bare "interface Vlan" and every command
        # after it lands in the wrong config mode — fail up front instead.
        raise RuntimeError(
            "'mgmt_vlan' setting is empty — set the staging SVI VLAN id in the "
            "app settings before provisioning switches"
        )

    logger.info(f"Setting up temporary staging config (DHCP on Vlan{mgmt_vlan})")

    _set_hostname(child, device, logger)

    commands = [
        # (no logging console already applied by _set_hostname)
        f"ip domain name {domain}",
        f"interface Vlan{mgmt_vlan}",
        " ip address dhcp",
        " no shutdown",
    ]
    _apply_config(child, commands, logger, "Switch staging")
    _stop_pnp(child, logger)

    logger.info("Staging config applied — waiting for DHCP lease")
    # Switches get no staging VRF — the SVI lives in the global table.
    _poll_connectivity(child, gateway, settings, logger, use_vrf=False)


def _poll_connectivity(child, gateway, settings, logger, window=600, interval=5, use_vrf=True):
    """Ping the gateway until it answers or `window` seconds elapse.

    Time-window based, not attempt-based — after a reload the device can take
    minutes to bring interfaces up, re-acquire DHCP, and converge routing, and
    an attempt-counted loop gives wildly different real windows depending on
    how fast each failing ping errors out.
    """
    vrf = settings["vrf_name"]
    ping_cmd = f"ping vrf {vrf} {gateway}" if use_vrf else f"ping {gateway}"
    start = time.time()
    attempt = 0
    last_result = "no ping output seen"
    while time.time() - start < window:
        attempt += 1
        try:
            output = child.send_command(ping_cmd, read_timeout=30)
        except ReadTimeout:
            last_result = "ping produced no prompt within 30s (device busy or console noisy)"
            time.sleep(interval)
            continue

        m = re.search(r"Success rate is (\d+) percent", output)
        if m and m.group(1) == "100":
            logger.info(f"Gateway reachable — network is up (after {int(time.time() - start)}s)")
            return True
        if m:
            last_result = m.group(0)
        else:
            last_result = " ".join(output.split())[-160:] or "no ping output"
        logger.info(
            f"No connectivity yet — attempt {attempt} ({int(time.time() - start)}s of {window}s): {last_result}"
        )
        time.sleep(interval)

    elapsed = int(time.time() - start)
    raise RuntimeError(
        f"No connectivity to {gateway} after {attempt} pings over {elapsed}s "
        f"(last result: {last_result}) — DHCP or routing never came up"
    )
