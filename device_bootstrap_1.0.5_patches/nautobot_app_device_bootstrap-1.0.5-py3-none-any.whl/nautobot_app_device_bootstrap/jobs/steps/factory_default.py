"""Detect device state and handle factory default dialog."""

import re
import time

from ..console import EXEC_PROMPT


def run(child, device, session, settings, logger):
    """Detect device state, walk through factory default if needed, then
    promote the session to netmiko's cisco_ios mode (prompt learned, paging
    disabled) for the rest of the pipeline."""
    state = detect_device_state(child, logger)
    enable_secret = settings["factory_default_enable_secret"]

    if state == "factory_default":
        handle_factory_default(child, enable_secret, logger)
        summary = "Factory-default setup dialog completed"
    elif state == "mid_dialog":
        # A previous run (or operator) died inside the setup dialog — the
        # device is sitting at "Enter enable secret:". Resume from there.
        logger.info("Device is mid setup dialog at the enable-secret prompt — resuming")
        _complete_setup_dialog(child, enable_secret, logger)
        summary = "Resumed and completed the setup dialog"
    elif state == "user_exec":
        enter_priv_exec(child, enable_secret, logger)
        summary = "Entered privileged exec"
    else:
        logger.info("Already in privileged exec — good to go")
        summary = "Already in privileged exec"

    # Every path above ends at privileged exec — hand the session to netmiko's
    # cisco_ios personality (learns the prompt, terminal length 0/width).
    child.promote_to_ios()
    logger.info("Console session promoted to IOS mode")
    return summary


def detect_device_state(child, logger, max_wait=15):
    rx_init_q = re.compile(r"Would you like to enter the initial configuration dialog\?\s*\[yes/no\]:", re.I)
    rx_sys_dlg = re.compile(r"System Configuration Dialog", re.I)
    rx_enable_secret = re.compile(r"Enter enable secret:", re.I)
    rx_username = re.compile(r"(?m)^Username:\s*$")
    rx_password = re.compile(r"(?m)^Password:\s*$")
    rx_rommon = re.compile(r"(?m)^rommon\S*>\s*$")
    rx_return = re.compile(r"Press RETURN to get started", re.I)
    rx_more = re.compile(r"--More--")
    rx_prompt = re.compile(r"(?m)^(\S+)([>#])\s*$")

    deadline = time.time() + max_wait

    def classify(text):
        if rx_init_q.search(text) or rx_sys_dlg.search(text):
            return "factory_default"
        # Mid-dialog: probing with Enter at "Enter enable secret:" makes the
        # device print a validation failure and re-issue the same prompt (a
        # stranded "Confirm enable secret:" also re-issues it via the mismatch
        # path), so this match means the prompt is fresh and waiting.
        if rx_enable_secret.search(text):
            return "mid_dialog"
        if rx_rommon.search(text):
            raise RuntimeError("Device is in ROMMON — needs manual recovery before bootstrap can continue")
        if rx_username.search(text) or rx_password.search(text):
            raise RuntimeError("Device has an AAA login prompt — already configured with unknown credentials")
        if rx_return.search(text):
            return "return"
        if rx_more.search(text):
            return "more"
        m = rx_prompt.search(text)
        if m:
            return "priv_exec" if m.group(2) == "#" else "user_exec"
        return None

    while time.time() < deadline:
        child.send_return()
        raw = child.drain(quiet=0.7, max_wait=3)
        state = classify(raw)

        if state in ("factory_default", "mid_dialog", "user_exec", "priv_exec"):
            if state == "factory_default":
                logger.info("Device is fresh out of the box — walking through setup dialog")
            elif state == "user_exec":
                logger.info("Device is at user exec — escalating to priv exec")
            return state
        elif state == "return":
            child.send_return()
        elif state == "more":
            child.write(" ")
        time.sleep(0.3)

    raise RuntimeError(
        f"Couldn't get a stable prompt from the device — check the console "
        f"connection. Last output: {child.tail()}"
    )


def handle_factory_default(child, enable_secret, logger):
    child.sendline("no")
    _complete_setup_dialog(child, enable_secret, logger)


def _complete_setup_dialog(child, enable_secret, logger, overall_timeout=180):
    """Walk the setup dialog to privileged exec — state-driven, not scripted.

    Prompt order varies by platform and release: newer IOS-XE forces the
    enable-secret flow even when the dialog is declined, switches interject
    'terminate autoinstall?', dialogs flush type-ahead input between prompts
    (so a queued answer can be eaten and the prompt RE-ASKED, e.g. the
    selection menu's 'A decimal number between 0 and 2' seen live on an
    IE-3300 at 17.15.04). A linear expect script desyncs on any of these —
    instead, answer whatever the dialog shows next until an exec prompt.
    """
    deadline = time.time() + overall_timeout
    answer_counts = {}

    def _answer(idx, reply):
        """Send a dialog answer, capped per prompt — a prompt that keeps
        rejecting the same answer means we're desynced, not unlucky."""
        answer_counts[idx] = answer_counts.get(idx, 0) + 1
        if answer_counts[idx] > 4:
            raise RuntimeError(
                f"Setup dialog kept re-asking the same prompt despite our "
                f"answer '{reply}' — console showed: {child.tail()}"
            )
        child.sendline(reply)

    while time.time() < deadline:
        idx, _ = child.expect(
            [
                r"initial configuration dialog\?\s*\[yes/no\]:",  # 0 (re-)asked when an answer is eaten
                r"Enter enable secret:",                          # 1
                r"Confirm enable secret",                         # 2 (wording varies after the base phrase)
                r"[Pp]assword strength validation failed",        # 3
                r"Enter your encryption selection\s*\[2\]:",      # 4 System Security dialog (17.15+): type-6/7
                r"Enter your selection\s*\[2\]:",                 # 5 save/discard menu (incl. re-prompts)
                r"terminate autoinstall\?\s*\[yes\]:",            # 6 switches only
                r"Press RETURN to get started",                   # 7
                r"[Pp]assword:",                                  # 8 enable password (secret already active)
                EXEC_PROMPT,                                      # 9 privileged exec — done
                r"(?m)^[A-Za-z0-9][\w\-]*>\s*$",                  # 10 user exec
            ],
            timeout=45,
            where="setup_dialog",
        )

        if idx == 0:
            _answer(idx, "no")
        elif idx in (1, 2):
            _answer(idx, enable_secret)
        elif idx == 3:
            raise RuntimeError(
                "Device rejected the enable secret (password strength validation "
                "failed) — 'factory_default_enable_secret' must be 10-32 characters "
                "with at least one upper case, one lower case, and one digit, and "
                "must not contain 'cisco'"
            )
        elif idx == 4:
            # [2] = no encryption applied — "Configuration aborted, no changes
            # made". Type-6 needs an unrecoverable master key and the real
            # crypto config comes from config_push; take no dialog-era changes.
            _answer(idx, "2")
        elif idx == 5:
            # [0] = go to the IOS command prompt without saving this config.
            # No trailing extra CR — at a re-asked menu an empty line means
            # the default [2] (save and exit), which we must never pick.
            _answer(idx, "0")
        elif idx == 6:
            _answer(idx, "yes")
        elif idx == 7:
            child.send_return()
        elif idx == 8:
            _answer(idx, enable_secret)
        elif idx == 9:
            logger.info("Setup dialog complete — in privileged exec")
            return
        elif idx == 10:
            child.sendline("en")
        else:  # timeout with nothing recognized
            raise RuntimeError(
                f"Device never reached privileged exec after the setup dialog — "
                f"console showed: {child.tail()}"
            )

    raise RuntimeError(
        f"Setup dialog did not complete within {overall_timeout}s — "
        f"console showed: {child.tail()}"
    )


def enter_priv_exec(child, enable_secret, logger):
    child.sendline("en")
    idx, _ = child.expect([r"Password:", r"#"], timeout=15, where="enable")
    if idx == 0:
        child.sendline(enable_secret)
        child.expect([r"#"], timeout=15, where="enable_auth")
    logger.info("Escalated to privileged exec")
