"""Remove staging artifacts before the full config push.

Only staging-only leftovers are removed — the temporary DHCP addressing and
the staging default route. Anything that matches intended state (NTP lines,
http client source-interface, Loopback0) is deliberately left alone, and
g0/0/0 is defaulted but left admin-up.
"""

from .staging import is_switch_role


def run(child, device, session, settings, logger):
    """Remove the staging DHCP config (and, on routers, the temp default route)."""
    if is_switch_role(device):
        _cleanup_switch(child, settings, logger)
        return f"Staging DHCP removed from Vlan{settings.get('mgmt_vlan')}"
    _cleanup_router(child, settings, logger)
    return "Staging route and DHCP uplink removed"


def _cleanup_router(child, settings, logger):
    vrf = settings["vrf_name"]
    gateway = settings["staging_gateway"]

    logger.info("Tearing down staging config (removing temp route, defaulting g0/0/0)")
    cleanup_commands = [
        f"no ip route vrf {vrf} 0.0.0.0 0.0.0.0 {gateway} name FDVRF_DEFAULT",
        "default interface GigabitEthernet0/0/0",
        # Leave the interface UP — 'default interface' can reset a router port
        # to its shutdown default, and the intended config may not reference
        # g0/0/0 at all (cellular WAN sites), which would leave it stranded
        # admin-down.
        "interface GigabitEthernet0/0/0",
        " no shutdown",
    ]
    child.send_config_set(cleanup_commands, read_timeout=30)
    logger.info("Staging cleaned up — ready for production config")


def _cleanup_switch(child, settings, logger):
    mgmt_vlan = settings["mgmt_vlan"]

    logger.info(f"Tearing down staging config (removing DHCP from Vlan{mgmt_vlan})")
    cleanup_commands = [
        f"interface Vlan{mgmt_vlan}",
        " no ip address dhcp",
    ]
    child.send_config_set(cleanup_commands, read_timeout=30)
    logger.info("Staging cleaned up — ready for production config")
