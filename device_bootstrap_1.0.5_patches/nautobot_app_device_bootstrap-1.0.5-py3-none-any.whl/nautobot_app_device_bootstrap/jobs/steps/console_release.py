"""Release the OpenGear console port after a fully successful provision.

This is the last step in the pipeline, so it only runs when every prior
step — including config push and validation — completed. It removes the
console cable record in Nautobot (freeing the OpenGear port for the next
device on the bench) and optionally moves the device to its post-provision
status, which also keeps the allowed_provisioning_statuses gate from
letting a finished device be factory-defaulted by a rerun.
"""

from nautobot.dcim.models import ConsolePort
from nautobot.extras.models import Status


def run(child, device, session, settings, logger):
    """Restore console logging, then release the console and update the device status."""
    # The pipeline's very first config line was `no logging console` (staging
    # step) so syslog couldn't splice into prompt matching. Everything
    # console-interactive is finished by this step, so turn it back on and
    # save — `logging console` is the IOS default, so the pushed intended
    # config carries no explicit line that would restore it, and without this
    # the device leaves provisioning with console logging disabled for good.
    logger.info("Restoring console logging")
    child.send_config_set(["logging console"], read_timeout=15)
    child.save_config()

    console_port = ConsolePort.objects.filter(device=device).first()
    if console_port and console_port.cable:
        og_name = session.console_server.name if session.console_server else "console server"
        console_port.cable.delete()
        logger.info(
            f"Console cable to {og_name} port {session.console_port_number} removed — "
            f"port is free for the next device"
        )
        summary = f"Console port {session.console_port_number} released"
    else:
        logger.info("No console cable modeled in Nautobot — nothing to release")
        summary = "No console cable to release"

    status_name = settings.get("post_provision_status", "")
    if not status_name:
        return summary

    status = Status.objects.filter(name=status_name).first()
    if status is None:
        logger.warning(f"Post-provision status '{status_name}' not found — leaving device status unchanged")
        return f"{summary}; status '{status_name}' not found, unchanged"

    device.status = status
    # Do NOT swallow this failure: post_provision_status is the guard that stops
    # a finished device from being re-provisioned (and factory-defaulted) by a
    # later run. If the status doesn't stick, the device stays in a
    # provisionable status — surface that instead of silently reporting success.
    device.validated_save()
    logger.info(f"Device status set to '{status_name}'")
    return f"{summary}; device status → {status_name}"
