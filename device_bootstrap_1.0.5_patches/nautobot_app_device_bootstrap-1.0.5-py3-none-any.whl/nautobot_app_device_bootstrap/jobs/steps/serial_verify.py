"""Verify chassis serial number matches Nautobot record."""

import re


def _chassis_rank(name):
    """Sort key: how chassis-like an inventory entry name is.

    Routers title the entry "Chassis"; standalone/stacked Catalyst switches use
    "Switch" / "Switch 1" / "Switch 2"; stacks may lead with e.g. "c93xx Stack".
    Everything else (modules, PSUs, SFPs) ranks last.
    """
    lowered = name.lower()
    if lowered == "chassis":
        return 0
    if re.fullmatch(r"switch(\s+\d+)?", lowered):
        return 1
    if "stack" in lowered:
        return 2
    return 3


def run(child, device, session, settings, logger):
    """Check the chassis serial number matches Nautobot. Raises on mismatch."""
    expected = getattr(device, "serial", None)
    if not expected:
        logger.warning("No serial in Nautobot — skipping serial check")
        return "No serial in Nautobot — not checked"

    logger.info(f"Checking chassis serial (expecting {expected})")
    output = child.send_command("show inventory", read_timeout=30)

    # Parse every NAME/SN pair — the chassis entry's NAME differs by platform
    # (routers: "Chassis"; switches: "Switch 1"; stacks: "c93xx Stack"), so a
    # single fixed name silently skipped the check on switches.
    entries = [
        (name.strip(), sn.upper())
        for name, sn in re.findall(r'NAME:\s*"([^"]+)".*?SN:\s*([A-Za-z0-9]+)', output, re.DOTALL)
    ]
    if not entries:
        logger.warning("Couldn't parse any serials from 'show inventory' — skipping check")
        return "Could not parse 'show inventory' — not checked"

    # Accept a match against any chassis-level entry: on a stack, Nautobot may
    # record any member's serial depending on how the device was modeled.
    chassis_entries = [e for e in entries if _chassis_rank(e[0]) < 3] or entries[:1]
    for entry_name, serial in chassis_entries:
        if serial == expected.upper():
            logger.info(f"Serial matches: {serial} ({entry_name})")
            return f"Serial {serial} matches ({entry_name})"

    found = ", ".join(f"{sn} ({name})" for name, sn in chassis_entries)
    raise RuntimeError(
        f"Wrong device! Expected serial {expected} but found {found} — "
        f"check that the correct device is cabled to this console port"
    )
