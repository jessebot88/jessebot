"""Apply license boot-level config parsed from the intended config.

The intended config (Golden Config) is the single source of truth: every
`license boot level ...` line found there is applied, and stale boot-level
lines on the device are removed. License boot-level changes only take effect
after a reload, so this step sets the shared `reload_required` flag and lets
the `reload` step (placed right after this one in the pipeline) cover both
the OS upgrade and the license activation with a single reboot.
"""

import re

_LICENSE_LINE = re.compile(r"^license boot level\s+\S+", re.IGNORECASE)

_EULA_RE = re.compile(r"(ACCEPT\?|\[yes/no\]:)\s*$", re.IGNORECASE | re.MULTILINE)
_ERROR_RE = re.compile(r"(?m)^\s*%\s*(Invalid|Error|Incomplete).*$", re.IGNORECASE)


def _parse_license_lines(device):
    """Return the normalized `license boot level` lines from intended config."""
    try:
        from nautobot_golden_config.models import GoldenConfig
        gc = GoldenConfig.objects.get(device=device)
    except Exception:
        return []

    if not gc.intended_config:
        return []

    lines = []
    for raw in gc.intended_config.splitlines():
        stripped = raw.strip()
        if _LICENSE_LINE.match(stripped):
            lines.append(stripped)
    return lines


def applies_to(device, settings):
    """True when the intended config declares a license boot level."""
    return bool(_parse_license_lines(device))


def run(child, device, session, settings, logger):
    """Converge the device's license boot level onto the intended config."""
    settings.setdefault("reload_required", False)

    desired = _parse_license_lines(device)
    if not desired:
        logger.info("No 'license boot level' lines in intended config — skipping")
        return "No license boot level in intended config — skipped"

    output = child.send_command("show running-config | include ^license boot", read_timeout=30)
    current = [
        line.strip() for line in output.splitlines()
        if _LICENSE_LINE.match(line.strip())
    ]

    to_add = [line for line in desired if line not in current]
    to_remove = [line for line in current if line not in desired]

    if not to_add and not to_remove:
        logger.info(f"License boot level already correct: {'; '.join(desired)}")
        return f"License boot level already correct: {'; '.join(desired)}"

    logger.info(f"License boot level change — applying: {'; '.join(desired)}")
    child.config_mode()
    try:
        for line in to_remove:
            _send_license_command(child, f"no {line}", logger)
        for line in to_add:
            _send_license_command(child, line, logger)
    finally:
        try:
            child.exit_config_mode()
        except Exception:
            pass

    child.drain(quiet=0.3, max_wait=3)  # clear any post-config %SYS syslog before netmiko re-detects the prompt
    child.save_config()
    settings["reload_required"] = True
    logger.info("License boot level saved — takes effect on next reload")
    return f"License boot level set: {'; '.join(desired)}; reload pending"


def _send_license_command(child, command, logger):
    """Send one license config line, accepting the EULA prompt if it appears."""
    output = child.send_command_timing(command, last_read=2.0, read_timeout=60)

    if _EULA_RE.search(output):
        logger.info("Accepting end-user license agreement")
        output += child.send_command_timing("yes", last_read=2.0, read_timeout=60)

    err = _ERROR_RE.search(output)
    if err:
        raise RuntimeError(
            f"License command rejected: '{command}' — device said: {err.group(0).strip()}. "
            "Valid boot levels differ per platform (e.g. network-advantage/"
            "network-essentials on Cat8k routers) — the intended config's license "
            "line must use a level this platform supports."
        )

    if not output.strip():
        raise RuntimeError(
            f"License command produced no response: '{command}' — "
            f"console showed: {child.tail()}"
        )
