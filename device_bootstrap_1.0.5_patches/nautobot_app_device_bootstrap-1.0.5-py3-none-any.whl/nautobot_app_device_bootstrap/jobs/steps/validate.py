"""Post-bootstrap validation — software, firmware, and configuration."""

import re
import time

from . import cell_firmware as _cell_fw
from . import cell_profile as _cell_profile
from . import cert_enroll as _cert_enroll
from . import config_push as _config_push
from .os_image import (
    _boot_statement_references,
    _bootvar_references,
    _image_on_flash,
    _normalize_version,
    _parse_running_version,
    _resolve_image,
)


def run(child, device, session, settings, logger):
    """Verify the device is running the expected software, firmware, and config.

    This is the pipeline's final correctness gate, so the checks that indicate
    real misprovisioning — wrong/absent OS version, missing license boot level,
    wrong boot statement, a cellular modem not on its carrier firmware, no
    certificate on the trustpoint, wrong APN, modem not attached — accumulate
    and RAISE, failing the pipeline. The hostname check stays advisory: a typo
    there is cosmetic. The intended-vs-running config comparison is advisory
    until a bench cycle has proven its normalisation (`_CONFIG_DIFF_HARD`).

    Checks that verify another step's work only run when that step is in the
    device's pipeline (`_in_pipeline`), so a team that dropped cert_enroll
    isn't failed for having no certificate.
    """
    _check_hostname(child, device, logger)              # advisory

    verified = []
    failures = []
    failures += _check_os_version(child, device, logger, verified)
    failures += _check_license(child, device, logger, verified)
    failures += _check_boot_statement(child, device, logger, verified)
    failures += _check_bootvar(child, device, logger)
    failures += _check_image_on_flash(child, device, logger)
    failures += _check_cell_firmware(child, device, settings, logger, verified)
    if _in_pipeline(settings, "cert_enroll"):
        failures += _check_certificate(child, device, logger, verified)
    if _in_pipeline(settings, "cell_profile"):
        failures += _check_apn_profile(child, device, settings, logger, verified)
        failures += _check_cell_attached(child, device, settings, logger, verified)
    if _in_pipeline(settings, "config_push"):
        failures += _check_config_applied(child, device, settings, logger, verified)

    if failures:
        raise RuntimeError(
            "Post-bootstrap validation failed:\n  - " + "\n  - ".join(failures)
        )
    summary = "Verified: " + ", ".join(verified) if verified else "Nothing to verify for this device"
    logger.info(f"Validation complete — {summary}")
    return summary


def _in_pipeline(settings, step_name):
    """True when `step_name` is in a configured pipeline (or none is known)."""
    pipelines = [
        settings.get(key) for key in ("pipeline_router", "pipeline_switch") if settings.get(key)
    ]
    if not pipelines:
        return True
    return any(step_name in pipeline for pipeline in pipelines)


def _check_hostname(child, device, logger):
    output = child.send_command("show running-config | include hostname", read_timeout=30)

    if device.name in output:
        logger.info(f"Hostname verified: {device.name}")
    else:
        logger.warning(f"Hostname '{device.name}' not in running-config — worth a manual look")


def _check_os_version(child, device, logger, verified=None):
    """Return [] if the running OS matches the target, else a failure message.

    Validation runs after the reload, so the device must already be on the
    target version — a mismatch here is a real provisioning failure, not a
    pending reload.
    """
    image = _resolve_target_image(device)
    if image is None:
        return []

    target_version = image.software_version.version
    logger.info(f"Checking OS version (expecting {target_version})")

    output = child.send_command("show version | include Version", read_timeout=30)

    running = _parse_running_version(output)
    if running is not None and _normalize_version(running) == _normalize_version(target_version):
        logger.info(f"OS version verified: {target_version}")
        if verified is not None:
            verified.append(f"OS {target_version}")
        return []
    return [
        f"device is running {running or 'an unparseable version'}, "
        f"not the target OS version {target_version}, after reload"
    ]


def _check_license(child, device, logger, verified=None):
    from .license import _parse_license_lines

    desired = _parse_license_lines(device)
    if not desired:
        return []

    logger.info("Checking license boot level")
    output = child.send_command("show running-config | include ^license boot", read_timeout=30)

    missing = [line for line in desired if line not in output]
    if missing:
        return [f"license boot level not applied — missing: {'; '.join(missing)}"]
    logger.info(f"License boot level verified: {'; '.join(desired)}")
    if verified is not None:
        verified.append("license boot level")
    return []


# The APN profile step reboots the modem shortly before validation and only
# waits passively, so give the modem a bounded window to answer here.
_CELL_VALIDATE_WAIT = 300


def _check_cell_firmware(child, device, settings, logger, verified=None):
    """Return [] when every cellular modem is on the configured carrier firmware.

    This is the backstop for the firmware step: a modem that never answers, or
    answers on the wrong firmware version or carrier PRI, is a failure when a
    carrier firmware is configured for the device. With no carrier firmware
    configured there is nothing to compare against, so the check only logs.
    """
    modules = _cell_fw._find_cellular_modules(device)
    if not modules:
        return []

    carrier = _cell_fw._resolve_carrier(device, settings)
    failures = []
    for bay_name, module_model, subslot in modules:
        logger.info(f"Checking cellular firmware in subslot {subslot}")

        if carrier is None:
            version, pri = _cell_fw._read_modem_state(child, subslot)
            if version:
                logger.info(f"Cellular firmware: {version} (carrier PRI {pri or 'not reported'})")
            else:
                logger.warning(
                    f"Modem in subslot {subslot} not responding — no carrier firmware "
                    "configured for this device, so this is advisory"
                )
            continue

        try:
            version, pri = _cell_fw._wait_for_modem_ready(
                child, subslot, logger, timeout=_CELL_VALIDATE_WAIT
            )
        except RuntimeError as exc:
            failures.append(f"cellular modem in subslot {subslot}: {exc}")
            continue

        on_target, reason = _cell_fw._modem_matches_target(
            version, pri, carrier["key"], carrier["version"]
        )
        if on_target:
            logger.info(
                f"Cellular firmware verified: {version} (carrier PRI {pri or 'not reported'})"
            )
            if verified is not None:
                verified.append(f"modem {subslot} firmware {version} ({(pri or carrier['key']).upper()})")
        else:
            failures.append(f"cellular modem in subslot {subslot}: {reason}")

    return failures


def _check_boot_statement(child, device, logger, verified=None):
    """Return [] if the boot statement references the target image, else a failure.

    Tri-state: some platforms (IE-3300 confirmed live) accept `boot system`
    but never render it in running-config — for those the saved BOOT
    variable check (_check_bootvar, run right after this) is authoritative,
    so an ABSENT statement is not a failure; only a WRONG one is."""
    image = _resolve_target_image(device)
    if image is None:
        return []

    logger.info("Checking boot statement")
    stmt = _boot_statement_references(child, image.image_file_name)
    if stmt is None:
        logger.info("No boot system line in running-config — this platform stores boot config in the BOOT variable only")
        return []
    if stmt:
        logger.info(f"Boot statement verified: {image.image_file_name}")
        if verified is not None:
            verified.append("boot statement")
        return []
    return [f"boot statement does not reference the target image {image.image_file_name}"]


def _check_bootvar(child, device, logger):
    """Return [] if the saved BOOT variable references the target image.

    The running-config check above proves the statement was configured; this
    proves it was WRITTEN — an unsaved boot statement silently reverts the
    device to the old image on its next power cycle."""
    image = _resolve_target_image(device)
    if image is None:
        return []

    logger.info("Checking saved BOOT variable")
    if _bootvar_references(child, image.image_file_name):
        logger.info(f"BOOT variable verified: {image.image_file_name}")
        return []
    return [
        f"saved BOOT variable does not reference {image.image_file_name} — "
        f"boot config was not written to NVRAM"
    ]


def _check_image_on_flash(child, device, logger):
    """Return [] if the target image FILE exists on flash.

    Running the right version isn't enough — the boot config points at a
    file, and if that file is missing from flash the device strands itself
    on its next reload."""
    image = _resolve_target_image(device)
    if image is None:
        return []

    if _image_on_flash(child, image.image_file_name, logger):
        logger.info(f"Image present on flash: {image.image_file_name}")
        return []
    return [f"target image {image.image_file_name} is not on flash — device will fail its next reload"]


def _resolve_target_image(device):
    """Same resolution as the os_image step — validation must check against
    the same target the upgrade used, not an independent (and previously
    nondeterministic) pick. Ambiguity raises and fails the gate loudly."""
    image, _ = _resolve_image(device)
    return image


# ----------------------------------------------------------------------------
# Certificate, APN, attach, and config checks — verify the later steps' work.
# ----------------------------------------------------------------------------

_CERT_BLOCK_RE = re.compile(r"^(CA Certificate|Certificate)\s*$", re.MULTILINE)
_CERT_STATUS_RE = re.compile(r"Status:\s*(\S+)")


def _parse_router_cert_status(output):
    """The Status of the router (non-CA) certificate block, or None if absent."""
    headers = list(_CERT_BLOCK_RE.finditer(output or ""))
    for n, header in enumerate(headers):
        if header.group(1) != "Certificate":
            continue
        end = headers[n + 1].start() if n + 1 < len(headers) else len(output)
        match = _CERT_STATUS_RE.search(output, header.end(), end)
        return match.group(1) if match else "unknown"
    return None


def _check_certificate(child, device, logger, verified=None):
    """Return [] when the trustpoint from the intended config holds a router cert."""
    tp = _cert_enroll._parse_trustpoint_from_intended(device)
    if not tp or not tp.get("name"):
        return []

    name = tp["name"]
    logger.info(f"Checking certificate on trustpoint {name}")
    output = child.send_command(f"show crypto pki certificates {name}", read_timeout=30)
    status = _parse_router_cert_status(output)
    if status is None:
        return [f"trustpoint {name} has no router certificate — enrollment did not complete"]
    if status.lower() != "available":
        return [f"trustpoint {name} certificate status is {status}, not Available"]
    logger.info(f"Certificate verified on trustpoint {name}")
    if verified is not None:
        verified.append(f"certificate ({name})")
    return []


_APN_RE = re.compile(r"Profile\s+1\s*=.*?Access Point Name \(APN\)\s*=\s*(\S+)", re.DOTALL | re.IGNORECASE)


def _parse_profile_apn(output):
    """APN of profile 1 from `show cellular X profile`, or None."""
    match = _APN_RE.search(output or "")
    return match.group(1) if match else None


def _check_apn_profile(child, device, settings, logger, verified=None):
    """Return [] when every modem's profile 1 carries the configured APN."""
    modules = _cell_fw._find_cellular_modules(device)
    if not modules:
        return []
    apn = _cell_profile._resolve_apn(device, settings)
    if apn is None:
        return []

    failures = []
    for _, _, subslot in modules:
        logger.info(f"Checking APN profile on subslot {subslot}")
        output = child.send_command(f"show cellular {subslot} profile", read_timeout=30)
        found = _parse_profile_apn(output)
        if found is None:
            failures.append(f"modem {subslot}: no profile 1 with an APN — profile apply did not take")
        elif found.lower() != apn.lower():
            failures.append(f"modem {subslot}: profile 1 APN is {found}, expected {apn}")
        else:
            logger.info(f"APN profile verified on subslot {subslot}: {apn}")
            if verified is not None:
                verified.append(f"APN {apn}")
    return failures


# The modem re-registers after the APN step's profile reboot; give it a
# bounded window to attach before calling it a failure.
_ATTACH_WAIT = 180
_ATTACH_INTERVAL = 15
# IOS: "Packet Service = LTE (Attached)"; IOS-XE: "Packet switch domain(PS) state = Attached"
_ATTACHED_RE = re.compile(r"\(Attached\)|state\s*=\s*Attached\b", re.IGNORECASE)
_DETACHED_RE = re.compile(r"\(Detached\)|state\s*=\s*Detached\b", re.IGNORECASE)
_SERVICE_STATUS_RE = re.compile(r"Current Service Status\s*=\s*([^\r\n]+)", re.IGNORECASE)


def _parse_attach(output):
    """(attached, service_status) from `show cellular X network`."""
    status_match = _SERVICE_STATUS_RE.search(output or "")
    status = status_match.group(1).strip() if status_match else "unknown"
    attached = bool(_ATTACHED_RE.search(output or "")) or (
        status.lower() == "normal" and not _DETACHED_RE.search(output or "")
    )
    return attached, status


def _check_cell_attached(child, device, settings, logger, verified=None):
    """Return [] when every modem is attached to the network."""
    modules = _cell_fw._find_cellular_modules(device)
    if not modules or _cell_profile._resolve_apn(device, settings) is None:
        return []

    failures = []
    for _, _, subslot in modules:
        logger.info(f"Checking network attach on subslot {subslot} (up to {_ATTACH_WAIT}s)")
        deadline = time.time() + _ATTACH_WAIT
        attached, status = False, "unknown"
        while True:
            output = child.send_command(f"show cellular {subslot} network", read_timeout=30)
            attached, status = _parse_attach(output)
            if attached or time.time() >= deadline:
                break
            time.sleep(_ATTACH_INTERVAL)
        if attached:
            logger.info(f"Modem {subslot} attached (service status {status})")
            if verified is not None:
                verified.append(f"modem {subslot} attached")
        else:
            failures.append(
                f"modem {subslot} not attached after {_ATTACH_WAIT}s (service status: {status})"
            )
    return failures


# Advisory until a bench cycle has proven the normalisation — flip to True to
# fail the pipeline on intended lines missing from the running config.
_CONFIG_DIFF_HARD = False
_CONFIG_DIFF_REPORT_CAP = 40
# Lines the device stores transformed (hashed/encrypted), so they never
# compare equal to the intended text.
_CONFIG_SECRET_RE = re.compile(
    r"\b(secret|password|passphrase|key|community|pre-shared-key|auth-key|authentication-key|md5)\b",
    re.IGNORECASE,
)


def _config_parser_os(device):
    """netutils parser key for the device — cisco_xe has no parser of its own."""
    from netutils.config.compliance import parser_map

    driver = getattr(getattr(device, "platform", None), "network_driver", None) or ""
    return driver if driver in parser_map else "cisco_ios"


def _missing_config_lines(intended, running, network_os):
    """Intended lines absent from running, split into (real, secret-bearing)."""
    from netutils.config.compliance import diff_network_config

    missing = diff_network_config(intended, running, network_os)
    real, secret = [], []
    for line in missing.splitlines():
        if not line.strip():
            continue
        (secret if _CONFIG_SECRET_RE.search(line) else real).append(line)
    return real, secret


def _check_config_applied(child, device, settings, logger, verified=None):
    """Compare the intended config against the running config after the push.

    config_push only knows what the device REJECTED; this catches what it
    silently ignored. Lines carrying secrets are excluded (stored hashed).
    """
    try:
        intended = _config_push._resolve_intended_config(device, settings, logger)
    except Exception as exc:  # the push would have failed first; don't fail twice
        logger.warning(f"Config comparison skipped — intended config unavailable: {exc}")
        return []

    logger.info("Comparing intended config against running-config")
    running = child.send_command("show running-config", read_timeout=120)
    real, secret = _missing_config_lines(intended, running, _config_parser_os(device))

    if not real:
        logger.info(
            "Running config contains every intended line"
            + (f" ({len(secret)} secret-bearing lines not compared)" if secret else "")
        )
        if verified is not None:
            verified.append("config applied")
        return []

    shown = [_config_push._redact_line(line) for line in real[:_CONFIG_DIFF_REPORT_CAP]]
    more = f"\n  … {len(real) - len(shown)} more" if len(real) > len(shown) else ""
    report = f"{len(real)} intended line(s) missing from running-config:\n  " + "\n  ".join(shown) + more
    if _CONFIG_DIFF_HARD:
        return [report]
    logger.warning(f"{report}\n(advisory — not failing the run)")
    if verified is not None:
        verified.append(f"config applied ({len(real)} lines missing, advisory)")
    return []
