"""Certificate enrollment via NDES.

Parses the device's intended config from Golden Config to extract trustpoint
parameters, then enrolls via NDES. No role matching or app settings needed
for PKI — the intended config is the single source of truth.

Where the NDES server IS comes from the trustpoint's `enrollment url` (see
`resolve_ndes`): its hostname is what the device must resolve, and the same
server hosts the Microsoft admin page the worker fetches the OTP from.
"""

import codecs
import ipaddress
import re
import subprocess
import time
from urllib.parse import urlsplit

from nautobot.extras.models import SecretsGroup

from ..console import EXEC_PROMPT, CFG_PROMPT


def applies_to(device, settings):
    """True if the device has a router role."""
    role = device.role.name.lower() if device.role else ""
    return "router" in role


def preflight(device, settings):
    from nautobot.extras.models import SecretsGroup

    issues = []

    tp = _parse_trustpoint_from_intended(device)
    if tp is None:
        issues.append("No trustpoint block found in intended config")
        return issues

    if not tp.get("enrollment_url"):
        issues.append("No enrollment URL in trustpoint block")
    if not tp.get("key_label"):
        issues.append("No rsakeypair in trustpoint block")

    ndes = resolve_ndes(device, settings, tp)
    if not ndes["ip"]:
        if ndes["host"]:
            issues.append(
                f"Cannot determine the NDES IP — no 'ip host' line for '{ndes['host']}' "
                "(the enrollment URL host) in the intended config and no NDES IP override in settings"
            )
        else:
            issues.append("Cannot determine the NDES server — no host in the enrollment URL and no NDES host/IP override in settings")

    lo0 = _parse_loopback0_from_intended(device)
    if lo0 is None:
        issues.append(
            "No Loopback0 with an IP address in intended config — needed as the "
            "http client source-interface for SCEP enrollment"
        )

    sg_name = settings.get("ndes_secrets_group", "")
    if not sg_name:
        issues.append("No ndes_secrets_group in app settings")
    else:
        try:
            from nautobot.extras.models import SecretsGroupAssociation
            sg = SecretsGroup.objects.get(name=sg_name)
            has_user = SecretsGroupAssociation.objects.filter(
                secrets_group=sg, access_type="Generic", secret_type="username",
            ).exists()
            has_pass = SecretsGroupAssociation.objects.filter(
                secrets_group=sg, access_type="Generic", secret_type="password",
            ).exists()
            if not has_user:
                issues.append(f"Secrets group '{sg_name}' has no Generic/username secret")
            if not has_pass:
                issues.append(f"Secrets group '{sg_name}' has no Generic/password secret")
        except SecretsGroup.DoesNotExist:
            issues.append(f"Secrets group '{sg_name}' not found")

    return issues


def run(child, device, session, settings, logger):
    """Parse intended config for trustpoint settings, then enroll."""
    tp = _parse_trustpoint_from_intended(device)

    if not tp:
        logger.info("No trustpoint block in intended config — skipping cert enrollment")
        return "No trustpoint in intended config — skipped"

    logger.info(f"Trustpoint: {tp['name']} — enrollment via {tp['enrollment_url']}")

    ndes = resolve_ndes(device, settings, tp)
    logger.info(
        f"NDES server: {ndes['host'] or 'no hostname'} / {ndes['ip'] or 'IP unknown'}"
        + (f" (IP from {ndes['source']})" if ndes["source"] else "")
    )
    if ndes["ip"]:
        _check_ndes_reachability(child, ndes["ip"], settings.get("vrf_name", "MGMT"), logger)

    otp = _retrieve_otp(device, tp, ndes, settings, logger)
    child.register_secret(otp)
    _enroll_certificate(child, device, otp, tp, settings, logger)
    return f"Trustpoint {tp['name']} enrolled"


def _parse_trustpoint_from_intended(device):
    """Extract trustpoint config from the device's Golden Config intended config."""
    try:
        from nautobot_golden_config.models import GoldenConfig
        gc = GoldenConfig.objects.get(device=device)
    except Exception:
        return None

    if not gc.intended_config:
        return None

    tp = {"name": None, "enrollment_url": None, "vrf": None, "key_label": None}
    in_tp = False

    for line in gc.intended_config.splitlines():
        stripped = line.strip()

        match = re.match(r"crypto pki trustpoint\s+(\S+)", stripped)
        if match:
            tp["name"] = match.group(1)
            in_tp = True
            continue

        if in_tp:
            if stripped and not stripped.startswith("!") and not line.startswith(" "):
                break

            m = re.match(r"enrollment url\s+(\S+)", stripped)
            if m:
                tp["enrollment_url"] = m.group(1)

            m = re.match(r"rsakeypair\s+(\S+)", stripped)
            if m:
                tp["key_label"] = m.group(1)

            m = re.match(r"vrf\s+(\S+)", stripped)
            if m:
                tp["vrf"] = m.group(1)

    if not tp["name"]:
        return None

    return tp


def _parse_loopback0_from_intended(device):
    """Extract Loopback0 settings (ip/mask, optional vrf) from intended config.

    Returns {"ip": ..., "mask": ..., "vrf": ...} or None if Loopback0 has no
    IP address in the intended config.
    """
    try:
        from nautobot_golden_config.models import GoldenConfig
        gc = GoldenConfig.objects.get(device=device)
    except Exception:
        return None

    if not gc.intended_config:
        return None

    lo0 = {"ip": None, "mask": None, "vrf": None}
    in_block = False

    for line in gc.intended_config.splitlines():
        stripped = line.strip()

        if re.match(r"interface Loopback0\s*$", stripped, re.IGNORECASE):
            in_block = True
            continue

        if in_block:
            if stripped and not stripped.startswith("!") and not line.startswith(" "):
                break
            m = re.match(r"ip address\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)", stripped)
            if m:
                lo0["ip"], lo0["mask"] = m.group(1), m.group(2)
            m = re.match(r"vrf forwarding\s+(\S+)", stripped)
            if m:
                lo0["vrf"] = m.group(1)

    if not lo0["ip"]:
        return None
    return lo0


def _intended_config(device):
    """The device's Golden Config intended config text, or None."""
    try:
        from nautobot_golden_config.models import GoldenConfig
        gc = GoldenConfig.objects.get(device=device)
    except Exception:
        return None
    return gc.intended_config or None


def _is_ip_literal(text):
    try:
        ipaddress.ip_address(text)
        return True
    except ValueError:
        return False


def _ip_host_entry(intended, hostname):
    """IP from an `ip host [vrf X] <hostname> <ip>` line, exact hostname match."""
    if not intended or not hostname:
        return None
    pattern = re.compile(
        r"^ip host\s+(?:vrf\s+\S+\s+)?" + re.escape(hostname) + r"\s+(\d+\.\d+\.\d+\.\d+)\b",
        re.IGNORECASE,
    )
    for line in intended.splitlines():
        match = pattern.match(line.strip())
        if match:
            return match.group(1)
    return None


def resolve_ndes(device, settings, tp=None):
    """Locate the NDES server from the trustpoint enrollment URL.

    Returns {"host", "ip", "source", "scheme", "port"}:
      host   — hostname the DEVICE resolves (the URL host; the NDES host
               override only when the URL has none)
      ip     — the URL host itself when it is an IP literal, else the exact
               `ip host` line for that hostname in the intended config, else
               the NDES IP override from settings; None when unknown
      source — where the IP came from, for logs/preflight
      scheme/port — from the URL, reused for the admin (OTP) URL
    Nothing here keys on the word "ndes": any server name in the URL works.
    """
    if tp is None:
        tp = _parse_trustpoint_from_intended(device)
    url = (tp or {}).get("enrollment_url") or ""
    parts = urlsplit(url) if "://" in url else None
    host = parts.hostname if parts else None
    scheme = (parts.scheme if parts and parts.scheme else "http")
    port = parts.port if parts else None

    ip = source = None
    if host and _is_ip_literal(host):
        ip, source = host, "enrollment URL"
    elif host:
        ip = _ip_host_entry(_intended_config(device), host)
        if ip:
            source = "intended config ip host"
    if not ip and settings.get("ndes_ip"):
        ip, source = settings["ndes_ip"], "NDES IP override"
    if not host:
        host = settings.get("ndes_host") or None

    return {"host": host, "ip": ip, "source": source, "scheme": scheme, "port": port}


def _admin_url(ndes, settings):
    """Microsoft NDES admin page on the enrollment server (same host, scheme
    and port as the enrollment URL). The NDES host override, when set,
    replaces the host for the WORKER's request only."""
    host = settings.get("ndes_host") or ndes["host"] or ndes["ip"]
    if not host:
        raise ValueError("Cannot determine the NDES admin URL — no enrollment URL host and no NDES host/IP override")
    netloc = f"{host}:{ndes['port']}" if ndes.get("port") else host
    return f"{ndes.get('scheme') or 'http'}://{netloc}/CertSrv/mscep_admin/"


def _parse_ndes_ip_from_intended(device):
    """NDES IP as the intended config alone determines it (no settings)."""
    return resolve_ndes(device, {})["ip"]


def _check_ndes_reachability(child, ndes_ip, vrf, logger):
    """Ping NDES through the VRF before attempting enrollment."""
    logger.info(f"Making sure we can reach NDES ({ndes_ip}) before starting enrollment")
    output = child.send_command(f"ping vrf {vrf} {ndes_ip}", read_timeout=30)

    m = re.search(r"Success rate is (\d+) percent", output)
    if not m or m.group(1) != "100":
        raise RuntimeError(f"Can't reach NDES at {ndes_ip} — check VRF routing or NDES server status")


def _retrieve_otp(device, tp, ndes, settings, logger):
    secrets_group = SecretsGroup.objects.get(name=settings["ndes_secrets_group"])
    from nautobot.extras.models import SecretsGroupAssociation
    ndes_username = SecretsGroupAssociation.objects.get(
        secrets_group=secrets_group, access_type="Generic", secret_type="username",
    ).secret.get_value()
    ndes_password = SecretsGroupAssociation.objects.get(
        secrets_group=secrets_group, access_type="Generic", secret_type="password",
    ).secret.get_value()
    domain = settings.get("domain_name", "example.net")

    admin_url = _admin_url(ndes, settings)

    logger.info(f"Requesting one-time password from NDES ({admin_url})")
    command = [
        "curl", "--silent", "--insecure",
        "--url", admin_url,
        "--ntlm",
        "--user", f"{ndes_username}@{domain}:{ndes_password}",
    ]

    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    if result.returncode != 0:
        stderr_text = result.stderr.decode("utf-8", errors="replace")
        raise ValueError(f"NDES request failed: {stderr_text}")

    try:
        decoded = codecs.decode(result.stdout, "utf-16")
    except (UnicodeDecodeError, ValueError):
        decoded = result.stdout.decode("utf-8", errors="replace")

    match = re.search(r"[A-Z0-9]{16}", decoded)
    if not match:
        raise ValueError("Didn't get an OTP back from NDES — check credentials and server health")

    logger.info("Got OTP from NDES")
    return match.group()


def _enroll_certificate(child, device, otp, tp, settings, logger):
    trustpoint_name = tp["name"]
    key_label = tp.get("key_label") or settings.get("key_label", "kr_OT")
    domain = settings.get("domain_name", "example.net")
    vrf = tp.get("vrf") or settings.get("vrf_name", "MGMT")
    enrollment_url = tp.get("enrollment_url") or ""

    trustpoint_configured = False

    try:
        _clear_existing_trustpoint(child, trustpoint_name, logger)

        # PKI enrollment is an interactive dialog (yes/no prompts, keygen,
        # install banners), so this section drives the raw channel inside one
        # managed config session rather than using send_config_set.
        child.drain(quiet=0.3, max_wait=5)
        child.sendline("config t")
        child.expect([CFG_PROMPT], timeout=15, where="cert_cfg_t")

        _configure_http_client_source(child, device, logger)
        _generate_rsa_keys(child, key_label, logger)

        logger.info(f"Configuring trustpoint '{trustpoint_name}'")
        config_commands = [
            f"crypto pki trustpoint {trustpoint_name}",
            " enrollment mode ra",
            f" enrollment url {enrollment_url}",
            " serial-number",
            f" subject-name cn={device.name}.{domain}",
            f" subject-alt-name {device.name}.{domain}",
            f" vrf {vrf}",
            " revocation-check none",
            f" rsakeypair {key_label}",
            " auto-enroll 70 regenerate",
            f" password {otp}",
        ]
        for cmd in config_commands:
            child.sendline(cmd)
            child.expect([CFG_PROMPT, r"\(config.*\)#"], timeout=45, where=f"cert_cfg:{cmd.strip()}")

        trustpoint_configured = True

        _authenticate_trustpoint(child, trustpoint_name, logger)
        _enroll_trustpoint(child, trustpoint_name, logger)

        poll_timeout = settings.get("cert_poll_timeout", 90)
        poll_interval = settings.get("cert_poll_interval", 5)
        if not _poll_certificate(child, trustpoint_name, poll_timeout, poll_interval, logger):
            raise ValueError(f"Certificate didn't come back after {poll_timeout}s — CA may be backed up or unreachable")

        _disable_trustpoint_password(child, trustpoint_name, logger)

        child.sendline("end")
        child.expect([EXEC_PROMPT], timeout=15, where="cert_end")
        child.drain(quiet=0.3, max_wait=3)  # clear any post-config %SYS syslog before netmiko re-detects the prompt
        child.save_config()

        logger.info("Certificate enrolled and saved — device has its identity")

    except Exception:
        if trustpoint_configured:
            logger.warning("Something went wrong — rolling back trustpoint config")
            try:
                child.sendline("end")
                child.expect([EXEC_PROMPT], timeout=10, where="rollback_end")
                _clear_existing_trustpoint(child, trustpoint_name, logger)
            except Exception as rollback_err:
                logger.error(f"Rollback failed too: {rollback_err}")
        raise


def _configure_http_client_source(child, device, logger):
    """Bring up Loopback0 from the intended config and source SCEP from it.

    IOS SCEP enrollment rides the HTTP client; the CA/NDES side expects
    requests sourced from the device's Loopback0. Must be called while
    already in config mode.
    """
    lo0 = _parse_loopback0_from_intended(device)
    if lo0 is None:
        logger.warning(
            "No Loopback0 with an IP in intended config — SCEP will source from "
            "the egress interface instead"
        )
        return

    logger.info(f"Configuring Loopback0 ({lo0['ip']}) as the http client source-interface")
    commands = ["interface Loopback0"]
    if lo0["vrf"]:
        commands.append(f" vrf forwarding {lo0['vrf']}")
    commands.extend([
        f" ip address {lo0['ip']} {lo0['mask']}",
        " no shutdown",
        "exit",
        "ip http client source-interface Loopback0",
    ])
    for cmd in commands:
        child.sendline(cmd)
        child.expect([CFG_PROMPT, r"\(config.*\)#"], timeout=15, where=f"lo0:{cmd.strip()}")


def _generate_rsa_keys(child, key_label, logger):
    """Generate the RSA keypair with a keygen-sized timeout.

    4096-bit generation can take minutes on small platforms — the per-line
    45s timeout used for trustpoint config desynchronizes the console if the
    keygen is still running. Also handles the 'already have RSA keys …
    replace them?' prompt left behind by a previous enrollment attempt
    (removing the trustpoint does not remove its keypair).
    """
    logger.info(f"Generating RSA keys (label {key_label}, 4096-bit) — this can take several minutes")
    child.drain(quiet=0.3, max_wait=5)
    child.sendline(f"crypto key generate rsa modulus 4096 label {key_label}")
    idx, _ = child.expect(
        [
            CFG_PROMPT,                                   # 0: done
            r"replace them\?\s*\[yes/no\]:",              # 1: keypair exists
            r"%\s*Invalid",                               # 2: wrong mode / desynced console
            r"[Pp]lease define a domain-name",            # 3: prerequisite missing
        ],
        timeout=1800,
        where="cert_keygen",
    )
    if idx == 1:
        logger.info("Keypair from a previous attempt found — regenerating")
        child.sendline("yes")
        idx, _ = child.expect([CFG_PROMPT], timeout=1800, where="cert_keygen_replace")
    elif idx == 2:
        raise RuntimeError(
            "RSA keygen command rejected (% Invalid) — the console is likely not "
            "in config mode (a desynced session leaves commands landing at the "
            "wrong prompt)"
        )
    elif idx == 3:
        raise RuntimeError(
            "Device requires an ip domain name before RSA key generation — "
            "the staging step should have set it; check the staging config applied"
        )
    if idx is None:
        raise RuntimeError(
            f"RSA key generation didn't finish within 30 minutes — "
            f"console showed: {child.tail()}"
        )


def _clear_existing_trustpoint(child, trustpoint_name, logger):
    output = child.send_command("show crypto pki trustpoints", read_timeout=30)

    if trustpoint_name not in output:
        return

    logger.info(f"Cleaning up old trustpoint '{trustpoint_name}' first")
    child.drain(quiet=0.3, max_wait=5)
    child.sendline("config t")
    child.expect([CFG_PROMPT], timeout=10, where="clear_tp_cfg_t")
    child.sendline(f"no crypto pki trustpoint {trustpoint_name}")

    idx, _ = child.expect(
        [r"Are you sure you want to do this.*\[yes/no\]:", CFG_PROMPT],
        timeout=15,
        where="clear_tp_confirm",
    )
    if idx == 0:
        child.sendline("yes")
        child.expect([CFG_PROMPT], timeout=15, where="clear_tp_yes")

    child.sendline("end")
    child.expect([EXEC_PROMPT], timeout=10, where="clear_tp_end")


def _authenticate_trustpoint(child, trustpoint_name, logger):
    logger.info("Authenticating against the CA")
    child.sendline(f"crypto pki authenticate {trustpoint_name}")
    idx, _ = child.expect(
        [r"Do you accept this certificate.*\[yes/no\]:", r"Trustpoint CA certificate accepted"],
        timeout=60,
        where="pki_auth",
    )
    if idx == 0:
        child.sendline("yes")
        child.expect([r"Trustpoint CA certificate accepted", CFG_PROMPT], timeout=60, where="pki_auth_accept")


def _enroll_trustpoint(child, trustpoint_name, logger):
    logger.info("Submitting certificate request to NDES")
    child.sendline(f"crypto pki enroll {trustpoint_name}")

    idx, _ = child.expect(
        [
            r"Include the router serial number.*\[yes/no\]:",
            r"Include an IP address.*\[no\]:",
            r"Request certificate from CA.*\[yes/no\]:",
        ],
        timeout=60,
        where="pki_enroll_first",
    )

    if idx == 0:
        child.sendline("no")
        child.expect([r"Include an IP address.*\[no\]:"], timeout=30, where="pki_enroll_ip")
        child.sendline("no")
        child.expect([r"Request certificate from CA.*\[yes/no\]:"], timeout=30, where="pki_enroll_req")
        child.sendline("yes")
    elif idx == 1:
        child.sendline("no")
        child.expect([r"Request certificate from CA.*\[yes/no\]:"], timeout=30, where="pki_enroll_req2")
        child.sendline("yes")
    elif idx == 2:
        child.sendline("yes")

    enroll_idx, _ = child.expect(
        [r"%PKI-6-CERT_INSTALL", r"request was rejected", CFG_PROMPT],
        timeout=120,
        where="pki_enroll_result",
    )
    if enroll_idx == 1:
        raise ValueError("NDES rejected the enrollment request — OTP may have expired or been used already")

    child.expect([CFG_PROMPT], timeout=30, where="pki_enroll_return")


def _poll_certificate(child, trustpoint_name, timeout, interval, logger):
    status_pattern = re.compile(r"Status:\s*Available", re.IGNORECASE)
    start = time.time()
    logger.info(f"Waiting for certificate to be issued (up to {timeout}s)")

    while time.time() - start < timeout:
        child.drain(quiet=0.3, max_wait=5)
        child.sendline(f"do show crypto pki certificate {trustpoint_name}")
        _idx, output = child.expect([CFG_PROMPT, EXEC_PROMPT], timeout=15, where="cert_poll")
        if status_pattern.search(output):
            logger.info("Certificate issued and installed")
            return True
        time.sleep(interval)

    logger.error(f"Timed out after {timeout}s waiting for certificate")
    return False


def _disable_trustpoint_password(child, trustpoint_name, logger):
    child.sendline(f"crypto pki trustpoint {trustpoint_name}")
    child.expect([CFG_PROMPT, r"\(ca-trustpoint\)#"], timeout=10, where="tp_reenter")
    child.sendline("no password")
    child.expect([CFG_PROMPT, r"\(ca-trustpoint\)#"], timeout=10, where="tp_no_pass")
    child.sendline("exit")
    child.expect([CFG_PROMPT], timeout=10, where="tp_exit")
