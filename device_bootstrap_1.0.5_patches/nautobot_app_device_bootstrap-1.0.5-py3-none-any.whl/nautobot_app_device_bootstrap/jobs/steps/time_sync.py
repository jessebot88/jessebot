"""Set the device clock and apply the intended NTP config early.

Certificate enrollment fails with "certificate is not yet valid" when a
factory-default device's clock is behind the CA, so this runs before any
PKI work. The clock is set immediately from the worker's UTC time (instant,
no sync wait). Then the device's own `ntp ...` lines are applied verbatim
from the intended config (Golden Config) — nothing is invented here, and
since the lines ARE the intended state they stay in place; config_push
simply re-applies them as a no-op later.
"""

import re
from datetime import datetime, timezone

_NTP_LINE = re.compile(r"^ntp\s+\S+", re.IGNORECASE)


def _parse_ntp_lines_from_intended(device):
    """Return top-level `ntp ...` lines from the intended config, verbatim."""
    try:
        from nautobot_golden_config.models import GoldenConfig
        gc = GoldenConfig.objects.get(device=device)
    except Exception:
        return []

    if not gc.intended_config:
        return []

    lines = []
    for raw in gc.intended_config.splitlines():
        if raw.startswith(" "):
            continue
        stripped = raw.strip()
        if _NTP_LINE.match(stripped) and stripped not in lines:
            lines.append(stripped)
    return lines


def _loopback0_commands(device, logger):
    """Config lines that create Loopback0 from the intended config.

    The intended ntp config references Loopback0 as its source, but nothing
    has created the interface this early in the pipeline (cert_enroll builds
    it much later), so the source line would error on the device. Uses the
    same intended-config shape as cert_enroll so config_push re-applies it
    as a no-op.
    """
    from .cert_enroll import _parse_loopback0_from_intended

    lo0 = _parse_loopback0_from_intended(device)
    if lo0 is None:
        logger.warning(
            "ntp config sources from Loopback0 but the intended config has no "
            "Loopback0 with an IP — the ntp source line will error until config push"
        )
        return []

    logger.info(f"Creating Loopback0 ({lo0['ip']}) so the ntp source line applies cleanly")
    commands = ["interface Loopback0"]
    if lo0["vrf"]:
        commands.append(f" vrf forwarding {lo0['vrf']}")
    commands.extend([
        f" ip address {lo0['ip']} {lo0['mask']}",
        " no shutdown",
        "exit",
    ])
    return commands


def run(child, device, session, settings, logger):
    """Set the clock from worker time, then apply intended NTP config."""
    now = datetime.now(timezone.utc)
    child.send_command_timing(now.strftime("clock set %H:%M:%S %d %b %Y"))
    logger.info(f"Clock set to {now:%Y-%m-%d %H:%M:%S} UTC")

    ntp_lines = _parse_ntp_lines_from_intended(device)
    if not ntp_lines:
        logger.info("No ntp lines in intended config — clock set only")
        return "Clock set; no ntp lines in intended config"

    commands = []
    if any(re.search(r"\bsource\s+Loopback0\b", line, re.IGNORECASE) for line in ntp_lines):
        commands += _loopback0_commands(device, logger)
    commands += ntp_lines

    child.send_config_set(commands, read_timeout=30)
    logger.info(f"Applied {len(ntp_lines)} ntp line(s) from intended config")
    return f"Clock set; {len(ntp_lines)} ntp line(s) applied"
