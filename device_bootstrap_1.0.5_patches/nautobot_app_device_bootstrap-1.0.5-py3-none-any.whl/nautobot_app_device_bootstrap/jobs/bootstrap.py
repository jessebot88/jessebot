"""Bootstrap pipeline executor.

Runs a configurable sequence of steps to bring a device from factory default
to fully configured. The pipeline is defined in app settings and can be
customized per environment via env vars:

    BOOTSTRAP_PIPELINE_ROUTER=factory_default,staging,serial_verify,connectivity,time_sync,os_image,license,reload,connectivity,cell_firmware,cell_firmware_reset,connectivity,cert_enroll,staging_cleanup,cell_profile,config_push,validate,console_release
    BOOTSTRAP_PIPELINE_SWITCH=factory_default,staging,serial_verify,time_sync,os_image,license,reload,staging_cleanup,config_push,validate,console_release

Teams can remove steps (e.g. drop cert_enroll) or add custom ones by
registering new modules in jobs/steps/__init__.py.
"""

from django.core.cache import cache
from django.utils import timezone
from nautobot.apps.jobs import BooleanVar, IntegerVar, Job, MultiObjectVar, ObjectVar, StringVar
from nautobot.dcim.models import Device
from nautobot.extras.models import ExternalIntegration

from nautobot_app_device_bootstrap.app_settings import get_settings
from nautobot_app_device_bootstrap.models import BootstrapSession

from . import console, drivers, steps
from .console import ConsoleSessionLost


SESSION_LOG_KEY = "bootstrap:sessionlog:{pk}"


class SessionLogProxy:
    """Mirror step log lines into cache so the progress page's Activity Log
    shows what a step is actually doing (flash checks, transfers, verification)
    instead of just the step name.

    Cache-only by design — the durable record is the Nautobot JobResult log;
    mirroring avoids a schema migration so wheel-swap deploys stay simple.
    Steps already redact secrets before logging, so mirrored lines are safe.
    """

    def __init__(self, logger, session_pk, ttl=7200, max_lines=300):
        self._logger = logger
        self._key = SESSION_LOG_KEY.format(pk=session_pk)
        self._ttl = ttl
        self._max = max_lines

    def _mirror(self, level, message):
        try:
            entry = {
                "timestamp": timezone.localtime().strftime("%H:%M:%S"),
                "level": level,
                "message": str(message),
            }
            lines = cache.get(self._key) or []
            lines.append(entry)
            cache.set(self._key, lines[-self._max:], timeout=self._ttl)
        except Exception:  # never let display plumbing break provisioning
            pass

    def info(self, message, *args, **kwargs):
        self._mirror("info", message)
        self._logger.info(message, *args, **kwargs)

    def warning(self, message, *args, **kwargs):
        self._mirror("warning", message)
        self._logger.warning(message, *args, **kwargs)

    def error(self, message, *args, **kwargs):
        self._mirror("error", message)
        self._logger.error(message, *args, **kwargs)

    def debug(self, message, *args, **kwargs):
        # Debug lines go to the JobResult log only — the progress page's
        # Activity Log stays operator-readable (no DBPERSIST internals).
        self._logger.debug(message, *args, **kwargs)

    def __getattr__(self, name):
        # Safety net: any logger method this proxy doesn't wrap (exception(),
        # critical(), future additions) delegates to the real logger instead
        # of AttributeError-ing a live provisioning session mid-upgrade.
        return getattr(self._logger, name)


def _default_file_server():
    """Resolve the default file-server ExternalIntegration at form-render time.

    Name comes from plugin setting 'default_file_server_ei_name' (default "Firmware Webserver").
    """
    name = get_settings().get(
        "default_file_server_ei_name", "Firmware Webserver"
    )
    return ExternalIntegration.objects.filter(name=name).first()


class DeviceBootstrapJob(Job):
    class Meta:
        name = "Provision Device"
        description = "Provision routers or switches via OpenGear console — firmware, certificates, config, and validation."
        has_sensitive_variables = False

    devices = MultiObjectVar(
        model=Device,
        required=True,
        label="Devices",
        description="Select one or more devices to provision.",
    )
    opengear = ObjectVar(
        model=Device,
        required=False,
        label="OpenGear Console Server (single device override)",
        description="Manual override — only needed if cable traces are not modeled.",
        query_params={"role": "console-server"},
    )
    console_port = IntegerVar(
        required=False,
        label="Console Port (single device override)",
        description="Port number on the OpenGear (1-48). Required if OpenGear is manually selected.",
    )
    file_server = ObjectVar(
        model=ExternalIntegration,
        required=True,
        label="File Server",
        description="ExternalIntegration for the staging file server (OS images + cell firmware). A SecretsGroup is only required for SCP; http/https servers may be anonymous.",
        default=_default_file_server,
    )
    dry_run = BooleanVar(default=True, label="Dry Run")
    batch_id = StringVar(
        required=False,
        label="Batch ID",
        description="Set automatically when a multi-device batch is launched from the provisioning page — leave blank when running manually.",
    )

    def run(self, devices, opengear=None, console_port=None, file_server=None, dry_run=True, batch_id=""):
        if not devices:
            self.logger.error("No devices selected")
            return

        # The var's default only renders on the job FORM — programmatic enqueues
        # (the provisioning page, the API) that omit file_server arrive here with
        # None, so resolve the Provisioning Settings default ourselves.
        if file_server is None:
            file_server = _default_file_server()
            if file_server is None:
                raise RuntimeError(
                    "No file server: none was passed and Provisioning Settings "
                    "has no default file server configured."
                )
            self.logger.info(f"Using default file server from settings: {file_server.name}")

        import uuid

        try:
            self._batch_id = uuid.UUID(batch_id) if batch_id else None
        except ValueError:
            self.logger.warning(f"Ignoring malformed batch_id '{batch_id}'")
            self._batch_id = None

        settings = get_settings()

        # Fail fast on any registry/pipeline drift before touching devices —
        # a mislabeled step or a typo'd pipeline entry should never surface
        # mid-provision on a half-configured router.
        steps.validate_registry()
        for key in sorted(set(drivers.PIPELINE_KEYS.values())):
            steps.validate_pipeline(settings.get(key, []), key)

        results = {"success": [], "failed": []}

        file_server_files = None
        try:
            file_server_files = console.get_file_server_files_cached(file_server)
            if file_server_files is None:
                if console.get_ei_scheme(file_server) in ("http", "https"):
                    self.logger.info(
                        f"File server '{file_server.name}' reachable — file presence will be "
                        f"verified per file via HTTP during preflight"
                    )
                else:
                    self.logger.info(
                        f"File server '{file_server.name}' reachable — file presence not "
                        f"verifiable for this protocol, presence checks will be skipped"
                    )
            else:
                self.logger.info(
                    f"File server '{file_server.name}' reachable — {len(file_server_files)} files at base path"
                )
        except Exception as e:
            self.logger.error(
                f"File server '{file_server.name}' check failed: {e} — aborting before touching any devices"
            )
            raise

        for device in devices:
            try:
                console_path = self._resolve_console(device, opengear, console_port)

                driver = drivers.get_driver(device)
                device_class = driver.classify(device)
                if device_class is None:
                    self.logger.warning(f"[{device.name}] Role '{device.role.name}' not recognized — skipping")
                    continue
                pipeline = settings[driver.pipeline_key(device_class)]

                device_settings = self._build_device_settings(device, settings)
                device_settings["file_server_ei"] = file_server
                device_settings["file_server_files"] = file_server_files
                pipeline = steps.filter_pipeline(pipeline, device, device_settings)
                self._run_pipeline(device, driver, device_class, pipeline, console_path, settings, file_server, file_server_files, dry_run)
                results["success"].append(device.name)

            except Exception as e:
                self.logger.error(f"[{device.name}] Provisioning failed: {e}")
                results["failed"].append(f"{device.name}: {e}")

        total = len(results["success"]) + len(results["failed"])
        self.logger.info(f"Finished — {len(results['success'])}/{total} devices provisioned successfully")
        if results["success"]:
            for name in results["success"]:
                self.logger.info(f"  ✓ {name}")
        if results["failed"]:
            self.logger.error("Devices that failed:")
            for entry in results["failed"]:
                self.logger.error(f"  ✗ {entry}")

    def _build_device_settings(self, device, settings):
        """Merge device config context into app defaults. Config context wins.

        PKI/trustpoint settings are no longer merged here — cert_enroll reads
        them directly from the device's intended config (Golden Config).
        """
        device_settings = dict(settings)
        # The user who ran the job — needed so config_push can render
        # Golden Config secrets (get_secret_by_secret_group_name is
        # permission-checked against this user).
        device_settings["job_user"] = self.user
        ctx = device.get_config_context()
        trustpoint = ctx.get("trustpoint", {})

        if not trustpoint:
            return device_settings

        if trustpoint.get("vrf"):
            device_settings["vrf_name"] = trustpoint["vrf"]
        if trustpoint.get("rd"):
            device_settings["vrf_rd"] = trustpoint["rd"]
        if trustpoint.get("ndes_secrets_group"):
            device_settings["ndes_secrets_group"] = trustpoint["ndes_secrets_group"]

        return device_settings

    def _run_pipeline(self, device, driver, device_class, pipeline, console_path, settings, file_server, file_server_files, dry_run):
        """Execute the step pipeline for a single device."""
        allowed = settings.get("allowed_provisioning_statuses") or []
        current_status = device.status.name if device.status else "(no status)"
        if allowed and current_status not in allowed:
            raise RuntimeError(
                f"Refusing to provision {device.name} — status is '{current_status}', "
                f"expected one of: {', '.join(allowed)}. "
                f"Change the device status in Nautobot or adjust 'allowed_provisioning_statuses'."
            )

        lock_key = f"bootstrap:lock:{device.id}"
        if not cache.add(lock_key, "locked", timeout=3600):
            self.logger.warning(
                f"[{device.name}] Another provisioning run holds the device lock — skipping. "
                f"Clear with 'cache.delete(\"{lock_key}\")' if the other run is known-dead."
            )
            return

        try:
            device_settings = self._build_device_settings(device, settings)
            device_settings["file_server_ei"] = file_server
            device_settings["file_server_files"] = file_server_files

            session = BootstrapSession.objects.create(
                device=device,
                device_type_class=device_class,
                console_server=console_path["console_server"],
                console_port_number=console_path["port_number"],
                status="pending",
                batch_id=getattr(self, "_batch_id", None),
                job_result=self.job_result,
            )
            conn = {"child": None}

            try:
                og_name = console_path["console_server"].name
                og_port = console_path["port_number"]
                step_labels = " → ".join(steps.label(s) for s in pipeline)
                slog = SessionLogProxy(self.logger, session.pk)
                slog.info(f"[{device.name}] Connecting via {og_name} port {og_port}")
                slog.info(f"[{device.name}] Plan: {step_labels}")

                preflight_issues = steps.run_preflight(pipeline, device, device_settings)
                if preflight_issues:
                    details = "; ".join(f"{i['label']}: {i['detail']}" for i in preflight_issues)
                    raise RuntimeError(f"Preflight blocked provisioning — {details}")

                if dry_run:
                    self._dry_run_report(device, pipeline, console_path)
                    session.status = "complete"
                    session.completed_at = timezone.now()
                    session.save()
                    return

                og_user, og_pass = self._get_console_creds(console_path["console_server"])
                # Console transcript → job log, one debug entry per step.
                transcript = console.Transcript()
                for secret in (og_pass, device_settings.get("factory_default_enable_secret")):
                    transcript.register_secret(secret)
                conn["child"] = console.connect_console(
                    console_path, og_user, og_pass, slog, driver=driver, transcript=transcript
                )

                def _reconnect_console():
                    """Fresh OpenGear session — the old one can go half-dead
                    across a device reboot (writes silently dropped)."""
                    try:
                        conn["child"].close()
                    except Exception:
                        pass
                    conn["child"] = console.connect_console(
                        console_path, og_user, og_pass, slog, driver=driver, transcript=transcript
                    )
                    return conn["child"]

                device_settings["reconnect_console"] = _reconnect_console

                step_results = []

                for i, step_name in enumerate(pipeline, 1):
                    step_module = steps.get(step_name)
                    session.status = step_name
                    session.steps = step_results
                    session.save()
                    slog.info(f"[{device.name}] Step {i}/{len(pipeline)}: {steps.label(step_name)}")
                    try:
                        # conn["child"] rather than a local — the reload step
                        # swaps in a fresh session via reconnect_console.
                        # A step may return a one-line result summary; it is
                        # stored as the step's message and shown on the cards.
                        summary = step_module.run(conn["child"], device, session, device_settings, slog)
                        step_results.append({
                            "name": step_name,
                            "status": "complete",
                            "message": summary if isinstance(summary, str) else "",
                        })
                    except ConsoleSessionLost as e:
                        step_results.append({"name": step_name, "status": "failed", "message": str(e)})
                        session.steps = step_results
                        session.save()
                        slog.error(
                            f"[{device.name}] Lost the console session during '{steps.label(step_name)}' — "
                            f"the SSH connection to the OpenGear dropped"
                        )
                        raise RuntimeError(f"Console session lost during '{steps.label(step_name)}': {e}") from e
                    except Exception as e:
                        step_results.append({"name": step_name, "status": "failed", "message": str(e)})
                        session.steps = step_results
                        session.save()
                        raise
                    finally:
                        self._log_transcript(transcript, steps.label(step_name), slog)

                session.status = "complete"
                session.steps = step_results
                session.completed_at = timezone.now()
                session.save()
                slog.info(f"[{device.name}] All done — device is provisioned and on the network")

            except Exception as e:
                session.status = "failed"
                session.error_message = str(e)
                session.completed_at = timezone.now()
                session.save()
                raise
            finally:
                if conn["child"]:
                    try:
                        conn["child"].close()
                    except Exception:
                        pass
        finally:
            cache.delete(lock_key)

    def _resolve_console(self, device, opengear, console_port):
        if opengear and console_port:
            host = console._get_management_ip(opengear)
            return {
                "console_server": opengear,
                "port_number": console_port,
                "host": host,
            }
        return console.resolve_console_path(device)

    def _get_console_creds(self, console_server):
        sg = console_server.secrets_group
        if not sg:
            raise ValueError(f"Console server {console_server.name} has no secrets group assigned")
        from nautobot.extras.models import SecretsGroupAssociation
        username = SecretsGroupAssociation.objects.get(
            secrets_group=sg, access_type="Generic", secret_type="username",
        ).secret.get_value()
        password = SecretsGroupAssociation.objects.get(
            secrets_group=sg, access_type="Generic", secret_type="password",
        ).secret.get_value()
        return username, password

    @staticmethod
    def _log_transcript(transcript, label, slog):
        """Hand the step's console traffic to the job log as ONE debug entry,
        grouped by step, redacted, tail-capped. Never lets logging plumbing
        fail the run."""
        try:
            chunk = transcript.take()
            if chunk.strip():
                slog.debug(
                    console.Transcript.clip(chunk),
                    extra={"grouping": f"console: {label}"},
                )
        except Exception as exc:  # pragma: no cover - defensive
            slog.warning(f"Could not record the console transcript for '{label}': {exc}")

    def _dry_run_report(self, device, pipeline, console_path):
        settings = get_settings()
        device_settings = self._build_device_settings(device, settings)

        self.logger.info(f"[{device.name}] DRY RUN — here's what would happen:")
        self.logger.info(f"  Console: {console_path['console_server'].name} port {console_path['port_number']}")
        step_labels = ", ".join(steps.label(s) for s in pipeline)
        self.logger.info(f"  Steps: {step_labels}")

        from nautobot_app_device_bootstrap.jobs.steps.cert_enroll import (
            _parse_trustpoint_from_intended,
            resolve_ndes,
        )
        tp = _parse_trustpoint_from_intended(device)
        ndes = resolve_ndes(device, device_settings, tp)

        source = "intended config" if tp else "app defaults"
        self.logger.info(f"  Config source: {source}")
        self.logger.info(f"  VRF: {device_settings['vrf_name']} (rd {device_settings['vrf_rd']})")
        self.logger.info(
            f"  NDES: {ndes['host'] or 'no hostname'} / "
            f"{ndes['ip'] or 'IP not determined'}"
            + (f" ({ndes['source']})" if ndes["source"] else "")
        )
        if tp:
            self.logger.info(f"  Trustpoint: {tp['name']} / key: {tp.get('key_label', 'N/A')}")
        else:
            self.logger.info("  Trustpoint: not found in intended config")

        from nautobot_golden_config.models import GoldenConfig

        if "config_push" in pipeline:
            try:
                gc = GoldenConfig.objects.get(device=device)
                line_count = len(gc.intended_config.splitlines()) if gc.intended_config else 0
                self.logger.info(f"  Golden Config: ready ({line_count} lines)")
            except GoldenConfig.DoesNotExist:
                self.logger.warning(
                    "  Golden Config: NOT FOUND — this device needs intended config generated before provisioning"
                )
