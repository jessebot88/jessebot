"""Platform driver registry.

Drivers are resolved from Platform.network_driver. Devices with no platform
(or an unregistered network_driver) fall back to the Cisco IOS driver — the
app predates the driver seam and the whole existing fleet is Cisco, so the
fallback preserves that behavior instead of blocking provisioning on
platform hygiene.
"""

from .base import PlatformDriver  # noqa: F401  (re-export for subclasses/tests)
from .cisco_ios import CiscoIosDriver

_DEFAULT_DRIVER = CiscoIosDriver()

DRIVER_REGISTRY = {
    nd: _DEFAULT_DRIVER for nd in CiscoIosDriver.network_drivers
}

# Every pipeline settings key any driver can select — the orchestrator
# validates each of these against the step registry before touching a device.
PIPELINE_KEYS = {
    device_class: key
    for driver in {id(d): d for d in DRIVER_REGISTRY.values()}.values()
    for device_class, key in driver.pipeline_keys.items()
}


def get_driver(device):
    """Resolve the platform driver for a device (never None)."""
    platform = getattr(device, "platform", None)
    network_driver = getattr(platform, "network_driver", "") or ""
    return DRIVER_REGISTRY.get(network_driver, _DEFAULT_DRIVER)


def default_driver():
    """The fallback driver — also used where no device is in scope."""
    return _DEFAULT_DRIVER


def classify_device(device):
    """Shorthand: the device_class the resolved driver assigns, or None."""
    return get_driver(device).classify(device)
