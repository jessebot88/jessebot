from nautobot.apps.jobs import register_jobs

from .bootstrap import DeviceBootstrapJob

register_jobs(DeviceBootstrapJob)

__all__ = ["DeviceBootstrapJob"]
