import django_filters
from nautobot.apps.filters import NaturalKeyOrPKMultipleChoiceFilter, NautobotFilterSet, SearchFilter
from nautobot.dcim.models import Device

from nautobot_app_device_bootstrap.models import BootstrapSession


class BootstrapSessionFilterSet(NautobotFilterSet):
    q = SearchFilter(
        filter_predicates={
            "device__name": "icontains",
            "status": "icontains",
            "error_message": "icontains",
        },
    )
    device = NaturalKeyOrPKMultipleChoiceFilter(
        field_name="device",
        queryset=Device.objects.all(),
        to_field_name="name",
        label="Device (name or ID)",
    )
    status = django_filters.ChoiceFilter(choices=BootstrapSession._meta.get_field("status").choices)
    device_type_class = django_filters.ChoiceFilter(choices=BootstrapSession._meta.get_field("device_type_class").choices)

    class Meta:
        model = BootstrapSession
        fields = ["id", "status", "device_type_class", "started_at"]
