from nautobot.apps.ui import NavMenuGroup, NavMenuItem, NavMenuTab

menu_items = (
    NavMenuTab(
        name="Devices",
        groups=(
            NavMenuGroup(
                name="Provisioning",
                weight=200,
                items=(
                    NavMenuItem(
                        link="plugins:nautobot_app_device_bootstrap:bootstrapsession_list",
                        name="Provisioning Sessions",
                        permissions=["nautobot_app_device_bootstrap.view_bootstrapsession"],
                    ),
                    NavMenuItem(
                        link="plugins:nautobot_app_device_bootstrap:bootstrap_settings",
                        name="Provisioning Settings",
                        permissions=["nautobot_app_device_bootstrap.change_bootstrapsettings"],
                    ),
                ),
            ),
        ),
    ),
)
