from django import forms
from nautobot.apps.forms import NautobotFilterForm
from nautobot.extras.models import ExternalIntegration, JobQueue, SecretsGroup, Status

from nautobot_app_device_bootstrap.filters import BootstrapSessionFilterSet
from nautobot_app_device_bootstrap.models import BootstrapSettings


class BootstrapSessionFilterForm(NautobotFilterForm):
    model = BootstrapSessionFilterSet.Meta.model
    filterset_class = BootstrapSessionFilterSet


class BootstrapSettingsForm(forms.ModelForm):
    """Settings edit form. Pipelines are edited as one step per line — a
    multi-select would lose the ORDER, and order is what a pipeline is."""

    pipeline_router_text = forms.CharField(
        label="Router pipeline",
        widget=forms.Textarea(attrs={"rows": 16, "spellcheck": "false"}),
        help_text="One step per line, in execution order.",
    )
    pipeline_switch_text = forms.CharField(
        label="Switch pipeline",
        widget=forms.Textarea(attrs={"rows": 16, "spellcheck": "false"}),
        help_text="One step per line, in execution order.",
    )
    allowed_provisioning_statuses = forms.ModelMultipleChoiceField(
        queryset=Status.objects.all().order_by("name"), required=False
    )
    post_provision_status = forms.ModelChoiceField(
        queryset=Status.objects.all().order_by("name"), required=False
    )
    default_file_server = forms.ModelChoiceField(
        queryset=ExternalIntegration.objects.all().order_by("name"), required=False
    )
    provisioning_queue = forms.ModelChoiceField(
        queryset=JobQueue.objects.all().order_by("name"),
        required=False,
        empty_label="(default queue)",
    )
    ndes_secrets_group = forms.ModelChoiceField(
        queryset=SecretsGroup.objects.all().order_by("name"), required=False, label="NDES credentials"
    )
    local_admin_secrets_group = forms.ModelChoiceField(
        queryset=SecretsGroup.objects.all().order_by("name"), required=False, label="Local admin credentials"
    )

    class Meta:
        model = BootstrapSettings
        # Explicit list — PrimaryModel adds tags/custom-field plumbing that
        # must not leak into the settings page.
        fields = [
            "console_port_base",
            "provisioning_queue",
            "domain_name",
            "vrf_name",
            "vrf_rd",
            "staging_gateway",
            "mgmt_vlan",
            "connectivity_window",
            "factory_default_enable_secret",
            "allowed_provisioning_statuses",
            "post_provision_status",
            "default_file_server",
            "ndes_secrets_group",
            "ndes_host",
            "ndes_ip",
            "local_admin_secrets_group",
            "cell_firmware_cwe",
            "cell_firmware_firstnet_nvu",
            "cell_firmware_verizon_nvu",
            "cell_apn_firstnet",
            "cell_apn_verizon",
            "cell_apn_reboot_wait",
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.present_in_database:
            self.fields["pipeline_router_text"].initial = "\n".join(self.instance.pipeline_router or [])
            self.fields["pipeline_switch_text"].initial = "\n".join(self.instance.pipeline_switch or [])

    @staticmethod
    def _parse_pipeline(text, name):
        from nautobot_app_device_bootstrap.jobs import steps as step_registry

        pipeline = [line.strip() for line in (text or "").splitlines() if line.strip()]
        try:
            step_registry.validate_pipeline(pipeline, name)
        except ValueError as e:
            raise forms.ValidationError(str(e))
        return pipeline

    def clean_pipeline_router_text(self):
        return self._parse_pipeline(self.cleaned_data["pipeline_router_text"], "router pipeline")

    def clean_pipeline_switch_text(self):
        return self._parse_pipeline(self.cleaned_data["pipeline_switch_text"], "switch pipeline")

    def clean(self):
        cleaned = super().clean()
        # Assign here (not in save) so the model's own full_clean — which runs
        # during form validation — sees the NEW pipelines, not the old ones.
        if "pipeline_router_text" in self.cleaned_data:
            self.instance.pipeline_router = self.cleaned_data["pipeline_router_text"]
        if "pipeline_switch_text" in self.cleaned_data:
            self.instance.pipeline_switch = self.cleaned_data["pipeline_switch_text"]
        return cleaned
