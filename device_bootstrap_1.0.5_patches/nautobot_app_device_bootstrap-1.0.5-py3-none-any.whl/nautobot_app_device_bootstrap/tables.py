import django_tables2 as tables
from django.urls import reverse
from django.utils.html import format_html
from nautobot.apps.tables import BaseTable, ToggleColumn

from nautobot_app_device_bootstrap.models import BootstrapSession

STATUS_STYLE = {
    "pending":         {"color": "#868e96", "bg": "rgba(134,142,150,0.10)", "icon": "mdi-clock-outline",   "label": "Pending"},
    "factory_default": {"color": "#339af0", "bg": "rgba(51,154,240,0.10)",  "icon": "mdi-restart",         "label": "Factory Default"},
    "staging":         {"color": "#339af0", "bg": "rgba(51,154,240,0.10)",  "icon": "mdi-lan-pending",     "label": "Staging"},
    "serial_verify":   {"color": "#339af0", "bg": "rgba(51,154,240,0.10)",  "icon": "mdi-barcode-scan",    "label": "Serial Check"},
    "connectivity":    {"color": "#339af0", "bg": "rgba(51,154,240,0.10)",  "icon": "mdi-access-point-network", "label": "Connectivity"},
    "cert_enroll":     {"color": "#f59f00", "bg": "rgba(245,159,0,0.10)",   "icon": "mdi-certificate-outline", "label": "Certificate"},
    "staging_cleanup": {"color": "#339af0", "bg": "rgba(51,154,240,0.10)",  "icon": "mdi-broom",           "label": "Cleanup"},
    "config_push":     {"color": "#f59f00", "bg": "rgba(245,159,0,0.10)",   "icon": "mdi-file-upload-outline", "label": "Config Push"},
    "validate":        {"color": "#339af0", "bg": "rgba(51,154,240,0.10)",  "icon": "mdi-check-decagram-outline", "label": "Validating"},
    "complete":        {"color": "#69db7c", "bg": "rgba(105,219,124,0.10)", "icon": "mdi-check-circle-outline", "label": "Complete"},
    "failed":          {"color": "#ff8787", "bg": "rgba(255,135,135,0.10)", "icon": "mdi-alert-circle-outline", "label": "Failed"},
}


class BootstrapSessionTable(BaseTable):
    pk = ToggleColumn()
    device = tables.Column(linkify=True)
    bootstrap_status = tables.Column(accessor="status", verbose_name="Status")
    role = tables.Column(accessor="device__role__name", verbose_name="Role")
    console_server = tables.Column(linkify=True)
    console_port_number = tables.Column(verbose_name="Port")
    started_by = tables.Column(
        accessor="job_result__user__username", verbose_name="Started By", default="—"
    )
    started_at = tables.DateTimeColumn(format="Y-m-d H:i")
    completed_at = tables.DateTimeColumn(format="Y-m-d H:i")
    progress = tables.Column(empty_values=(), orderable=False, verbose_name="")

    class Meta(BaseTable.Meta):
        model = BootstrapSession
        fields = (
            "pk", "device", "bootstrap_status", "role", "console_server",
            "console_port_number", "started_by", "started_at", "completed_at", "progress",
        )
        default_ordering = ("-started_at",)

    def render_bootstrap_status(self, value, record):
        raw = record.status
        style = STATUS_STYLE.get(raw, STATUS_STYLE["pending"])
        running_class = " mdi-spin" if raw not in ("pending", "complete", "failed") else ""
        return format_html(
            '<span style="color:{c};background:{b};font-weight:600;'
            'padding:4px 12px;border-radius:14px;font-size:0.8rem;display:inline-flex;'
            'align-items:center;gap:5px"><i class="mdi {i}{r}" style="font-size:0.9rem"></i>{l}</span>',
            c=style["color"], b=style["bg"], i=style["icon"], r=running_class, l=style["label"],
        )

    def render_progress(self, record):
        url = reverse("plugins:nautobot_app_device_bootstrap:bootstrap_progress", args=[record.pk])
        if record.status in ("complete", "failed"):
            label = "View Details"
        else:
            label = "Watch Live"
        return format_html(
            '<a href="{}" class="btn btn-xs btn-default" style="border-radius:8px">'
            '<i class="mdi mdi-eye-outline"></i> {}</a>',
            url, label,
        )
