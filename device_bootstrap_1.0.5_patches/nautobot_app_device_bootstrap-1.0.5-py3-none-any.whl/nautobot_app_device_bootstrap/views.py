from django.conf import settings as django_settings
from django.contrib import messages
from django.contrib.auth.mixins import PermissionRequiredMixin
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.views import View
from django.views.generic import DetailView
from nautobot.apps.views import NautobotUIViewSet
from nautobot.extras.models import Job

from nautobot_app_device_bootstrap import filters, forms, models, tables
from nautobot_app_device_bootstrap.app_settings import get_settings
from nautobot_app_device_bootstrap.jobs import drivers, steps


# Rolling index of recently-submitted batches (newest first). Sessions carry
# batch_id durably; this cache entry adds submit metadata and covers batches
# whose jobs haven't created sessions yet.
BATCH_INDEX_KEY = "bootstrap:batch_index"

STEP_ICONS = {
    "factory_default": "mdi-restart",
    "staging": "mdi-lan-pending",
    "serial_verify": "mdi-barcode-scan",
    "connectivity": "mdi-access-point-network",
    "os_image": "mdi-package-down",
    "cell_firmware": "mdi-cellphone-arrow-down",
    "cert_enroll": "mdi-certificate-outline",
    "staging_cleanup": "mdi-broom",
    "cell_profile": "mdi-sim-outline",
    "config_push": "mdi-file-upload-outline",
    "reload": "mdi-restart",
    "validate": "mdi-check-decagram-outline",
    "time_sync": "mdi-clock-outline",
    "license": "mdi-license",
    "cell_firmware_reset": "mdi-cellphone-cog",
    "console_release": "mdi-lan-disconnect",
}

STEP_LABELS = {
    "factory_default": "Factory Default",
    "staging": "Staging Config",
    "serial_verify": "Serial Check",
    "connectivity": "Connectivity",
    "os_image": "OS Image",
    "cell_firmware": "Cell Firmware",
    "cert_enroll": "Certificate",
    "staging_cleanup": "Cleanup",
    "cell_profile": "APN Profile",
    "config_push": "Config Push",
    "reload": "Reload",
    "validate": "Validate",
    "time_sync": "Time Sync",
    "license": "License",
    "cell_firmware_reset": "Cell FW Reset",
    "console_release": "Release Console",
}

STEP_DESCRIPTIONS = {
    "factory_default": "Walk through initial setup dialog",
    "staging": "Temporary network config for bootstrapping",
    "serial_verify": "Confirm this is the right device",
    "connectivity": "Make sure we can reach the network",
    "os_image": "Download target IOS image and set boot statement",
    "cell_firmware": "Upgrade cellular modem firmware from Nautobot",
    "cert_enroll": "Get the device its identity certificate",
    "staging_cleanup": "Remove temporary staging config",
    "cell_profile": "Write carrier APN to the modem",
    "config_push": "Push the full production config",
    "reload": "Reload into the new software image",
    "validate": "Verify software, firmware, and configuration",
    "time_sync": "Set the clock and apply intended NTP",
    "license": "Apply the intended license boot level",
    "cell_firmware_reset": "Verizon modem factory reset: GENERIC, reload, re-activate carrier image",
    "console_release": "Free the console port and set the device status",
}


def _batch_overview(limit=25):
    """Summary rows for the Batches tab on the sessions list page.

    Sessions grouped by batch_id are the durable source; the cached submit
    index contributes who/when metadata and batches whose jobs haven't
    created any session yet (still queued).
    """
    from django.core.cache import cache
    from django.utils.dateparse import parse_datetime

    index = {e["batch_id"]: e for e in (cache.get(BATCH_INDEX_KEY) or [])}

    batches = {}
    sessions = (
        models.BootstrapSession.objects.filter(batch_id__isnull=False)
        .select_related("device")
        .order_by("-started_at")[:500]
    )
    for s in sessions:
        b = batches.setdefault(str(s.batch_id), {
            "device_names": [], "complete": 0, "failed": 0, "running": 0,
            "started_at": s.started_at,
        })
        b["device_names"].append(s.device.name)
        if s.status == "complete":
            b["complete"] += 1
        elif s.status == "failed":
            b["failed"] += 1
        else:
            b["running"] += 1
        # queryset is newest-first, so the last-seen session is the earliest
        b["started_at"] = s.started_at

    rows = []
    for batch_id in set(batches) | set(index):
        b = batches.get(batch_id)
        entry = index.get(batch_id, {})
        expected = len(entry.get("device_names", [])) or (b and len(b["device_names"])) or 0
        started = len(b["device_names"]) if b else 0
        queued = max(0, expected - started)
        complete, failed, running = (b["complete"], b["failed"], b["running"]) if b else (0, 0, 0)

        if running or queued:
            status = "running"
        elif failed and complete:
            status = "partial"
        elif failed:
            status = "failed"
        elif complete:
            status = "complete"
        else:
            status = "running"

        submitted_at = parse_datetime(entry["submitted_at"]) if entry.get("submitted_at") else None
        rows.append({
            "batch_id": batch_id,
            "when": submitted_at or (b and b["started_at"]),
            "submitted_by": entry.get("submitted_by", ""),
            "device_names": entry.get("device_names") or (b and b["device_names"]) or [],
            "total": max(expected, started),
            "complete": complete,
            "failed": failed,
            "running": running,
            "queued": queued,
            "status": status,
        })

    from datetime import datetime, timezone as dt_timezone

    epoch = datetime(1970, 1, 1, tzinfo=dt_timezone.utc)
    rows.sort(key=lambda r: r["when"] or epoch, reverse=True)
    return rows[:limit]


class BootstrapSessionUIViewSet(NautobotUIViewSet):
    queryset = models.BootstrapSession.objects.select_related(
        "device", "console_server", "job_result__user"
    )
    table_class = tables.BootstrapSessionTable
    filterset_class = filters.BootstrapSessionFilterSet
    filterset_form_class = forms.BootstrapSessionFilterForm
    action_set = ("list", "detail", "destroy", "bulk_destroy")
    action_buttons = ("export",)

    def get_extra_context(self, request, instance=None):
        ctx = super().get_extra_context(request, instance=instance)
        if instance is None and getattr(self, "action", None) == "list":
            ctx["batches"] = _batch_overview()
            from nautobot.dcim.models import Device

            # File server comes from Provisioning Settings now — no form field.
            ctx.update({
                "devices": Device.objects.select_related("role").order_by("name"),
                "opengear_devices": Device.objects.filter(role__name__icontains="console").order_by("name"),
            })
        return ctx



def _assemble_step_list(session, pipeline):
    """Map executed steps onto pipeline positions POSITIONALLY.

    The pipeline can contain the same step twice (connectivity runs after
    staging and again after the reload) — keying by name mirrors one result
    onto every occurrence, lighting both cards. session.steps is stored in
    execution order, so consume it front-to-back against the pipeline.
    """
    saved = list(session.steps or [])
    ptr = 0
    active = session.status if session.status not in ("complete", "failed", "pending") else None
    running_assigned = False
    past_failure = False
    step_list = []

    for step_name in pipeline:
        if ptr < len(saved) and saved[ptr].get("name") == step_name:
            step_data = dict(saved[ptr])
            ptr += 1
            if step_data.get("status") == "failed":
                past_failure = True
        elif past_failure:
            step_data = {"name": step_name, "status": "skipped", "message": ""}
        elif session.status == "complete":
            step_data = {"name": step_name, "status": "complete", "message": ""}
        elif active and step_name == active and not running_assigned:
            step_data = {"name": step_name, "status": "running", "message": ""}
            running_assigned = True
        else:
            step_data = {"name": step_name, "status": "pending", "message": ""}
        step_list.append(step_data)

    return step_list


class BootstrapProgressView(DetailView):
    model = models.BootstrapSession
    template_name = "nautobot_app_device_bootstrap/progress.html"
    context_object_name = "session"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        session = self.object
        settings = get_settings()

        pipeline = settings[drivers.PIPELINE_KEYS.get(session.device_type_class, "pipeline_switch")]
        pipeline = steps.filter_pipeline(pipeline, session.device, settings)

        step_list = [
            {
                **step_data,
                "icon": STEP_ICONS.get(step_data["name"], "mdi-circle-outline"),
                "label": STEP_LABELS.get(step_data["name"], step_data["name"]),
                "description": STEP_DESCRIPTIONS.get(step_data["name"], ""),
            }
            for step_data in _assemble_step_list(session, pipeline)
        ]

        if session.status == "complete":
            overall = "complete"
        elif session.status == "failed":
            overall = "failed"
        elif session.status == "pending":
            overall = "pending"
        else:
            overall = "running"

        completed_count = sum(1 for s in step_list if s["status"] == "complete")
        failed_count = sum(1 for s in step_list if s["status"] == "failed")
        progress_pct = int(((completed_count + failed_count) / len(step_list)) * 100) if step_list else 0
        if overall == "complete":
            progress_pct = 100

        log_entries = self._build_log_entries(session, step_list)

        device_config = self._resolve_device_config(session.device, settings)

        config_preview = self._build_config_preview(session.device, device_config, pipeline)

        import json

        ctx["steps"] = step_list
        ctx["overall_status"] = overall
        # pending counts as active — the page must poll while waiting for the
        # worker to pick the job up, or "waiting to start" never refreshes.
        ctx["is_active"] = overall in ("running", "pending")
        ctx["log_entries"] = log_entries
        ctx["progress_pct"] = progress_pct
        ctx["completed_count"] = completed_count
        ctx["total_steps"] = len(step_list)
        ctx["device_config"] = device_config
        ctx["config_preview"] = config_preview
        ctx["step_icons_json"] = json.dumps(STEP_ICONS)
        return ctx

    def _resolve_device_config(self, device, settings):
        """Build the resolved config for this device."""
        from nautobot_app_device_bootstrap.jobs.steps.cert_enroll import (
            _parse_trustpoint_from_intended,
            resolve_ndes,
        )

        tp = _parse_trustpoint_from_intended(device)
        ndes = resolve_ndes(device, settings, tp)

        return {
            "source": "intended config" if tp else "app defaults",
            "from_context": tp is not None,
            "vrf_name": (tp.get("vrf") if tp else None) or settings.get("vrf_name", ""),
            "vrf_rd": settings.get("vrf_rd", ""),
            "domain_name": settings.get("domain_name", ""),
            "staging_gateway": settings.get("staging_gateway", ""),
            "mgmt_vlan": settings.get("mgmt_vlan", ""),
            "trustpoint_name": tp["name"] if tp else settings.get("trustpoint_name", ""),
            "key_label": (tp.get("key_label") if tp else None) or settings.get("key_label", ""),
            "rsa_modulus": 4096,
            "ndes_ip": ndes["ip"] or "",
            "ndes_host": ndes["host"] or "",
            "ndes_source": ndes["source"] or "",
            "enrollment_url": (tp.get("enrollment_url") if tp else None) or "",
            "ndes_secrets_group": settings.get("ndes_secrets_group", ""),
        }

    def _build_config_preview(self, device, config, pipeline):
        """Generate the staging commands and fetch intended config for preview."""
        preview = {"staging_commands": [], "intended_preview": None, "intended_lines": 0, "intended_url": None}

        if "staging" in pipeline:
            vrf = config["vrf_name"]
            vrf_rd = config["vrf_rd"]
            domain = config["domain_name"]
            gateway = config["staging_gateway"]

            if drivers.classify_device(device) == "switch":
                preview["staging_commands"] = [
                    f"hostname {device.name}",
                    f"ip domain-name {domain}",
                    f"interface Vlan{config['mgmt_vlan']}",
                    " ip address dhcp",
                    " no shutdown",
                ]
            else:
                ndes_ip = config.get("ndes_ip", "")
                ndes_host = config.get("ndes_host") or f"ndes.{domain}"

                preview["staging_commands"] = [
                    f"hostname {device.name}",
                    f"vrf definition {vrf}",
                    f" rd {vrf_rd}",
                    " address-family ipv4",
                    " exit-address-family",
                    f"ip domain-name {domain}",
                    f"ip host {ndes_host} {ndes_ip}",
                    f"ip host vrf {vrf} {ndes_host} {ndes_ip}",
                    f"ip route vrf {vrf} 0.0.0.0 0.0.0.0 {gateway} name FDVRF_DEFAULT",
                    "interface GigabitEthernet0/0/0",
                    f" vrf forwarding {vrf}",
                    " ip address dhcp",
                    " no shutdown",
                ]

        if "config_push" in pipeline:
            try:
                from nautobot_golden_config.models import GoldenConfig
                gc = GoldenConfig.objects.get(device=device)
                if gc.intended_config:
                    lines = gc.intended_config.splitlines()
                    preview["intended_lines"] = len(lines)
                    preview["intended_preview"] = lines[:40]
                    preview["intended_url"] = gc.get_absolute_url() if hasattr(gc, "get_absolute_url") else None
            except Exception:
                pass

        return preview

    def _build_log_entries(self, session, step_list):
        return _build_log_entries(session, step_list)


def _build_log_entries(session, step_list):
    """Shared by the progress page render and the status API.

    Prefers the live per-line log the job mirrors into cache (real step
    activity: flash checks, transfers, verification). Falls back to a summary
    synthesized from step statuses for sessions whose cache entry has expired.
    Steps from the API carry no label, so fall back to STEP_LABELS by name.
    """
    from django.core.cache import cache
    from nautobot_app_device_bootstrap.jobs.bootstrap import SESSION_LOG_KEY

    ts = session.started_at
    if not ts:
        return []

    from datetime import timedelta

    live = cache.get(SESSION_LOG_KEY.format(pk=session.pk))
    if live:
        entries = list(live)
        offset = 0
    else:
        entries = []
        offset = 0
        for step in step_list:
            if step["status"] == "pending":
                continue

            step_ts = (ts + timedelta(seconds=offset)).strftime("%H:%M:%S")
            label = step.get("label") or STEP_LABELS.get(step["name"], step["name"])

            if step["status"] == "running":
                entries.append({"timestamp": step_ts, "level": "info", "message": f"{label}..."})
                if step.get("message"):
                    entries.append({"timestamp": step_ts, "level": "info", "message": f"  {step['message']}"})
            elif step["status"] == "complete":
                msg = step.get("message") or "Done"
                entries.append({"timestamp": step_ts, "level": "success", "message": f"{label} — {msg}"})
            elif step["status"] == "failed":
                msg = step.get("message") or "Failed"
                entries.append({"timestamp": step_ts, "level": "error", "message": f"{label} — {msg}"})
            elif step["status"] == "skipped":
                entries.append({"timestamp": step_ts, "level": "warning", "message": f"{label} — skipped"})

            offset += 12

    if session.error_message and session.status == "failed":
        err_when = session.completed_at or (ts + timedelta(seconds=offset))
        entries.append({
            "timestamp": err_when.strftime("%H:%M:%S"),
            "level": "error",
            "message": session.error_message,
        })

    if session.status == "complete" and session.completed_at:
        elapsed = session.completed_at - session.started_at
        mins = int(elapsed.total_seconds() // 60)
        secs = int(elapsed.total_seconds() % 60)
        done_ts = session.completed_at.strftime("%H:%M:%S")
        entries.append({
            "timestamp": done_ts,
            "level": "success",
            "message": f"All done — bootstrapped in {mins}m {secs}s",
        })

    return entries


def _session_status_payload(session, settings):
    """Live status snapshot for one session — shared by the per-device status
    API and the batch page (which renders one of these per card)."""
    from nautobot.extras.choices import JobResultStatusChoices

    pipeline = settings[drivers.PIPELINE_KEYS.get(session.device_type_class, "pipeline_switch")]
    pipeline = steps.filter_pipeline(pipeline, session.device, settings)

    step_list = _assemble_step_list(session, pipeline)

    if session.status in ("complete", "failed", "pending"):
        overall = session.status
    else:
        overall = "running"

    status_display = session.get_status_display()
    error_message = session.error_message or None

    # A session only advances while its job is alive. If the session still looks
    # in-flight but the job has already reached a terminal state — or its
    # JobResult is gone entirely — nothing will ever finish it, so report it
    # failed instead of polling "running"/"pending" forever.
    if overall in ("running", "pending"):
        job_result = session.job_result
        if job_result is None:
            overall = "failed"
            status_display = "Job record missing"
            error_message = error_message or (
                "The provisioning job's record no longer exists — the run never finished."
            )
        elif job_result.status in JobResultStatusChoices.READY_STATES:
            overall = "failed"
            status_display = f"Job ended ({job_result.status.title()}) before the pipeline finished"
            error_message = error_message or (
                "The provisioning job stopped without completing this device — see the job log."
            )

    completed_count = sum(1 for s in step_list if s["status"] == "complete")
    failed_count = sum(1 for s in step_list if s["status"] == "failed")
    progress_pct = int(((completed_count + failed_count) / len(step_list)) * 100) if step_list else 0
    if overall == "complete":
        progress_pct = 100

    return {
        "overall": overall,
        "status_display": status_display,
        "progress_pct": progress_pct,
        "completed_count": completed_count,
        "total_steps": len(step_list),
        "steps": step_list,
        "error_message": error_message,
        "is_active": overall in ("running", "pending"),
    }


class BootstrapStatusAPIView(View):
    """JSON endpoint for live-polling the progress page without full reload."""

    def get(self, request, pk):
        session = models.BootstrapSession.objects.get(pk=pk)
        payload = _session_status_payload(session, get_settings())
        payload["log_entries"] = _build_log_entries(session, payload["steps"])
        return JsonResponse(payload)


class BootstrapDeviceView(View):
    """Custom form to launch a bootstrap and redirect to the progress page."""

    def get(self, request):
        from nautobot.dcim.models import Device

        # File server is no longer chosen on this form — the job resolves it
        # from Provisioning Settings (the POST field, if ever sent, still wins).
        devices = Device.objects.select_related("role").order_by("name")
        opengear_devices = Device.objects.filter(role__name__icontains="console").order_by("name")

        return render(request, "nautobot_app_device_bootstrap/bootstrap_run.html", {
            "devices": devices,
            "opengear_devices": opengear_devices,
        })

    def post(self, request):
        import time
        import uuid
        from django.core.cache import cache
        from django.urls import reverse
        from django.utils import timezone
        from nautobot.dcim.models import Device
        from nautobot.extras.choices import JobResultStatusChoices
        from nautobot.extras.models import JobQueue, JobResult

        job_model = Job.objects.get(
            module_name="nautobot_app_device_bootstrap.jobs.bootstrap",
            job_class_name="DeviceBootstrapJob",
        )

        device_pks = request.POST.getlist("devices")
        opengear_pk = request.POST.get("opengear") or None
        console_port = request.POST.get("console_port") or None
        file_server_pk = request.POST.get("file_server") or None
        dry_run = "dry_run" in request.POST

        port = int(console_port) if console_port else None

        # Duplicate-provisioning guard: a device with a live session (not
        # finished, and its job is still pending/running) must not be enqueued
        # again — two console jobs on one serial line interleave keystrokes.
        # Sessions whose job crashed (READY_STATES without completed_at) don't
        # block a re-run.
        active = (
            models.BootstrapSession.objects
            .filter(device__pk__in=device_pks, completed_at__isnull=True, job_result__isnull=False)
            .exclude(job_result__status__in=JobResultStatusChoices.READY_STATES)
            .select_related("device")
        )
        blocked = {str(s.device_id): s.device.name for s in active}
        if blocked:
            messages.warning(
                request,
                f"Skipped {len(blocked)} device(s) already being provisioned: {', '.join(sorted(blocked.values()))}",
            )
            device_pks = [pk for pk in device_pks if pk not in blocked]
        if not device_pks:
            messages.error(request, "No devices left to provision.")
            return redirect(reverse("plugins:nautobot_app_device_bootstrap:bootstrap_device"))

        plugin_settings = get_settings()

        # Without a posted file_server the job resolves its default from
        # Provisioning Settings — fail early with a pointer if neither exists,
        # instead of a cryptic "file_server is a required field" job crash.
        if not file_server_pk and not plugin_settings.get("default_file_server_ei_name"):
            messages.error(
                request,
                "No default file server is set — choose one in Provisioning Settings first.",
            )
            return redirect(reverse("plugins:nautobot_app_device_bootstrap:bootstrap_device"))

        queue_name = plugin_settings.get("provisioning_queue") or ""
        job_queue = None
        if queue_name:
            job_queue = JobQueue.objects.filter(name=queue_name).first()
            if job_queue is None:
                messages.warning(
                    request,
                    f"Job queue '{queue_name}' does not exist — dispatching to the default queue. "
                    f"Create the Job Queue in Nautobot (and a worker for it) or clear the setting.",
                )

        def enqueue(pks, batch_id=""):
            # Nautobot 3.2 wants job args in an explicit job_kwargs dict; the
            # loose-kwargs form is deprecated and slated for removal.
            job_kwargs = {
                "devices": pks,
                "opengear": opengear_pk,
                "console_port": port,
                "dry_run": dry_run,
                "batch_id": batch_id,
            }
            # file_server is a required ObjectVar whose default resolves from
            # Provisioning Settings — the default only applies when the key is
            # ABSENT. An explicit None fails deserialization with
            # "file_server is a required field", so only pass it when a caller
            # actually posted one.
            if file_server_pk:
                job_kwargs["file_server"] = file_server_pk
            return JobResult.enqueue_job(
                job_model,
                request.user,
                job_queue=job_queue,
                job_kwargs=job_kwargs,
            )

        # Multi-device: one job per device sharing a batch_id, so each device
        # gets its own isolation/cancel/retry and durable log — and the batch
        # page can follow all of them (a single progress page only ever
        # followed the first device's session).
        if len(device_pks) > 1:
            batch_id = uuid.uuid4()
            names = {
                str(pk): name
                for pk, name in Device.objects.filter(pk__in=device_pks).values_list("pk", "name")
            }
            manifest = []
            for pk in device_pks:
                job_result = enqueue([pk], batch_id=str(batch_id))
                manifest.append({
                    "device_id": str(pk),
                    "device_name": names.get(str(pk), str(pk)),
                    "job_result_id": str(job_result.pk),
                })
            # The batch page needs the expected device set before any session
            # exists; after the cache expires, the sessions themselves (keyed
            # by batch_id) carry the page.
            cache.set(f"bootstrap:batch:{batch_id}", manifest, timeout=7 * 86400)
            # Rolling index feeding the batches list page — sessions take over
            # as the durable source once the entry ages out.
            index = cache.get(BATCH_INDEX_KEY) or []
            index.insert(0, {
                "batch_id": str(batch_id),
                "submitted_at": timezone.now().isoformat(),
                "submitted_by": request.user.get_username(),
                "device_names": [e["device_name"] for e in manifest],
            })
            cache.set(BATCH_INDEX_KEY, index[:50], timeout=7 * 86400)
            return redirect(
                reverse("plugins:nautobot_app_device_bootstrap:bootstrap_batch", args=[batch_id])
            )

        enqueued_at = timezone.now()
        job_result = enqueue(device_pks)

        # Wait for Celery to start the job and create THIS run's session — the
        # started_at filter keeps a re-run from grabbing a previous session for
        # the same device. Sessions are created after the job's up-front checks,
        # so a run that aborts early never creates one; the fallback goes to the
        # job result page where that abort is actually visible.
        session = None
        for _ in range(20):
            time.sleep(0.5)
            session = (
                models.BootstrapSession.objects
                .filter(device__pk__in=device_pks, started_at__gte=enqueued_at)
                .order_by("-started_at")
                .first()
            )
            if session:
                break
            job_result.refresh_from_db()
            if job_result.status in JobResultStatusChoices.READY_STATES:
                break

        if session:
            return redirect(
                reverse("plugins:nautobot_app_device_bootstrap:bootstrap_progress", args=[session.pk])
            )
        return redirect(job_result.get_absolute_url())


class PreflightCheckView(View):
    """JSON endpoint — run pre-flight checks for a single device."""

    def get(self, request, pk):
        from nautobot.dcim.models import ConsolePort, Device, SoftwareImageFile

        device = Device.objects.select_related("device_type", "role").get(pk=pk)
        plugin_settings = get_settings()
        checks = []

        # One unified "Console path" check. The console server is resolved from
        # EITHER the manual override (the OpenGear + Port form fields) OR the
        # device's cable trace — filling in the fields is a first-class way to
        # satisfy this, not a special case. A valid path needs the server plus
        # its management IP and secrets group (the job needs both to log in).
        opengear_pk = request.GET.get("opengear")
        console_port_override = request.GET.get("console_port")

        console_server = None
        port_desc = None
        via = None
        if opengear_pk and console_port_override:
            console_server = Device.objects.filter(pk=opengear_pk).first()
            port_desc = console_port_override
            via = "manual override"
        else:
            console_port = ConsolePort.objects.filter(device=device).first()
            if console_port and console_port.cable is not None:
                cable = console_port.cable
                far_end = cable.termination_b if cable.termination_a == console_port else cable.termination_a
                if hasattr(far_end, "device"):
                    console_server = far_end.device
                    port_desc = getattr(far_end, "name", None)
                    via = "cable trace"

        if console_server is None:
            path_ok = False
            path_detail = "Not cabled — select an OpenGear + Port above, or cable the console port in Nautobot"
        elif not (console_server.primary_ip4 or console_server.primary_ip6):
            path_ok = False
            path_detail = f"{console_server.name} ({via}) has no management IP"
        elif console_server.secrets_group is None:
            path_ok = False
            path_detail = f"{console_server.name} ({via}) has no secrets group"
        else:
            path_ok = True
            ip = console_server.primary_ip4 or console_server.primary_ip6
            port_part = f" port {port_desc}" if port_desc else ""
            path_detail = f"{console_server.name}{port_part} via {via} ({ip})"

        checks.append({"label": "Console path", "ok": path_ok, "detail": path_detail})

        try:
            from nautobot_golden_config.models import GoldenConfig
            gc = GoldenConfig.objects.get(device=device)
            has_config = bool(gc.intended_config)
            config_lines = len(gc.intended_config.splitlines()) if has_config else 0
        except Exception:
            has_config = False
            config_lines = 0
        checks.append({
            "label": "Golden Config intended config",
            "ok": has_config,
            "detail": f"{config_lines} lines" if has_config else "Not generated",
        })

        import os
        from urllib.parse import urlparse
        from nautobot_app_device_bootstrap.jobs.steps.cell_firmware import (
            _find_cellular_modules, _CARRIER_TAG_MAP, _resolve_carrier,
        )
        from nautobot_app_device_bootstrap.jobs.steps.cert_enroll import (
            _parse_trustpoint_from_intended, resolve_ndes,
        )

        # OS image
        sw_image = SoftwareImageFile.objects.filter(
            device_types=device.device_type,
            software_version__status__name__in=["Active", "Validated"],
        ).first()
        checks.append({
            "label": "Validated software image",
            "ok": sw_image is not None,
            "detail": f"{sw_image.software_version.version} — {sw_image.image_file_name}" if sw_image else "None assigned to device type",
        })
        if sw_image and sw_image.download_url:
            parsed_url = urlparse(sw_image.download_url)
            if parsed_url.scheme == "file":
                file_exists = os.path.isfile(parsed_url.path)
                checks.append({
                    "label": "OS image file on disk",
                    "ok": file_exists,
                    "detail": parsed_url.path if file_exists else f"Not found: {parsed_url.path}",
                })

        # Cert enrollment (routers only)
        role_name = device.role.name.lower() if device.role else ""
        if "router" in role_name:
            tp = _parse_trustpoint_from_intended(device)
            checks.append({
                "label": "Trustpoint in intended config",
                "ok": tp is not None,
                "detail": f"{tp['name']} — {tp.get('enrollment_url', '')}" if tp else "No trustpoint block found",
            })

            sg_name = plugin_settings.get("ndes_secrets_group", "")
            if sg_name:
                from nautobot.extras.models import SecretsGroup
                try:
                    from nautobot.extras.models import SecretsGroupAssociation
                    sg = SecretsGroup.objects.get(name=sg_name)
                    has_user = SecretsGroupAssociation.objects.filter(
                        secrets_group=sg, access_type="Generic", secret_type="username",
                    ).exists()
                    has_pass = SecretsGroupAssociation.objects.filter(
                        secrets_group=sg, access_type="Generic", secret_type="password",
                    ).exists()
                    checks.append({
                        "label": "NDES credentials",
                        "ok": has_user and has_pass,
                        "detail": sg_name if has_user and has_pass else f"Missing {'username' if not has_user else 'password'} in {sg_name}",
                    })
                except SecretsGroup.DoesNotExist:
                    checks.append({
                        "label": "NDES credentials",
                        "ok": False,
                        "detail": f"Secrets group '{sg_name}' not found",
                    })

        # Cellular
        modules = _find_cellular_modules(device)
        if modules:
            checks.append({
                "label": "Cellular module installed",
                "ok": True,
                "detail": ", ".join(f"{m[1]} ({m[2]})" for m in modules),
            })

            device_tags = set(device.tags.values_list("name", flat=True))
            carrier_tag = None
            carrier_key = None
            for tag_name, key in _CARRIER_TAG_MAP.items():
                if tag_name in device_tags:
                    carrier_tag = tag_name
                    carrier_key = key
                    break

            checks.append({
                "label": "Carrier tag",
                "ok": carrier_tag is not None,
                "detail": carrier_tag or "No FirstNet or Verizon Wireless tag",
            })

            if carrier_key:
                carrier = _resolve_carrier(device, plugin_settings)
                if carrier:
                    checks.append({
                        "label": "Carrier firmware configured",
                        "ok": True,
                        "detail": f"CWE: {carrier['cwe_file']}, NVU: {carrier['nvu_file']}",
                    })

                    media_root = getattr(django_settings, "MEDIA_ROOT", "/opt/nautobot/media")
                    fw_dir = os.path.join(media_root, "firmware", "cell_firmware")
                    for label, filename in [("CWE file", carrier["cwe_file"]), ("NVU file", carrier["nvu_file"])]:
                        if not filename:
                            continue
                        full_path = os.path.join(fw_dir, filename)
                        exists = os.path.isfile(full_path)
                        checks.append({
                            "label": f"{label} on disk",
                            "ok": exists,
                            "detail": filename if exists else f"Not found: {full_path}",
                        })

                    has_apn = bool(plugin_settings.get(f"cell_apn_{carrier_key}", ""))
                    checks.append({
                        "label": "Carrier APN",
                        "ok": has_apn,
                        "detail": plugin_settings.get(f"cell_apn_{carrier_key}", "") if has_apn else "Not configured",
                    })
                else:
                    checks.append({
                        "label": "Carrier firmware configured",
                        "ok": False,
                        "detail": f"No NVU configured for {carrier_key}",
                    })

        tp = _parse_trustpoint_from_intended(device)
        ndes = resolve_ndes(device, plugin_settings, tp)

        config = {
            "source": "intended config" if tp else "app defaults",
            "vrf_name": (tp.get("vrf") if tp else None) or plugin_settings.get("vrf_name", ""),
            "vrf_rd": plugin_settings.get("vrf_rd", ""),
            "domain_name": plugin_settings.get("domain_name", ""),
            "staging_gateway": plugin_settings.get("staging_gateway", ""),
            "trustpoint_name": tp["name"] if tp else plugin_settings.get("trustpoint_name", ""),
            "key_label": (tp.get("key_label") if tp else None) or plugin_settings.get("key_label", ""),
            "rsa_modulus": 4096,
            "ndes_ip": ndes["ip"] or "",
            "ndes_host": ndes["host"] or "",
            "ndes_source": ndes["source"] or "",
            "enrollment_url": (tp.get("enrollment_url") if tp else None) or "",
            "ndes_secrets_group": plugin_settings.get("ndes_secrets_group", ""),
        }

        all_ok = all(c["ok"] for c in checks)
        return JsonResponse({"device": device.name, "checks": checks, "all_ok": all_ok, "config": config})


class PreflightStepsView(View):
    """JSON endpoint — run per-step preflight checks for a device."""

    def get(self, request, pk):
        from nautobot.dcim.models import Device
        from nautobot.extras.models import ExternalIntegration
        from nautobot_app_device_bootstrap.jobs import console

        device = Device.objects.select_related("device_type", "role").get(pk=pk)
        plugin_settings = get_settings()

        from nautobot_app_device_bootstrap.jobs import drivers

        driver = drivers.get_driver(device)
        device_class = driver.classify(device)
        if device_class is None:
            return JsonResponse({"device": device.name, "steps": [], "all_ok": False, "error": "Unrecognized role"})
        pipeline = plugin_settings[driver.pipeline_key(device_class)]

        ei_name = plugin_settings.get("default_file_server_ei_name", "Firmware Webserver")
        default_ei = ExternalIntegration.objects.filter(name=ei_name).first()
        plugin_settings["file_server_ei"] = default_ei

        file_server_result = None
        if default_ei is not None:
            try:
                files = console.get_file_server_files_cached(default_ei)
                plugin_settings["file_server_files"] = files
                if files is not None:
                    detail = f"{default_ei.name} OK — {len(files)} files at base path"
                elif console.get_ei_scheme(default_ei) in ("http", "https"):
                    detail = f"{default_ei.name} reachable — files verified individually via HTTP"
                else:
                    detail = f"{default_ei.name} reachable — file presence not verifiable for this protocol"
                file_server_result = {
                    "step": "file_server", "label": "File server reachability",
                    "ok": True,
                    "detail": detail,
                }
            except Exception as e:
                file_server_result = {
                    "step": "file_server", "label": "File server reachability",
                    "ok": False, "detail": f"{default_ei.name}: {e}",
                }
        else:
            file_server_result = {
                "step": "file_server", "label": "File server reachability",
                "ok": False, "detail": f"No ExternalIntegration named '{ei_name}' found",
            }

        pipeline = steps.filter_pipeline(pipeline, device, plugin_settings)
        results = steps.run_preflight(pipeline, device, plugin_settings)
        results.insert(0, file_server_result)
        all_ok = all(r["ok"] for r in results)

        return JsonResponse({"device": device.name, "steps": results, "all_ok": all_ok})


def _batch_payload(batch_id):
    """Status snapshot for every device in a batch.

    Sessions (keyed by batch_id) are the durable source; the enqueue-time
    manifest cached by the provision view fills in devices whose job hasn't
    created a session yet (still queued, or aborted before provisioning).
    """
    from django.core.cache import cache
    from django.urls import reverse
    from nautobot.extras.choices import JobResultStatusChoices
    from nautobot.extras.models import JobResult

    settings = get_settings()
    manifest = cache.get(f"bootstrap:batch:{batch_id}") or []
    sessions = (
        models.BootstrapSession.objects.filter(batch_id=batch_id)
        .select_related("device", "job_result")
        .order_by("started_at")
    )
    by_device = {str(s.device_id): s for s in sessions}

    def session_card(session):
        card = _session_status_payload(session, settings)
        card.update({
            "device_id": str(session.device_id),
            "device_name": session.device.name,
            "device_class": session.device_type_class,
            "session_url": reverse(
                "plugins:nautobot_app_device_bootstrap:bootstrap_progress", args=[session.pk]
            ),
            "job_url": session.job_result.get_absolute_url() if session.job_result else None,
        })
        return card

    pending_jr_ids = [e["job_result_id"] for e in manifest if e["device_id"] not in by_device]
    queued_jrs = {str(j.pk): j for j in JobResult.objects.filter(pk__in=pending_jr_ids)}

    cards = []
    covered = set()
    for entry in manifest:
        did = entry["device_id"]
        covered.add(did)
        session = by_device.get(did)
        if session is not None:
            cards.append(session_card(session))
            continue
        jr = queued_jrs.get(entry["job_result_id"])
        if jr is None:
            # The manifest points at a JobResult that no longer exists — the run
            # is over (or was purged); it will never produce a session. Without
            # this, the card reads "queued" and the batch polls forever.
            overall, status_display, is_active = "failed", "Job record no longer exists", False
        elif jr.status in JobResultStatusChoices.READY_STATES:
            # The job finished without ever creating a session — it aborted in
            # the up-front checks; the job log has the reason.
            overall, status_display, is_active = "failed", "Ended before provisioning started", False
        else:
            overall, status_display, is_active = "queued", "Waiting for a worker", True
        cards.append({
            "device_id": did,
            "device_name": entry.get("device_name", did),
            "overall": overall,
            "status_display": status_display,
            "progress_pct": 0,
            "completed_count": 0,
            "total_steps": 0,
            "steps": [],
            "error_message": None,
            "is_active": is_active,
            "session_url": None,
            "job_url": jr.get_absolute_url() if jr is not None else None,
        })

    # Sessions the manifest didn't cover (cache expired, or historical view).
    for session in sessions:
        if str(session.device_id) not in covered:
            cards.append(session_card(session))

    return {
        "batch_id": str(batch_id),
        "devices": cards,
        "is_active": any(c["is_active"] for c in cards),
        "counts": {
            "total": len(cards),
            "complete": sum(1 for c in cards if c["overall"] == "complete"),
            "failed": sum(1 for c in cards if c["overall"] == "failed"),
        },
    }


class BatchProgressView(View):
    """Card-grid page following every device in a multi-device batch."""

    def get(self, request, batch_id):
        import json

        return render(request, "nautobot_app_device_bootstrap/batch.html", {
            "batch_id": batch_id,
            "payload": _batch_payload(batch_id),
            "step_icons_json": json.dumps(STEP_ICONS),
        })


class BatchStatusAPIView(View):
    """JSON endpoint the batch page polls."""

    def get(self, request, batch_id):
        return JsonResponse(_batch_payload(batch_id))


class BatchDeleteView(PermissionRequiredMixin, View):
    """Delete every session in a batch — the Batches-tab counterpart of deleting
    sessions from the sessions table. A batch is not a model of its own (it's a
    shared batch_id across sessions), so this is the only way to remove one.
    JobResults are untouched, same as deleting individual sessions."""

    permission_required = "nautobot_app_device_bootstrap.delete_bootstrapsession"

    def post(self, request, batch_id):
        from django.core.cache import cache
        from django.urls import reverse

        deleted, _ = models.BootstrapSession.objects.filter(batch_id=batch_id).delete()
        cache.delete(f"bootstrap:batch:{batch_id}")
        # The Batches tab unions sessions with the cached submit index, so the
        # batch must come out of the index too — otherwise a batch whose
        # sessions were deleted individually lingers as an undeletable row.
        index = cache.get(BATCH_INDEX_KEY) or []
        remaining = [e for e in index if e.get("batch_id") != str(batch_id)]
        if len(remaining) != len(index):
            cache.set(BATCH_INDEX_KEY, remaining, timeout=7 * 86400)
        if deleted:
            messages.success(request, f"Deleted batch — removed {deleted} session(s).")
        else:
            messages.success(request, "Deleted batch (its sessions were already removed).")
        return redirect(reverse("plugins:nautobot_app_device_bootstrap:bootstrapsession_list") + "#batches")


class BootstrapSettingsView(PermissionRequiredMixin, View):
    """Edit the app's singleton settings in the GUI."""

    permission_required = "nautobot_app_device_bootstrap.change_bootstrapsettings"
    template_name = "nautobot_app_device_bootstrap/settings.html"

    def _context(self, form):
        import json

        step_info = {
            name: {
                "label": steps.STEP_LABELS.get(name, name),
                "description": STEP_DESCRIPTIONS.get(name, ""),
            }
            for name in sorted(steps.STEP_REGISTRY)
        }
        # Shipped defaults for the reset buttons — PLUGINS_CONFIG carries the
        # app's default_settings (settings storage moved to the DB; these
        # remain the factory values).
        cfg = django_settings.PLUGINS_CONFIG["nautobot_app_device_bootstrap"]
        pipeline_defaults = {
            "pipeline_router": list(cfg.get("pipeline_router", [])),
            "pipeline_switch": list(cfg.get("pipeline_switch", [])),
        }
        return {
            "form": form,
            "step_info_json": json.dumps(step_info),
            "pipeline_defaults_json": json.dumps(pipeline_defaults),
        }

    def get(self, request):
        instance = models.BootstrapSettings.load()
        return render(request, self.template_name, self._context(forms.BootstrapSettingsForm(instance=instance)))

    def post(self, request):
        instance = models.BootstrapSettings.load()
        form = forms.BootstrapSettingsForm(request.POST, instance=instance)
        if form.is_valid():
            form.save()
            messages.success(request, "Provisioning settings saved.")
            return redirect("plugins:nautobot_app_device_bootstrap:bootstrap_settings")
        return render(request, self.template_name, self._context(form))
