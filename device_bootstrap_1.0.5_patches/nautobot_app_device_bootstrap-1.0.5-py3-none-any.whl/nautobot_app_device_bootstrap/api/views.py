from nautobot.apps.api import NautobotModelViewSet

from nautobot_app_device_bootstrap.api.serializers import BootstrapSessionSerializer
from nautobot_app_device_bootstrap.filters import BootstrapSessionFilterSet
from nautobot_app_device_bootstrap.models import BootstrapSession


class BootstrapSessionViewSet(NautobotModelViewSet):
    queryset = BootstrapSession.objects.all()
    serializer_class = BootstrapSessionSerializer
    filterset_class = BootstrapSessionFilterSet
