from nautobot.apps.api import OrderedDefaultRouter

from nautobot_app_device_bootstrap.api import views

app_name = "nautobot_app_device_bootstrap-api"

router = OrderedDefaultRouter()
router.register("provisioning-sessions", views.BootstrapSessionViewSet)

urlpatterns = router.urls
