"""API for Device Bootstrap app."""
