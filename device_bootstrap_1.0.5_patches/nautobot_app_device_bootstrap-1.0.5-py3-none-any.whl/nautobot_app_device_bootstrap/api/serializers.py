from nautobot.apps.api import ValidatedModelSerializer

from nautobot_app_device_bootstrap.models import BootstrapSession


class BootstrapSessionSerializer(ValidatedModelSerializer):
    class Meta:
        model = BootstrapSession
        fields = "__all__"
