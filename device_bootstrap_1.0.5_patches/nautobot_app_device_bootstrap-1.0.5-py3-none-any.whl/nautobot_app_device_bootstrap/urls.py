from django.templatetags.static import static
from django.urls import path
from django.views.generic import RedirectView
from nautobot.apps.urls import NautobotUIViewSetRouter

from nautobot_app_device_bootstrap import views

app_name = "nautobot_app_device_bootstrap"

router = NautobotUIViewSetRouter()
router.register("provisioning-sessions", views.BootstrapSessionUIViewSet)

urlpatterns = [
    path(
        "provisioning-sessions/<uuid:pk>/progress/",
        views.BootstrapProgressView.as_view(),
        name="bootstrap_progress",
    ),
    path(
        "provisioning-sessions/<uuid:pk>/status/",
        views.BootstrapStatusAPIView.as_view(),
        name="bootstrap_status_api",
    ),
    path(
        "bootstrap-device/",
        views.BootstrapDeviceView.as_view(),
        name="bootstrap_device",
    ),
    path(
        "batches/<uuid:batch_id>/",
        views.BatchProgressView.as_view(),
        name="bootstrap_batch",
    ),
    path(
        "batches/<uuid:batch_id>/status/",
        views.BatchStatusAPIView.as_view(),
        name="bootstrap_batch_status_api",
    ),
    path(
        "batches/<uuid:batch_id>/delete/",
        views.BatchDeleteView.as_view(),
        name="bootstrap_batch_delete",
    ),
    path(
        "preflight/<uuid:pk>/",
        views.PreflightCheckView.as_view(),
        name="preflight_check",
    ),
    path(
        "preflight-steps/<uuid:pk>/",
        views.PreflightStepsView.as_view(),
        name="preflight_steps",
    ),
    path(
        "settings/",
        views.BootstrapSettingsView.as_view(),
        name="bootstrap_settings",
    ),
    # Docs button on the Nautobot App listing links here. mkdocs builds into
    # `static/nautobot_app_device_bootstrap/docs/` (see mkdocs.yml site_dir).
    path(
        "docs/",
        RedirectView.as_view(url=static("nautobot_app_device_bootstrap/docs/index.html")),
        name="docs",
    ),
]
urlpatterns += router.urls
